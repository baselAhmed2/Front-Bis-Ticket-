# دليل المطور - نظام إدارة التذاكر للطلاب

## 🎯 نظرة عامة

هذا النظام تم بناؤه خصيصاً ليكون:
1. **متجاوب بالكامل**: يعمل بشكل ممتاز على جميع الأجهزة وخاصة الهواتف المحمولة
2. **جاهز للـ API**: بنية واضحة لسهولة الربط مع الـ Backend
3. **سهل الصيانة**: كود منظم وموثق بشكل جيد

---

## 📱 التصميم المتجاوب - أهم النقاط

### القائمة الجانبية
```tsx
// Desktop: ثابتة على الجانب
<aside className="hidden md:fixed md:inset-y-0 md:flex md:w-64">
  {/* محتوى القائمة */}
</aside>

// Mobile: منبثقة من الجانب
<Sheet open={mobileMenuOpen}>
  <SheetContent side="left" className="w-64">
    {/* نفس محتوى القائمة */}
  </SheetContent>
</Sheet>
```

### الشبكات المتجاوبة
```tsx
// من عمود واحد في الموبايل إلى 3 أعمدة في Desktop
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
  {items.map(item => <Card key={item.id}>{item.name}</Card>)}
</div>
```

### الفلاتر
```tsx
// Desktop: Select عادي
<Select className="hidden md:block">
  {/* الخيارات */}
</Select>

// Mobile: Sheet من الأسفل
<Sheet>
  <SheetContent side="bottom">
    {/* نفس الخيارات */}
  </SheetContent>
</Sheet>
```

---

## 🔌 كيفية ربط النظام بالـ Backend

### الخطوة 1: فهم بنية الـ API Layer

جميع استدعاءات الـ API موجودة في ملف واحد: `/lib/api.ts`

```typescript
// المثال الحالي (Mock Data)
export const ticketAPI = {
  getAll: async (filters) => {
    // محاكاة تأخير الشبكة
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // فلترة البيانات الوهمية
    let filtered = [...MOCK_TICKETS];
    if (filters?.status) {
      filtered = filtered.filter(t => t.status === filters.status);
    }
    return filtered;
  }
};
```

### الخطوة 2: استبدال بـ API حقيقي

```typescript
// بعد الربط بالـ Backend
export const ticketAPI = {
  getAll: async (filters?: { status?: string; search?: string }) => {
    // بناء الـ query parameters
    const params = new URLSearchParams();
    if (filters?.status && filters.status !== 'all') {
      params.append('status', filters.status);
    }
    if (filters?.search) {
      params.append('search', filters.search);
    }

    // استدعاء الـ API
    const response = await fetch(`${API_BASE_URL}/tickets?${params}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${getToken()}`, // إذا كان هناك توثيق
      },
    });

    // معالجة الأخطاء
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    // إرجاع البيانات
    return response.json();
  },

  create: async (data: Partial<Ticket>) => {
    const response = await fetch(`${API_BASE_URL}/tickets`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${getToken()}`,
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error('Failed to create ticket');
    }

    return response.json();
  }
};
```

### الخطوة 3: إضافة ملف للإعدادات

أنشئ ملف `/lib/config.ts`:

```typescript
export const config = {
  apiBaseUrl: process.env.REACT_APP_API_URL || 'http://localhost:3000/api',
  tokenKey: 'auth_token',
};

export const getToken = () => {
  return localStorage.getItem(config.tokenKey);
};

export const setToken = (token: string) => {
  localStorage.setItem(config.tokenKey, token);
};

export const removeToken = () => {
  localStorage.removeItem(config.tokenKey);
};
```

### الخطوة 4: معالجة الأخطاء المركزية

أنشئ ملف `/lib/error-handler.ts`:

```typescript
import { toast } from 'sonner';

export class APIError extends Error {
  constructor(
    public status: number,
    message: string,
    public data?: any
  ) {
    super(message);
    this.name = 'APIError';
  }
}

export const handleAPIError = (error: unknown) => {
  if (error instanceof APIError) {
    // معالجة أخطاء الـ API
    switch (error.status) {
      case 401:
        toast.error('انتهت صلاحية الجلسة. يرجى تسجيل الدخول مرة أخرى');
        // إعادة توجيه لصفحة تسجيل الدخول
        window.location.href = '/login';
        break;
      case 403:
        toast.error('ليس لديك صلاحية للقيام بهذا الإجراء');
        break;
      case 404:
        toast.error('البيانات المطلوبة غير موجودة');
        break;
      case 500:
        toast.error('خطأ في الخادم. يرجى المحاولة لاحقاً');
        break;
      default:
        toast.error(error.message || 'حدث خطأ ما');
    }
  } else if (error instanceof Error) {
    toast.error(error.message);
  } else {
    toast.error('حدث خطأ غير متوقع');
  }
  
  console.error('API Error:', error);
};
```

ثم استخدمها في المكونات:

```typescript
import { handleAPIError } from '@/lib/error-handler';

const loadTickets = async () => {
  try {
    const data = await ticketAPI.getAll();
    setTickets(data);
  } catch (error) {
    handleAPIError(error);
  }
};
```

---

## 🎨 تخصيص الألوان والتصميم

### تغيير اللون الأساسي

في ملف `/styles/globals.css`:

```css
:root {
  /* اللون البنفسجي الحالي */
  --primary: #7f56d8;
  
  /* للتغيير لأزرق مثلاً */
  --primary: #3b82f6;
  
  /* للتغيير لأخضر */
  --primary: #10b981;
}
```

### تخصيص الألوان في المكونات

```tsx
// البحث عن:
className="bg-purple-600 hover:bg-purple-700"

// واستبدالها بـ:
className="bg-blue-600 hover:bg-blue-700"
// أو
className="bg-green-600 hover:bg-green-700"
```

---

## 📊 إضافة حالات جديدة للتذاكر

### 1. تحديث الـ Types

في `/types/index.ts`:

```typescript
// إضافة حالة جديدة
export type TicketStatus = 'new' | 'on-going' | 'resolved' | 'closed' | 'pending';
```

### 2. تحديث الألوان

في المكونات:

```typescript
const statusColors = {
  'new': 'bg-blue-500',
  'on-going': 'bg-yellow-500',
  'resolved': 'bg-green-500',
  'closed': 'bg-gray-500',      // جديد
  'pending': 'bg-orange-500',    // جديد
};
```

---

## 🔔 إضافة الإشعارات الفورية (Real-time)

### استخدام WebSocket

أنشئ ملف `/lib/websocket.ts`:

```typescript
import { toast } from 'sonner';

class WebSocketService {
  private ws: WebSocket | null = null;
  private listeners: Map<string, Set<Function>> = new Map();

  connect(token: string) {
    this.ws = new WebSocket(`ws://your-server.com/ws?token=${token}`);

    this.ws.onopen = () => {
      console.log('WebSocket connected');
      toast.success('تم الاتصال بالخادم');
    };

    this.ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      this.emit(data.type, data.payload);
    };

    this.ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      toast.error('خطأ في الاتصال');
    };

    this.ws.onclose = () => {
      console.log('WebSocket disconnected');
      // إعادة الاتصال بعد 5 ثواني
      setTimeout(() => this.connect(token), 5000);
    };
  }

  on(event: string, callback: Function) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
  }

  off(event: string, callback: Function) {
    this.listeners.get(event)?.delete(callback);
  }

  private emit(event: string, data: any) {
    this.listeners.get(event)?.forEach(callback => callback(data));
  }

  send(event: string, data: any) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ event, data }));
    }
  }

  disconnect() {
    this.ws?.close();
  }
}

export const wsService = new WebSocketService();
```

### استخدامها في المكونات

```typescript
import { wsService } from '@/lib/websocket';

function TicketsList() {
  useEffect(() => {
    // الاستماع للتذاكر الجديدة
    const handleNewTicket = (ticket: Ticket) => {
      toast.success('تذكرة جديدة!');
      setTickets(prev => [ticket, ...prev]);
    };

    wsService.on('new-ticket', handleNewTicket);

    return () => {
      wsService.off('new-ticket', handleNewTicket);
    };
  }, []);
}
```

---

## 📤 إضافة رفع الملفات

### 1. تحديث النموذج

```tsx
import { useState } from 'react';

function NewTicket() {
  const [files, setFiles] = useState<File[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('title', title);
    formData.append('description', description);
    
    // إضافة الملفات
    files.forEach(file => {
      formData.append('attachments', file);
    });

    // إرسال
    const response = await fetch('/api/tickets', {
      method: 'POST',
      body: formData, // لا تضف Content-Type header
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* الحقول الأخرى */}
      
      <div>
        <Label htmlFor="files">المرفقات (اختياري)</Label>
        <Input
          id="files"
          type="file"
          multiple
          onChange={handleFileChange}
          accept="image/*,.pdf,.doc,.docx"
        />
        {files.length > 0 && (
          <div className="mt-2 space-y-1">
            {files.map((file, index) => (
              <div key={index} className="text-sm text-gray-600 flex items-center gap-2">
                <span>{file.name}</span>
                <button
                  type="button"
                  onClick={() => setFiles(files.filter((_, i) => i !== index))}
                  className="text-red-500 hover:text-red-700"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </form>
  );
}
```

---

## 🔍 إضافة البحث المتقدم

```typescript
interface AdvancedFilters {
  status?: string;
  priority?: string;
  dateFrom?: string;
  dateTo?: string;
  category?: string;
}

const [filters, setFilters] = useState<AdvancedFilters>({});

// في الـ API
const buildQueryString = (filters: AdvancedFilters) => {
  const params = new URLSearchParams();
  
  Object.entries(filters).forEach(([key, value]) => {
    if (value) params.append(key, value);
  });
  
  return params.toString();
};
```

---

## 🎯 نصائح مهمة للتطوير

### 1. استخدم TypeScript بشكل صحيح

```typescript
// ❌ خطأ
const data = await api.getTickets();

// ✅ صحيح
const data: Ticket[] = await api.getTickets();
```

### 2. معالجة حالات التحميل

```typescript
const [loading, setLoading] = useState(true);
const [data, setData] = useState<Ticket[]>([]);

useEffect(() => {
  const load = async () => {
    setLoading(true);
    try {
      const result = await api.getTickets();
      setData(result);
    } finally {
      setLoading(false);
    }
  };
  load();
}, []);

if (loading) return <Skeleton />;
return <DataList data={data} />;
```

### 3. استخدم useMemo للأداء

```typescript
const filteredTickets = useMemo(() => {
  return tickets.filter(t => 
    t.status === selectedStatus &&
    t.title.includes(searchQuery)
  );
}, [tickets, selectedStatus, searchQuery]);
```

### 4. استخدم useCallback للدوال

```typescript
const handleDelete = useCallback(async (id: string) => {
  await api.deleteTicket(id);
  setTickets(prev => prev.filter(t => t.id !== id));
}, []);
```

---

## 🐛 حل المشاكل الشائعة

### المشكلة: الصور لا تظهر

```typescript
// ✅ الحل
import img from "figma:asset/...";  // بدون ./
```

### المشكلة: التذاكر لا تتحدث

```typescript
// تأكد من استدعاء loadTickets بعد الإنشاء
const handleCreate = async () => {
  await ticketAPI.create(data);
  await loadTickets(); // هذا مهم!
};
```

### المشكلة: القائمة الجانبية لا تغلق على الموبايل

```typescript
// تأكد من تمرير mobile={true}
<NavContent mobile />

// وإغلاق القائمة عند الضغط
onClick={() => {
  onNavigate(page);
  if (mobile) setMobileMenuOpen(false);  // مهم!
}}
```

---

## 📱 اختبار التجاوب

### في Chrome DevTools

1. اضغط `F12`
2. اضغط `Ctrl + Shift + M` لفتح وضع الجوال
3. جرب الأحجام المختلفة:
   - iPhone SE (375px)
   - iPhone 12 Pro (390px)
   - iPad (768px)
   - Desktop (1920px)

### نقاط مهمة للفحص

- ✅ القائمة تظهر وتختفي بشكل صحيح
- ✅ الجداول تتحول لبطاقات
- ✅ النماذج سهلة الاستخدام
- ✅ لا يوجد scroll أفقي
- ✅ الأزرار كبيرة كفاية للمس
- ✅ النصوص واضحة وقابلة للقراءة

---

## 🚀 للنشر (Deployment)

### 1. بناء المشروع

```bash
npm run build
```

### 2. متغيرات البيئة

أنشئ ملف `.env`:

```
REACT_APP_API_URL=https://api.yoursite.com
REACT_APP_WS_URL=wss://ws.yoursite.com
```

### 3. تحسين الأداء

- استخدم lazy loading للصفحات الكبيرة
- ضغط الصور
- استخدم CDN للـ assets
- تفعيل caching

---

## 📞 للدعم والأسئلة

إذا واجهت أي مشاكل أو لديك أسئلة:

1. راجع التوثيق في README.md
2. تحقق من console.log في DevTools
3. راجع الأخطاء في Network tab

---

**تم بناء النظام بعناية فائقة ليكون سهل الفهم والتطوير. بالتوفيق! 🎉**
