import { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { TicketsList } from './components/TicketsList';
import { NewTicket } from './components/NewTicket';
import { TicketDetail } from './components/TicketDetail';
import { MyCourses } from './components/MyCourses';
import { Toaster } from './components/ui/sonner';
import { studentAPI } from './lib/api';
import type { Student } from './types';

type Page = 'dashboard' | 'tickets' | 'new-ticket' | 'ticket-detail' | 'courses';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [student, setStudent] = useState<Student | null>(null);

  useEffect(() => {
    loadStudent();
  }, []);

  const loadStudent = async () => {
    try {
      const data = await studentAPI.getCurrent();
      setStudent(data);
    } catch (error) {
      console.error('Failed to load student:', error);
    }
  };

  const handleNavigate = (page: string, ticketId?: string) => {
    setCurrentPage(page as Page);
    if (ticketId) {
      setSelectedTicketId(ticketId);
    }
    // Scroll to top on navigation
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onNavigate={handleNavigate} />;
      
      case 'tickets':
        return <TicketsList onNavigate={handleNavigate} />;
      
      case 'new-ticket':
        return (
          <NewTicket
            onNavigate={handleNavigate}
            studentId={student?.id || ''}
            studentName={student?.name || ''}
          />
        );
      
      case 'ticket-detail':
        return selectedTicketId ? (
          <TicketDetail
            ticketId={selectedTicketId}
            onNavigate={handleNavigate}
            studentName={student?.name || ''}
          />
        ) : (
          <TicketsList onNavigate={handleNavigate} />
        );
      
      case 'courses':
        return <MyCourses />;
      
      default:
        return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <>
      <Layout currentPage={currentPage} onNavigate={handleNavigate}>
        {renderPage()}
      </Layout>
      <Toaster position="top-center" />
    </>
  );
}

export default App;
