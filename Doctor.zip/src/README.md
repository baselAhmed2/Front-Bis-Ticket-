# نظام إدارة التذاكر للطلاب - Student Ticket System

نظام متكامل لإدارة تذاكر الدعم للطلاب مع واجهة مستخدم متجاوبة تعمل بشكل ممتاز على الهواتف المحمولة.

## المميزات الرئيسية

### ✅ التصميم المتجاوب (Mobile-First)
- تصميم متجاوب 100% يعمل بشكل ممتاز على جميع الأجهزة
- قائمة جانبية قابلة للطي على الهواتف
- شبكات متجاوبة تتكيف مع حجم الشاشة
- أزرار وعناصر تحكم محسّنة للمس

### 📱 الصفحات المتاحة
1. **Dashboard (لوحة التحكم)**
   - إحصائيات التذاكر (جديدة، قيد التنفيذ، مغلقة)
   - عرض التذاكر ذات الأولوية العالية

2. **Tickets (قائمة التذاكر)**
   - عرض جميع التذاكر
   - بحث وتصفية متقدمة
   - فلاتر حسب الحالة

3. **New Ticket (إنشاء تذكرة جديدة)**
   - نموذج سهل الاستخدام
   - تصنيفات متعددة
   - التحقق من صحة البيانات

4. **Ticket Detail (تفاصيل التذكرة)**
   - عرض التفاصيل الكاملة
   - سجل الردود
   - إضافة ردود جديدة

5. **My Courses (الكورسات)**
   - عرض الكورسات المسجلة
   - شريط التقدم

### 🔌 جاهز للـ API
النظام مبني بطريقة تسهل الربط مع Backend:

```typescript
// في ملف /lib/api.ts
export const ticketAPI = {
  getAll: async (filters) => {
    // استبدل هذا السطر بـ API الحقيقي
    const response = await fetch('/api/tickets');
    return response.json();
  },
  
  create: async (data) => {
    const response = await fetch('/api/tickets', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    return response.json();
  },
  
  // ... المزيد من الدوال
};
```

### 🎨 المكونات الأساسية

#### Layout Component
```typescript
<Layout currentPage="dashboard" onNavigate={handleNavigate}>
  {children}
</Layout>
```

#### Dashboard Component
```typescript
<Dashboard onNavigate={(page, ticketId) => handleNavigate(page, ticketId)} />
```

#### Tickets List
```typescript
<TicketsList onNavigate={handleNavigate} />
```

## البنية التقنية

### الملفات الرئيسية

```
/
├── App.tsx                 # الملف الرئيسي للتطبيق
├── types/
│   └── index.ts           # تعريفات الأنواع (TypeScript Types)
├── lib/
│   └── api.ts             # طبقة الـ API
├── components/
│   ├── Layout.tsx         # القالب الرئيسي
│   ├── Dashboard.tsx      # لوحة التحكم
│   ├── TicketsList.tsx    # قائمة التذاكر
│   ├── NewTicket.tsx      # إنشاء تذكرة جديدة
│   ├── TicketDetail.tsx   # تفاصيل التذكرة
│   └── MyCourses.tsx      # صفحة الكورسات
└── styles/
    └── globals.css        # الأنماط العامة
```

### Types المستخدمة

```typescript
interface Ticket {
  id: string;
  title: string;
  description: string;
  status: 'new' | 'on-going' | 'resolved';
  priority?: 'high' | 'medium' | 'low';
  category: string;
  studentId: string;
  studentName: string;
  course?: string;
  groupNumber?: number;
  createdAt: string;
  updatedAt: string;
  replies?: TicketReply[];
}
```

## كيفية الربط مع الـ Backend

### 1. استبدال البيانات الوهمية (Mock Data)

في ملف `/lib/api.ts`، استبدل الدوال الحالية بـ API الحقيقي:

```typescript
// قبل (Mock)
export const ticketAPI = {
  getAll: async () => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return MOCK_TICKETS;
  }
};

// بعد (Real API)
export const ticketAPI = {
  getAll: async (filters?: { status?: string; search?: string }) => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.search) params.append('search', filters.search);
    
    const response = await fetch(`/api/tickets?${params}`);
    if (!response.ok) throw new Error('Failed to fetch tickets');
    return response.json();
  }
};
```

### 2. إضافة التوثيق (Authentication)

```typescript
// في ملف api.ts
const getAuthHeaders = () => ({
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${localStorage.getItem('token')}`,
});

export const ticketAPI = {
  create: async (data) => {
    const response = await fetch('/api/tickets', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });
    return response.json();
  }
};
```

### 3. معالجة الأخطاء

```typescript
try {
  const tickets = await ticketAPI.getAll();
  setTickets(tickets);
} catch (error) {
  console.error('Failed to load tickets:', error);
  toast.error('فشل في تحميل التذاكر');
}
```

## التصميم المتجاوب

### نقاط التكسر (Breakpoints)

- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

### أمثلة على التصميم المتجاوب

```tsx
// شبكة متجاوبة
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
  {/* المحتوى */}
</div>

// القائمة الجانبية المخفية على الموبايل
<aside className="hidden md:block">
  {/* القائمة */}
</aside>

// قائمة منبثقة على الموبايل
<Sheet>
  <SheetTrigger className="md:hidden">
    <Menu />
  </SheetTrigger>
</Sheet>
```

## المكتبات المستخدمة

- **React**: المكتبة الأساسية
- **TypeScript**: للكتابة الآمنة
- **Tailwind CSS**: للتنسيق
- **shadcn/ui**: مكونات الواجهة
- **Lucide React**: الأيقونات
- **Sonner**: الإشعارات

## التحسينات المضافة

1. ✅ تصميم متجاوب كامل للموبايل
2. ✅ قائمة جانبية قابلة للطي
3. ✅ فلاتر محسّنة للموبايل
4. ✅ نماذج محسّنة للمس
5. ✅ إشعارات Toast للنجاح والأخطاء
6. ✅ حالات التحميل (Loading States)
7. ✅ معالجة الأخطاء
8. ✅ انتقالات سلسة بين الصفحات
9. ✅ تصنيفات وحالات ملونة
10. ✅ بنية كود قابلة للصيانة

## ملاحظات مهمة

### للمطورين

1. **استخدم الـ Types**: جميع الأنواع معرّفة في `/types/index.ts`
2. **API Layer**: جميع استدعاءات الـ API في `/lib/api.ts`
3. **Toast Notifications**: استخدم `toast.success()` و `toast.error()`
4. **Navigation**: استخدم `onNavigate(page, ticketId?)` للانتقال

### للتطوير المستقبلي

1. إضافة صفحة تسجيل الدخول
2. إضافة رفع الملفات للتذاكر
3. إضافة إشعارات فورية (Real-time)
4. إضافة نظام التقييم للتذاكر
5. إضافة تصدير التقارير

## الدعم

للأسئلة والاستفسارات، يرجى التواصل مع فريق التطوير.

---

تم بناء النظام بعناية ليكون:
- 📱 متجاوب تماماً
- ⚡ سريع وفعّال
- 🔌 جاهز للـ API
- 🎨 سهل التخصيص
- 🛠️ قابل للصيانة
