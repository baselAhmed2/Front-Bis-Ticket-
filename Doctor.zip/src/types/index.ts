// Types for the Student Portal

export type TicketStatus = 'new' | 'on-going' | 'resolved';
export type TicketPriority = 'high' | 'medium' | 'low';

export interface Ticket {
  id: string;
  title: string;
  description: string;
  status: TicketStatus;
  priority?: TicketPriority;
  category: string;
  studentId: string;
  studentName: string;
  course?: string;
  groupNumber?: number;
  createdAt: string;
  updatedAt: string;
  replies?: TicketReply[];
}

export interface TicketReply {
  id: string;
  ticketId: string;
  message: string;
  sender: string;
  senderType: 'student' | 'admin';
  createdAt: string;
}

export interface Course {
  id: string;
  name: string;
  image: string;
  progress?: number;
  enrolledStudents?: number;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  avatar: string;
  courses: string[];
}

export interface TicketStats {
  newTickets: number;
  inProgress: number;
  closed: number;
}
