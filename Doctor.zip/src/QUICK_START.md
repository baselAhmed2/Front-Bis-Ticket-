# 🚀 دليل البدء السريع

## نظرة سريعة على النظام

تم بناء نظام كامل لإدارة تذاكر الدعم للطلاب يتضمن:

### ✅ ما تم إنجازه

1. **5 صفحات رئيسية كاملة:**
   - 📊 Dashboard (لوحة التحكم)
   - 📋 Tickets List (قائمة التذاكر)
   - ➕ New Ticket (إنشاء تذكرة جديدة)
   - 🔍 Ticket Detail (تفاصيل التذكرة)
   - 📚 My Courses (كورساتي)

2. **تصميم متجاوب 100%**
   - يعمل بشكل ممتاز على الهواتف ✅
   - قائمة جانبية قابلة للطي
   - فلاتر محسّنة للموبايل
   - نماذج سهلة الاستخدام على اللمس

3. **جاهز للـ API**
   - بنية واضحة ومنظمة
   - سهل الربط مع Backend
   - معالجة أخطاء شاملة

---

## 📁 ملفات المشروع

```
/
├── App.tsx                      # نقطة البداية
├── types/index.ts              # تعريفات الأنواع
├── lib/
│   └── api.ts                  # طبقة الـ API (استبدلها بالـ API الحقيقي)
├── components/
│   ├── Layout.tsx              # القالب الأساسي
│   ├── Dashboard.tsx           # لوحة التحكم
│   ├── TicketsList.tsx         # قائمة التذاكر
│   ├── NewTicket.tsx           # إنشاء تذكرة
│   ├── TicketDetail.tsx        # تفاصيل التذكرة
│   └── MyCourses.tsx           # صفحة الكورسات
└── README.md                   # التوثيق الكامل
```

---

## 🎯 كيف تبدأ؟

### الخطوة 1: فهم البنية

النظام يستخدم:
- React + TypeScript
- Tailwind CSS للتنسيق
- shadcn/ui للمكونات

### الخطوة 2: استكشاف الصفحات

1. **Dashboard** - يعرض إحصائيات التذاكر
2. **Tickets** - قائمة بجميع التذاكر مع بحث وفلترة
3. **New Ticket** - نموذج لإنشاء تذكرة جديدة
4. **Ticket Detail** - تفاصيل كاملة + إضافة ردود
5. **My Courses** - عرض الكورسات المسجلة

### الخطوة 3: ربط الـ API

افتح ملف `/lib/api.ts` واستبدل الـ Mock Data:

```typescript
// قبل (Mock)
export const ticketAPI = {
  getAll: async () => {
    return MOCK_TICKETS;
  }
};

// بعد (Real API)
export const ticketAPI = {
  getAll: async () => {
    const response = await fetch('YOUR_API_URL/tickets');
    return response.json();
  }
};
```

---

## 📱 اختبار التجاوب

### على Chrome:
1. افتح الصفحة
2. اضغط `F12`
3. اضغط `Ctrl + Shift + M`
4. جرب أحجام مختلفة:
   - 📱 Mobile: 375px
   - 📱 Tablet: 768px
   - 💻 Desktop: 1920px

### تأكد من:
- ✅ القائمة الجانبية تعمل
- ✅ الفلاتر تظهر بشكل صحيح
- ✅ البطاقات مرتبة بشكل جيد
- ✅ النماذج سهلة الاستخدام

---

## 🔧 التخصيص السريع

### تغيير اللون الأساسي

ابحث عن `purple` واستبدله بأي لون:

```tsx
// من
className="bg-purple-600"

// إلى
className="bg-blue-600"
// أو
className="bg-green-600"
```

### إضافة حقول جديدة للتذكرة

1. عدّل `/types/index.ts`:
```typescript
export interface Ticket {
  // ... الحقول الموجودة
  priority?: 'high' | 'medium' | 'low';  // جديد
  attachments?: string[];                 // جديد
}
```

2. عدّل النموذج في `NewTicket.tsx`
3. عدّل العرض في `TicketDetail.tsx`

---

## 💡 أمثلة سريعة

### مثال 1: إضافة زر جديد

```tsx
<Button 
  onClick={() => console.log('clicked')}
  className="bg-purple-600"
>
  زر جديد
</Button>
```

### مثال 2: عرض بيانات من API

```tsx
const [data, setData] = useState([]);

useEffect(() => {
  const load = async () => {
    const result = await ticketAPI.getAll();
    setData(result);
  };
  load();
}, []);
```

### مثال 3: إضافة إشعار

```tsx
import { toast } from 'sonner';

// نجاح
toast.success('تم بنجاح!');

// خطأ
toast.error('حدث خطأ!');

// معلومات
toast.info('معلومة مهمة');
```

---

## 🎨 المكونات الجاهزة

يمكنك استخدام:

```tsx
// بطاقة
<Card>
  <CardHeader>
    <CardTitle>عنوان</CardTitle>
  </CardHeader>
  <CardContent>المحتوى</CardContent>
</Card>

// حقل إدخال
<Input placeholder="اكتب هنا..." />

// قائمة منسدلة
<Select>
  <SelectTrigger>
    <SelectValue placeholder="اختر" />
  </SelectTrigger>
  <SelectContent>
    <SelectItem value="1">خيار 1</SelectItem>
  </SelectContent>
</Select>

// زر
<Button>اضغط هنا</Button>

// شارة
<Badge>جديد</Badge>
```

---

## 🐛 حل المشاكل السريعة

### المشكلة: الصفحة فارغة
```typescript
// تأكد من أن الـ API تُرجع بيانات
console.log('Data:', data);
```

### المشكلة: التذاكر لا تظهر
```typescript
// تأكد من استدعاء loadTickets
useEffect(() => {
  loadTickets();
}, []);
```

### المشكلة: القائمة لا تغلق على الموبايل
```typescript
// تأكد من:
if (mobile) setMobileMenuOpen(false);
```

---

## 📊 البيانات الوهمية (Mock Data)

النظام يحتوي على بيانات تجريبية في `/lib/api.ts`:

- 3 تذاكر
- 3 كورسات
- طالب واحد

**مهم:** استبدلها بـ API الحقيقي!

---

## 🚀 الخطوات التالية

1. ✅ **فهم البنية** - تفحص الملفات
2. ✅ **جرب النظام** - شغّله واستكشفه
3. ✅ **اربط الـ API** - استبدل Mock Data
4. ✅ **خصّص التصميم** - غيّر الألوان
5. ✅ **أضف مميزات** - حسب احتياجك

---

## 📞 هل تحتاج مساعدة؟

1. راجع `README.md` - للتوثيق الكامل
2. راجع `DEVELOPER_GUIDE_AR.md` - للأمثلة المتقدمة
3. تفحص Console في DevTools - للأخطاء

---

## ✨ مميزات إضافية يمكن إضافتها

- 📎 رفع المرفقات
- 🔔 الإشعارات الفورية
- 📊 تقارير وإحصائيات
- 🔍 بحث متقدم
- ⭐ تقييم التذاكر
- 📧 إشعارات البريد الإلكتروني

---

**النظام جاهز للاستخدام! ابدأ الآن 🎉**

لأي استفسار، راجع الملفات التوثيقية المرفقة.
