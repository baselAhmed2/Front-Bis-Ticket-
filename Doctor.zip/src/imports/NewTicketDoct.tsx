import svgPaths from "./svg-s536lawe33";
import imgEllipse73 from "figma:asset/de594936ad0a19f927b491e86d6ede3a55fdfe1d.png";

function AlignLeft() {
  return (
    <div className="absolute left-[20px] size-[30px] top-[27px]" data-name="align-left">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="align-left">
          <path d="M22.5 14.5H5" id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 7.5H5" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 21.5H5" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <div className="relative shrink-0 size-[48px]">
        <img alt="" className="block max-w-none size-full" height="48" src={imgEllipse73} width="48" />
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#1a202c] text-[16px] whitespace-nowrap">
        <p className="leading-[normal]">Alex Robert</p>
      </div>
    </div>
  );
}

function ChevronDown() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="chevron-down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="chevron-down">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #0C0407)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function User() {
  return (
    <div className="absolute bg-[#fafafa] content-stretch flex gap-[12px] h-[56px] items-center left-[1019px] pl-[5px] pr-[18px] py-[12px] rounded-[1000px] top-[14px]" data-name="user">
      <Frame />
      <ChevronDown />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[20px] top-[14px]">
      <AlignLeft />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[0] left-[63px] text-[#1b1b1b] text-[#2e2c34] text-[18px] top-[31px]">
        <span className="leading-[normal]">{`Welcome! `}</span>
        <span className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal]">John Smith</span>
      </p>
      <User />
    </div>
  );
}

function TopBar() {
  return (
    <div className="absolute h-[85px] left-[calc(16.67%-3px)] top-0 w-[1263px]" data-name="Top Bar">
      <div className="absolute bg-white h-[85px] left-0 shadow-[0px_4px_40px_1px_rgba(0,0,0,0.03)] top-0 w-[1263px]" />
      <Group2 />
    </div>
  );
}

function Card() {
  return (
    <div className="absolute h-[828px] left-0 rounded-[4px] top-0 w-[1195px]" data-name="card">
      <div className="absolute bg-white inset-0 rounded-[4px]" />
    </div>
  );
}

function InputArea() {
  return (
    <div className="h-[50px] relative rounded-[4px] shrink-0 w-[366px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Content() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[20px] top-[127px] w-[366px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[320px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Enter Subject `}</p>
      </div>
      <InputArea />
    </div>
  );
}

function InputArea1() {
  return (
    <div className="absolute content-stretch flex h-[50px] items-center left-[425px] px-[20px] py-[16px] rounded-[4px] top-[152px] w-[366px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Enter Ticket Subject  `}</p>
      </div>
    </div>
  );
}

function Tittle() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] items-start leading-[0] left-[20px] top-[24px]" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[28px] justify-center relative shrink-0 text-[#2e2a40] text-[18px] w-[204px]">
        <p className="whitespace-pre-wrap">Create Quick Ticket</p>
      </div>
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center relative shrink-0 text-[#84818a] text-[16px] whitespace-nowrap">
        <p className="leading-[normal]">Write and address new queries and issues</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#7f56d8] content-stretch flex h-[44px] items-center justify-center left-[1012px] p-[10px] rounded-[4px] top-[469px] w-[157px]" data-name="Button">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Send Ticket</p>
      </div>
    </div>
  );
}

function AttachFile() {
  return (
    <div className="absolute left-[1096px] size-[24px] top-[136px]" data-name="attach_file">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="attach_file" />
      </svg>
    </div>
  );
}

function InputArea2() {
  return (
    <div className="h-[182px] relative rounded-[4px] shrink-0 w-[1153px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[8.79%_76.24%_82.42%_1.73%] justify-center leading-[0] text-[#757575] text-[14px] tracking-[-0.28px]">
        <p className="leading-[normal] whitespace-pre-wrap">Type ticket issue here..</p>
      </div>
      <AttachFile />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] h-[208px] items-start relative shrink-0">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[320px]">
        <p className="leading-[normal] whitespace-pre-wrap">Ticket Body</p>
      </div>
      <InputArea2 />
    </div>
  );
}

function Content1() {
  return (
    <div className="absolute content-stretch flex flex-col h-[208px] items-start left-[21px] top-[235px] w-[1153px]" data-name="Content">
      <Frame1 />
    </div>
  );
}

function InputArea3() {
  return (
    <div className="h-[50px] relative rounded-[4px] shrink-0 w-[366px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Content2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[829px] top-[125px] w-[366px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[320px]">
        <p className="leading-[normal] whitespace-pre-wrap">Enter Recipient ID</p>
      </div>
      <InputArea3 />
    </div>
  );
}

function ReplyDetailTicket() {
  return (
    <div className="absolute h-[537px] left-[calc(16.67%+32px)] overflow-clip rounded-[4px] top-[194px] w-[1195px]" data-name="Reply Detail Ticket">
      <Card />
      <Content />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] left-[425px] text-[#2e2a40] text-[14px] top-[136px] w-[320px]">
        <p className="leading-[normal] whitespace-pre-wrap">{` Ticket Subject  `}</p>
      </div>
      <InputArea1 />
      <Tittle />
      <Button />
      <Content1 />
      <Content2 />
    </div>
  );
}

function Category() {
  return (
    <div className="absolute inset-[8.33%_10.42%_10.42%_8.33%]" data-name="Category">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.875 17.875">
        <g id="Category">
          <path clipRule="evenodd" d={svgPaths.p3aaa82c0} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 1" />
          <path clipRule="evenodd" d={svgPaths.p2a04b900} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 3" />
          <path clipRule="evenodd" d={svgPaths.p10e31300} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 5" />
          <path clipRule="evenodd" d={svgPaths.p120a9d80} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 7" />
        </g>
      </svg>
    </div>
  );
}

function IconlyLightOutlineCategory() {
  return (
    <div className="absolute inset-[10.78%_79.52%_87.17%_11.65%]" data-name="Iconly/Light-Outline/Category">
      <Category />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[29px] top-[116px]">
      <IconlyLightOutlineCategory />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[61px] text-[#7f56d8] text-[16px] top-[117px]">Dashboard</p>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[61px] top-[170px]">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[61px] text-[#2e2c34] text-[16px] top-[170px]">{`My Courses `}</p>
    </div>
  );
}

function IconsaxLinearTicketstar() {
  return (
    <div className="absolute left-[29px] size-[22px] top-[226px]" data-name="Iconsax/Linear/ticketstar">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/ticketstar">
          <path d={svgPaths.p388172f0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p19372c00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function MaterialSymbolsLogoutRounded() {
  return (
    <div className="absolute left-[29px] size-[22px] top-[293px]" data-name="material-symbols:logout-rounded">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="material-symbols:logout-rounded">
          <path d={svgPaths.p3c8a9ec0} fill="var(--fill-0, #1E1E1E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function AkarIconsBook() {
  return (
    <div className="absolute left-[30px] size-[19px] top-[171px]" data-name="akar-icons:book">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19">
        <g id="akar-icons:book">
          <path d={svgPaths.pa0a100} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute h-[1076px] left-0 top-0 w-[249px]" data-name="Sidebar">
      <div className="absolute h-[1076px] left-0 top-0 w-[249px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 249 1076">
          <path d={svgPaths.p29894d00} fill="var(--fill-0, white)" id="Rectangle 5884" stroke="var(--stroke-0, #E7E7E7)" />
        </svg>
      </div>
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[35px] text-[#2e2c34] text-[24px] top-[28px] uppercase">Ticket Lead</p>
      <Group1 />
      <Group />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[61px] text-[#2e2c34] text-[16px] top-[227px]">Tickets</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[59px] text-[#2e2c34] text-[16px] top-[295px]">Logout</p>
      <IconsaxLinearTicketstar />
      <MaterialSymbolsLogoutRounded />
      <AkarIconsBook />
    </div>
  );
}

export default function NewTicketDoct() {
  return (
    <div className="bg-[#f9f9fb] relative size-full" data-name="New Ticket Doct">
      <TopBar />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-[calc(16.67%+21px)] text-[#2e2c34] text-[24px] top-[125.5px] whitespace-nowrap">
        <p className="leading-[normal]">New Ticket</p>
      </div>
      <ReplyDetailTicket />
      <Sidebar />
    </div>
  );
}