import svgPaths from "./svg-xywtzvj0xz";
import imgEllipse73 from "figma:asset/de594936ad0a19f927b491e86d6ede3a55fdfe1d.png";

function AlignLeft() {
  return (
    <div className="absolute left-[20px] size-[30px] top-[27px]" data-name="align-left">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="align-left">
          <path d="M22.5 14.5H5" id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 7.5H5" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 21.5H5" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <div className="relative shrink-0 size-[48px]">
        <img alt="" className="block max-w-none size-full" height="48" src={imgEllipse73} width="48" />
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#1a202c] text-[16px] whitespace-nowrap">
        <p className="leading-[normal]">Alex Robert</p>
      </div>
    </div>
  );
}

function ChevronDown() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="chevron-down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="chevron-down">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #0C0407)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function User() {
  return (
    <div className="absolute bg-[#fafafa] content-stretch flex gap-[12px] h-[56px] items-center left-[1019px] pl-[5px] pr-[18px] py-[12px] rounded-[1000px] top-[14px]" data-name="user">
      <Frame />
      <ChevronDown />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[20px] top-[14px]">
      <AlignLeft />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[0] left-[63px] text-[#1b1b1b] text-[#2e2c34] text-[18px] top-[31px]">
        <span className="leading-[normal]">{`Welcome! `}</span>
        <span className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal]">John Smith</span>
      </p>
      <User />
    </div>
  );
}

function TopBar() {
  return (
    <div className="absolute h-[85px] left-[calc(8.33%+123px)] top-0 w-[1263px]" data-name="Top Bar">
      <div className="absolute bg-white h-[85px] left-0 shadow-[0px_4px_40px_1px_rgba(0,0,0,0.03)] top-0 w-[1263px]" />
      <Group3 />
    </div>
  );
}

function Card() {
  return (
    <div className="absolute h-[828px] left-0 rounded-[4px] top-[-3px] w-[1195px]" data-name="card">
      <div className="absolute bg-white inset-0 rounded-[4px]" />
    </div>
  );
}

function ReplyTicketBox() {
  return (
    <div className="absolute inset-[28.07%_1.67%_50.33%_1.67%]" data-name="Reply ticket Box">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1155 207.869">
        <g id="Reply ticket Box">
          <path d={svgPaths.p8f4e000} fill="var(--fill-0, #FCFCFC)" id="Rectangle 6715" stroke="var(--stroke-0, #E7E7E7)" />
        </g>
      </svg>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[27px] top-[57px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[23px] justify-center leading-[0] left-[28px] text-[#2e2c34] text-[18px] top-[68.5px] w-[340px]">
        <p className="leading-[14px] whitespace-pre-wrap">How to deposit money to my portal?</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[normal] left-[27px] text-[#84818a] text-[14px] top-[169.5px] w-[991px] whitespace-pre-wrap">
        <p className="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        <p className="mb-0">&nbsp;</p>
        <p className="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        <p className="mb-0">&nbsp;</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      </div>
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[20px] top-[18px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-[45px] text-[#2e2c34] text-[16px] top-[26px] whitespace-nowrap">
        <p className="leading-[14px]" dir="auto">
          Ticket# 2026-IE123
        </p>
      </div>
      <div className="absolute left-[20px] size-[15px] top-[18px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="7.5" />
        </svg>
      </div>
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute left-[20px] size-[15px] top-[18px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="Group 1000004235">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="7.5" />
        </g>
      </svg>
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[20px] top-[18px]">
      <Group7 />
      <Group8 />
      <Group9 />
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents left-[20px] top-[18px]">
      <Group10 />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute contents left-[1029px] top-[19px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[1029px] text-[#84818a] text-[12px] top-[26px] whitespace-nowrap">
        <p className="leading-[14px]">Posted at 12:45 -3-2026</p>
      </div>
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute contents left-[20px] top-[18px]">
      <Group11 />
      <Group12 />
    </div>
  );
}

function OutputArea() {
  return (
    <div className="bg-white content-stretch flex h-[50px] items-center px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Output Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] tracking-[-0.28px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">Basel Ahmed</p>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[365px] top-[348px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Student Name `}</p>
      </div>
      <OutputArea />
    </div>
  );
}

function Content1() {
  return <div className="absolute h-[141px] left-[35px] top-[505px] w-[967px]" data-name="Content" />;
}

function Tittle() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[36px] top-[296px] w-[53px]" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[18px] w-[292px]">
        <p className="leading-[1.5] whitespace-pre-wrap">{` Ticket Sender Information `}</p>
      </div>
    </div>
  );
}

function OutputArea1() {
  return (
    <div className="bg-white content-stretch flex h-[50px] items-center px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Output Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] tracking-[-0.28px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">512393207</p>
      </div>
    </div>
  );
}

function Content2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[35px] top-[348px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">Student ID</p>
      </div>
      <OutputArea1 />
    </div>
  );
}

function InputArea() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="absolute left-[20px] size-[15px] top-[17.5px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="7.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[34%_17.65%_34%_16.61%] justify-center leading-[0] text-[#757575] text-[14px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Information Economy `}</p>
      </div>
    </div>
  );
}

function Content3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[713px] top-[348px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Course `}</p>
      </div>
      <InputArea />
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute contents left-[35px] top-[348px]">
      <Content2 />
      <Content3 />
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute contents left-[35px] top-[296px]">
      <Content1 />
      <Tittle />
      <Group14 />
    </div>
  );
}

function InputArea1() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[122px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] left-1/2 text-[14px] text-black text-center top-1/2 w-[50px]">
        <p className="leading-[normal] whitespace-pre-wrap">9</p>
      </div>
    </div>
  );
}

function Content4() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[1036px] top-[348px] w-[125px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-full">
        <p className="leading-[normal] whitespace-pre-wrap">{`Group Number `}</p>
      </div>
      <InputArea1 />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#7f56d8] content-stretch flex items-center justify-center left-[1018px] p-[10px] rounded-[4px] top-[783px] w-[157px]" data-name="Button">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Submit</p>
      </div>
    </div>
  );
}

function InputArea2() {
  return (
    <div className="bg-white content-stretch flex h-[110px] items-start px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[967px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] tracking-[-0.28px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">Type ticket issue here..</p>
      </div>
    </div>
  );
}

function Content5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] h-[133.97px] items-start left-[20px] top-[649.42px] w-[967px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[320px]">
        <p className="leading-[normal] whitespace-pre-wrap">Ticket Body</p>
      </div>
      <InputArea2 />
    </div>
  );
}

function Tittle1() {
  return (
    <div className="absolute content-stretch flex flex-col h-[26.604px] items-start left-[21px] top-[502px]" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[28px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[18px] w-[204px]">
        <p className="leading-[1.5] whitespace-pre-wrap">Reply to Ticket</p>
      </div>
    </div>
  );
}

function InputArea3() {
  return (
    <div className="bg-white content-stretch flex h-[50px] items-center px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] tracking-[-0.28px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">512393207</p>
      </div>
    </div>
  );
}

function Content6() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[20px] top-[551.41px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">Student ID</p>
      </div>
      <InputArea3 />
    </div>
  );
}

function InputArea4() {
  return (
    <div className="bg-white content-stretch flex h-[50px] items-center pl-[20px] pr-[72px] py-[16px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] w-[176px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Enter  Ticket Subject  `}</p>
      </div>
    </div>
  );
}

function Content7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[359px] top-[551.41px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[300px]">
        <p className="leading-[normal] whitespace-pre-wrap">{` Ticket Subject  `}</p>
      </div>
      <InputArea4 />
    </div>
  );
}

function VuesaxLinearArrowDown1() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="arrow-down">
          <path d={svgPaths.p3993d9c0} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_2" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowDown() {
  return (
    <div className="relative size-[16px]" data-name="vuesax/linear/arrow-down">
      <VuesaxLinearArrowDown1 />
    </div>
  );
}

function InputArea5() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="absolute left-[20px] size-[15px] top-[17.5px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="7.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[34%_17.65%_34%_16.61%] justify-center leading-[0] text-[#757575] text-[14px]">
        <p className="leading-[normal] whitespace-pre-wrap">On-Going</p>
      </div>
      <div className="absolute flex items-center justify-center left-[256px] size-[16px] top-[17px]">
        <div className="-scale-y-100 flex-none rotate-180">
          <VuesaxLinearArrowDown />
        </div>
      </div>
    </div>
  );
}

function Content8() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[698px] top-[551.41px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">Status</p>
      </div>
      <InputArea5 />
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute contents left-[20px] top-[551.41px]">
      <Content6 />
      <Content7 />
      <Content8 />
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute contents left-[20px] top-[502px]">
      <Button />
      <Content5 />
      <Tittle1 />
      <Group17 />
    </div>
  );
}

function ReplyDetailTicket() {
  return (
    <div className="absolute h-[962px] left-[calc(16.67%+21px)] overflow-clip rounded-[4px] top-[168px] w-[1195px]" data-name="Reply Detail Ticket">
      <Card />
      <ReplyTicketBox />
      <Group13 />
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[1.63%_40.75%_96.36%_44.52%] justify-center leading-[0] text-[#757575] text-[14px]">
        <p className="leading-[normal] whitespace-pre-wrap">Classwork Issue</p>
      </div>
      <Content />
      <Group15 />
      <Content4 />
      <Group16 />
    </div>
  );
}

function Group21() {
  return (
    <div className="absolute contents left-[2px] top-[215px]">
      <div className="absolute bg-[rgba(127,86,216,0.1)] h-[45px] left-[2px] top-[215px] w-[249px]" />
    </div>
  );
}

function Category() {
  return (
    <div className="absolute inset-[8.33%_10.42%_10.42%_8.33%]" data-name="Category">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.875 17.875">
        <g id="Category">
          <path clipRule="evenodd" d={svgPaths.p3aaa82c0} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 1" />
          <path clipRule="evenodd" d={svgPaths.p2a04b900} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 3" />
          <path clipRule="evenodd" d={svgPaths.p10e31300} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 5" />
          <path clipRule="evenodd" d={svgPaths.p120a9d80} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 7" />
        </g>
      </svg>
    </div>
  );
}

function IconlyLightOutlineCategory() {
  return (
    <div className="relative shrink-0 size-[22px]" data-name="Iconly/Light-Outline/Category">
      <Category />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex gap-[10px] items-center left-[29px] top-[116px]">
      <IconlyLightOutlineCategory />
      <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] relative shrink-0 text-[#7f56d8] text-[16px]">Dashboard</p>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[8.33%_17.33%_8.87%_16.67%]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.52 18.2145">
        <g id="Group 6">
          <g id="Union">
            <path clipRule="evenodd" d={svgPaths.pbece300} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p3a518600} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Profile() {
  return (
    <div className="absolute contents inset-[8.33%_17.33%_8.87%_16.67%]" data-name="Profile">
      <Group />
    </div>
  );
}

function IconlyLightOutlineProfile() {
  return (
    <div className="absolute inset-[15.71%_79.52%_82.25%_11.65%]" data-name="Iconly/Light-Outline/Profile">
      <Profile />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[29px] top-[169px]">
      <IconlyLightOutlineProfile />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[61px] text-[#2e2c34] text-[16px] top-[170px]">Users</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[61px] top-[341px]">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[61px] text-[#2e2c34] text-[16px] top-[341px]">Site Settings</p>
    </div>
  );
}

function IconsaxLinearSetting() {
  return (
    <div className="absolute left-[29px] size-[22px] top-[341px]" data-name="Iconsax/Linear/setting">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/setting">
          <path d={svgPaths.p1d7fb300} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p31cea00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function IconsaxLinearTicketstar() {
  return (
    <div className="absolute left-[29px] size-[22px] top-[226px]" data-name="Iconsax/Linear/ticketstar">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/ticketstar">
          <path d={svgPaths.p388172f0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p19372c00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function IconsaxLinearProfile2User() {
  return (
    <div className="absolute left-[29px] size-[22px] top-[283px]" data-name="Iconsax/Linear/profile2user">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/profile2user">
          <path d={svgPaths.pc575700} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Group22() {
  return (
    <div className="absolute contents left-[2px] top-[116px]">
      <Group21 />
      <Frame1 />
      <Group2 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[61px] text-[#2e2c34] text-[16px] top-[227px]">Tickets</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[61px] text-[#2e2c34] text-[16px] top-[284px]">Officials</p>
      <Group1 />
      <IconsaxLinearSetting />
      <IconsaxLinearTicketstar />
      <IconsaxLinearProfile2User />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute h-[1076px] left-0 top-0 w-[249px]" data-name="Sidebar">
      <div className="absolute bg-white border-[#e7e7e7] border-r border-solid h-[1076px] left-0 top-0 w-[249px]" />
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[35px] text-[#2e2c34] text-[24px] top-[28px] uppercase">Ticket Lead</p>
      <Group22 />
    </div>
  );
}

function VuesaxLinearArrowDown3() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
        <g id="arrow-down">
          <path d={svgPaths.p2c331200} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_2" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowDown2() {
  return (
    <div className="relative size-[34px]" data-name="vuesax/linear/arrow-down">
      <VuesaxLinearArrowDown3 />
    </div>
  );
}

function InputArea6() {
  return <div className="absolute bg-white border border-[#e7e7e7] border-solid h-[86px] left-[calc(66.67%+107px)] rounded-[4px] top-[798px] w-[152px]" data-name="Input Area" />;
}

function ColumnDropDOwn() {
  return (
    <div className="absolute contents left-[calc(66.67%+107px)] top-[798px]" data-name="Column Drop DOwn">
      <InputArea6 />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents inset-[71.64%_17%_27.04%_75.86%]">
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[71.64%_17%_27.04%_75.86%] justify-center leading-[0] text-[#84818a] text-[12px]">
        <p className="leading-[normal] whitespace-pre-wrap">On-Going Tickets</p>
      </div>
    </div>
  );
}

function Group19() {
  return (
    <div className="absolute contents left-[calc(75%-6px)] top-[816px]">
      <div className="absolute left-[calc(75%-6px)] size-[14px] top-[817px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
          <circle cx="7" cy="7" fill="var(--fill-0, #FAC885)" id="Ellipse 933" r="7" />
        </svg>
      </div>
      <Group4 />
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents inset-[74.54%_17.39%_24.14%_75.86%]">
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[74.54%_17.39%_24.14%_75.86%] justify-center leading-[0] text-[#84818a] text-[12px]">
        <p className="leading-[normal] whitespace-pre-wrap">Resolved Tickets</p>
      </div>
    </div>
  );
}

function Group18() {
  return (
    <div className="absolute contents left-[calc(75%-6px)] top-[849px]">
      <div className="absolute left-[calc(75%-6px)] size-[14px] top-[850px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
          <circle cx="7" cy="7" fill="var(--fill-0, #54C104)" id="Ellipse 934" r="7" />
        </svg>
      </div>
      <Group5 />
    </div>
  );
}

function Group20() {
  return (
    <div className="absolute contents left-[calc(66.67%+107px)] top-[798px]">
      <ColumnDropDOwn />
      <div className="absolute bg-[rgba(127,86,216,0.05)] h-[34px] left-[calc(75%-10px)] rounded-[4px] top-[806px] w-[135px]" />
      <Group19 />
      <Group18 />
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[calc(66.67%+107px)] top-[798px]">
      <Group20 />
    </div>
  );
}

export default function TicketResponse() {
  return (
    <div className="bg-[#f9f9fb] relative size-full" data-name="TicketResponse">
      <TopBar />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-[calc(16.67%+22px)] text-[#2e2c34] text-[24px] top-[125.5px] whitespace-nowrap">
        <p className="leading-[normal]">Tickets</p>
      </div>
      <ReplyDetailTicket />
      <Sidebar />
      <div className="absolute flex items-center justify-center left-[calc(91.67%-15px)] size-[34px] top-[457px]">
        <div className="-scale-y-100 flex-none rotate-180">
          <VuesaxLinearArrowDown2 />
        </div>
      </div>
      <Group6 />
    </div>
  );
}