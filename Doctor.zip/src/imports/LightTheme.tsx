import svgPaths from "./svg-2h5m1bhpqf";

function Group() {
  return (
    <div className="absolute contents inset-[24.14%_3.68%_23.56%_19.18%] not-italic text-[#2f3032]">
      <div className="absolute flex flex-col font-['Poppins:Medium',sans-serif] inset-[24.14%_64.68%_51.15%_19.18%] justify-center leading-[0] text-[36px]">
        <p className="leading-[normal] whitespace-pre-wrap">Success</p>
      </div>
      <p className="absolute font-['Poppins:Regular',sans-serif] inset-[55.75%_3.68%_23.56%_19.18%] leading-[normal] text-[24px] whitespace-pre-wrap">Order Placed Successfully. Thank you for shopping with us.</p>
    </div>
  );
}

function CheckLine() {
  return (
    <div className="absolute inset-[24.71%_84.94%_24.14%_5.42%] overflow-clip" data-name="check-line">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 89 89">
        <g id="Group">
          <g id="Vector" />
          <path d={svgPaths.p27b73b80} fill="var(--fill-0, #00CC99)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Success() {
  return (
    <div className="absolute h-[174px] left-[329px] top-[168px] w-[923px]" data-name="Success">
      <div className="absolute bg-[#e6faf5] border border-[#0c9] border-solid inset-0 rounded-bl-[11px] rounded-br-[20px] rounded-tl-[11px] rounded-tr-[20px]" />
      <div className="absolute bg-[#0c9] inset-[0_98.92%_0_0] rounded-bl-[20px] rounded-tl-[20px]" />
      <Group />
      <CheckLine />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents inset-[24.14%_3.47%_23.56%_19.18%] not-italic text-[#2f3032]">
      <div className="absolute flex flex-col font-['Poppins:Medium',sans-serif] inset-[24.14%_64.68%_51.15%_19.18%] justify-center leading-[0] text-[36px]">
        <p className="leading-[normal] whitespace-pre-wrap">Error</p>
      </div>
      <p className="absolute font-['Poppins:Regular',sans-serif] inset-[55.75%_3.47%_23.56%_19.18%] leading-[normal] text-[24px] whitespace-pre-wrap">Payment for order could not be proceed. Please try again.</p>
    </div>
  );
}

function CloseFill() {
  return (
    <div className="absolute inset-[24.71%_84.94%_24.14%_5.42%] overflow-clip" data-name="close-fill">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 89 89">
        <g id="Group">
          <g id="Vector" />
          <path d={svgPaths.p25a42600} fill="var(--fill-0, #EB5757)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Error() {
  return (
    <div className="absolute h-[174px] left-[329px] top-[400px] w-[923px]" data-name="Error">
      <div className="absolute bg-[#fdeeee] border border-[#eb5757] border-solid inset-0 rounded-bl-[11px] rounded-br-[20px] rounded-tl-[11px] rounded-tr-[20px]" />
      <div className="absolute bg-[#eb5757] inset-[0_98.92%_0_0] rounded-bl-[20px] rounded-tl-[20px]" />
      <Group1 />
      <CloseFill />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents inset-[24.14%_0_23.56%_18.79%] not-italic text-[#2f3032]">
      <div className="absolute flex flex-col font-['Poppins:Medium',sans-serif] inset-[24.14%_59.55%_51.15%_18.79%] justify-center leading-[0] text-[36px]">
        <p className="leading-[normal] whitespace-pre-wrap">Warning</p>
      </div>
      <p className="absolute font-['Poppins:Regular',sans-serif] inset-[55.75%_0_23.56%_18.79%] leading-[normal] text-[24px] whitespace-pre-wrap">Order will not delivered in this pincode. Try other pincode</p>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents inset-0">
      <div className="absolute bg-[#fdf8e8] border border-[#f2c94c] border-solid inset-[0_2.02%_0_0] rounded-bl-[11px] rounded-br-[20px] rounded-tl-[11px] rounded-tr-[20px]" />
      <div className="absolute bg-[#f2c94c] inset-[0_98.94%_0_0] rounded-bl-[10px] rounded-tl-[10px]" />
      <Group2 />
    </div>
  );
}

function Warning() {
  return (
    <div className="absolute h-[174px] left-[329px] top-[629px] w-[942px]" data-name="Warning">
      <Group3 />
      <div className="absolute inset-[35.06%_89.46%_35.25%_9.45%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.3333 51.6667">
          <path d={svgPaths.p2c97d600} fill="var(--fill-0, #F2C94C)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents inset-[24.14%_1.63%_23.56%_19.18%] not-italic text-[#2f3032]">
      <div className="absolute flex flex-col font-['Poppins:Medium',sans-serif] inset-[24.14%_64.68%_51.15%_19.18%] justify-center leading-[0] text-[36px]">
        <p className="leading-[normal] whitespace-pre-wrap">Info</p>
      </div>
      <p className="absolute font-['Poppins:Regular',sans-serif] inset-[55.75%_1.63%_23.56%_19.18%] leading-[normal] text-[24px] whitespace-pre-wrap">You will receive a tracking link as soon as your order ships.</p>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents inset-0">
      <div className="absolute bg-[#eeeefe] border border-[#5458f7] border-solid inset-0 rounded-bl-[11px] rounded-br-[20px] rounded-tl-[11px] rounded-tr-[20px]" />
      <div className="absolute bg-[#5458f7] inset-[0_98.92%_0_0] rounded-bl-[10px] rounded-tl-[10px]" />
      <Group5 />
    </div>
  );
}

function Info() {
  return (
    <div className="absolute h-[174px] left-[329px] top-[858px] w-[923px]" data-name="Info">
      <Group4 />
      <div className="absolute flex inset-[35.25%_89.24%_35.06%_9.64%] items-center justify-center">
        <div className="-scale-y-100 flex-none h-[51.667px] w-[10.333px]">
          <div className="relative size-full" data-name="Vector">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.3333 51.6667">
              <path d={svgPaths.p2c97d600} fill="var(--fill-0, #5458F7)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function LightTheme() {
  return (
    <div className="bg-white relative size-full" data-name="Light Theme">
      <Success />
      <Error />
      <Warning />
      <Info />
    </div>
  );
}