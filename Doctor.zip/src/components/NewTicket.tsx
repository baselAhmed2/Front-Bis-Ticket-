import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';
import { Label } from './ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { ArrowLeft } from 'lucide-react';
import { ticketAPI } from '@/lib/api';
import { toast } from 'sonner';

interface NewTicketProps {
  onNavigate: (page: string) => void;
  studentId: string;
  studentName: string;
}

export function NewTicket({ onNavigate, studentId, studentName }: NewTicketProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    subject: '',
    category: '',
    recipientId: '',
    body: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.subject || !formData.category || !formData.body) {
      toast.error('Please fill in all required fields');
      return;
    }

    setLoading(true);
    try {
      await ticketAPI.create({
        title: formData.subject,
        description: formData.body,
        category: formData.category,
        studentId,
        studentName,
      });

      toast.success('Ticket created successfully!');
      onNavigate('tickets');
    } catch (error) {
      console.error('Failed to create ticket:', error);
      toast.error('Failed to create ticket. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onNavigate('tickets')}
          className="md:hidden"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl md:text-3xl font-bold">New Ticket</h1>
      </div>

      {/* Form */}
      <Card>
        <CardHeader>
          <CardTitle>Create Quick Ticket</CardTitle>
          <CardDescription>Write and address new queries and issues</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
              {/* Subject */}
              <div className="space-y-2">
                <Label htmlFor="subject">Enter Subject *</Label>
                <Input
                  id="subject"
                  placeholder="Enter subject"
                  value={formData.subject}
                  onChange={(e) => handleChange('subject', e.target.value)}
                  required
                />
              </div>

              {/* Category */}
              <div className="space-y-2">
                <Label htmlFor="category">Ticket Category *</Label>
                <Select value={formData.category} onValueChange={(val) => handleChange('category', val)}>
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Technical Issue">Technical Issue</SelectItem>
                    <SelectItem value="Academic Issue">Academic Issue</SelectItem>
                    <SelectItem value="Classwork Issue">Classwork Issue</SelectItem>
                    <SelectItem value="Payment Issue">Payment Issue</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Recipient ID */}
              <div className="space-y-2">
                <Label htmlFor="recipient">Enter Recipient ID</Label>
                <Input
                  id="recipient"
                  placeholder="Optional"
                  value={formData.recipientId}
                  onChange={(e) => handleChange('recipientId', e.target.value)}
                />
              </div>
            </div>

            {/* Ticket Body */}
            <div className="space-y-2">
              <Label htmlFor="body">Ticket Body *</Label>
              <Textarea
                id="body"
                placeholder="Type ticket issue here..."
                value={formData.body}
                onChange={(e) => handleChange('body', e.target.value)}
                className="min-h-[150px] md:min-h-[200px] resize-none"
                required
              />
            </div>

            {/* Submit Button */}
            <div className="flex justify-end pt-4">
              <Button
                type="submit"
                className="bg-purple-600 hover:bg-purple-700 w-full md:w-auto"
                disabled={loading}
              >
                {loading ? 'Sending...' : 'Send Ticket'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
