import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ticketAPI } from '@/lib/api';
import type { Ticket, TicketStats } from '@/types';
import svgPaths from '../imports/svg-rg5f8iwqsz';
import imgImage from "figma:asset/4a48e9ef3542f6dfa5c2b4006a3bd35174343b86.png";
import imgImage1 from "figma:asset/9167c8be93d950c9eebb94ae4a66f19fa94485fa.png";
import imgRectangle126 from "figma:asset/8222eca410c3d1ecebf8045ae4e6e773ae14b8a5.png";
import imgPeople from "figma:asset/574436234932c1bee1f2c0e5132cc2c2470cb1cc.png";

interface DashboardProps {
  onNavigate: (page: string, ticketId?: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const [stats, setStats] = useState<TicketStats>({ newTickets: 0, inProgress: 0, closed: 0 });
  const [highPriorityTickets, setHighPriorityTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [statsData, allTickets] = await Promise.all([
        ticketAPI.getStats(),
        ticketAPI.getAll(),
      ]);
      
      setStats(statsData);
      setHighPriorityTickets(allTickets.filter(t => t.priority === 'high').slice(0, 3));
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const statusColors = {
    'new': 'bg-blue-500',
    'on-going': 'bg-yellow-500',
    'resolved': 'bg-green-500',
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      'new': 'bg-blue-100 text-blue-800',
      'on-going': 'bg-yellow-100 text-yellow-800',
      'resolved': 'bg-green-100 text-green-800',
    };
    return colors[status as keyof typeof colors] || colors.new;
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl md:text-3xl font-bold">Dashboard</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
          {[1, 2, 3].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-40 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Page Title */}
      <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Dashboard</h1>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {/* New Tickets Card */}
        <div 
          className="relative h-[159px] rounded-[34px] cursor-pointer hover:shadow-xl transition-shadow overflow-hidden"
          onClick={() => onNavigate('tickets')}
        >
          {/* Background SVG Shape */}
          <div className="absolute h-full left-0 top-0 w-full">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 300 159">
              <path d={svgPaths.p15875b80} fill="#0BF4C8" />
            </svg>
          </div>
          
          {/* Decorative patterns */}
          <div className="absolute inset-0">
            <div className="absolute flex h-[31.072px] items-center justify-center left-[123px] top-[11px] w-[79.155px]">
              <div className="-rotate-15 flex-none">
                <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[27px] top-[8px] w-[79.155px]">
              <div className="-rotate-15 flex-none">
                <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[35px] top-[36px] w-[79.155px]">
              <div className="-rotate-15 flex-none">
                <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[97.84px] top-[62.82px] w-[79.155px]">
              <div className="flex-none rotate-[165deg]">
                <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[193.84px] top-[65.82px] w-[79.155px]">
              <div className="flex-none rotate-[165deg]">
                <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[185.84px] top-[37.82px] w-[79.155px]">
              <div className="flex-none rotate-[165deg]">
                <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="absolute h-[110px] left-[150px] shadow-[0px_4px_4px_0px_#34dabb] top-[43px] w-[136px]">
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <img alt="" className="absolute h-[121.17%] left-[-22.5%] max-w-none top-[-13.81%] w-[138.17%]" src={imgImage} />
            </div>
          </div>

          {/* Text Content */}
          <div className="absolute left-[24px] top-[22px] font-['Poppins',sans-serif]">
            <p className="text-[16px] text-[#131215] tracking-[0.48px] font-medium">
              New Ticket
            </p>
            <p className="text-[32px] text-[#131215] tracking-[0.96px] font-medium mt-2">{stats.newTickets}</p>
          </div>
          
          <p className="absolute left-[27px] bottom-[21px] text-[12px] text-[#131215] underline tracking-[0.36px] font-['Poppins',sans-serif]">
            View entire list
          </p>
        </div>

        {/* In Progress Card */}
        <div 
          className="relative h-[159px] rounded-[34px] cursor-pointer hover:shadow-xl transition-shadow overflow-hidden"
          onClick={() => onNavigate('tickets')}
        >
          {/* Background SVG Shape */}
          <div className="absolute h-full left-0 top-0 w-full">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 300 159">
              <path d={svgPaths.p67e2d00} fill="#FAD85D" />
            </svg>
          </div>
          
          {/* Decorative patterns */}
          <div className="absolute inset-0">
            <div className="absolute flex h-[31.072px] items-center justify-center left-[118px] top-[9px] w-[79.155px]">
              <div className="-rotate-15 flex-none">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[22px] top-[6px] w-[79.155px]">
              <div className="-rotate-15 flex-none">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[30px] top-[34px] w-[79.155px]">
              <div className="-rotate-15 flex-none">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[92.84px] top-[60.82px] w-[79.155px]">
              <div className="flex-none rotate-[165deg]">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[188.84px] top-[120.37px] w-[79.155px]">
              <div className="flex-none rotate-[165deg]">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[180.84px] top-[35.82px] w-[79.155px]">
              <div className="flex-none rotate-[165deg]">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="absolute h-[135px] left-[126px] shadow-[0px_8px_8px_0px_#f1cb41] top-[18px] w-[169px]">
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <img alt="" className="absolute h-[118.18%] left-[-12.79%] max-w-none top-[-9.52%] w-[125.64%]" src={imgImage1} />
            </div>
          </div>

          {/* Text Content */}
          <div className="absolute left-[24px] top-[22px] font-['Poppins',sans-serif]">
            <p className="text-[16px] text-[#131215] tracking-[0.48px] font-medium">
              In Progress
            </p>
            <p className="text-[32px] text-[#131215] tracking-[0.96px] font-medium mt-2">{stats.inProgress}</p>
          </div>
          
          <p className="absolute left-[27px] bottom-[21px] text-[12px] text-[#131215] underline tracking-[0.36px] font-['Poppins',sans-serif]">
            View entire list
          </p>
        </div>

        {/* Closed Card */}
        <div 
          className="relative h-[159px] rounded-[34px] cursor-pointer hover:shadow-xl transition-shadow overflow-hidden sm:col-span-2 lg:col-span-1"
          onClick={() => onNavigate('tickets')}
        >
          {/* Background SVG Shape */}
          <div className="absolute h-full left-0 top-0 w-full">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 300 159">
              <path d={svgPaths.p742ef80} fill="#F2A0FF" />
            </svg>
          </div>
          
          {/* Decorative patterns */}
          <div className="absolute inset-0">
            <div className="absolute flex h-[31.072px] items-center justify-center left-[109px] top-[11px] w-[79.155px]">
              <div className="-rotate-15 flex-none">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[13px] top-[8px] w-[79.155px]">
              <div className="-rotate-15 flex-none">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[21px] top-[36px] w-[79.155px]">
              <div className="-rotate-15 flex-none">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[83.84px] top-[62.82px] w-[79.155px]">
              <div className="flex-none rotate-[165deg]">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[179.84px] top-[65.82px] w-[79.155px]">
              <div className="flex-none rotate-[165deg]">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
            <div className="absolute flex h-[31.072px] items-center justify-center left-[171.84px] top-[37.82px] w-[79.155px]">
              <div className="flex-none rotate-[165deg]">
                <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" />
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="absolute h-[173px] left-[173px] top-[-14px] w-[127px]">
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <img alt="" className="absolute h-[107.35%] left-0 max-w-none top-[-2.52%] w-[103.34%]" src={imgRectangle126} />
            </div>
          </div>

          {/* Text Content */}
          <div className="absolute left-[24px] top-[22px] font-['Poppins',sans-serif]">
            <p className="text-[16px] text-[#131215] tracking-[0.48px] font-medium">
              Closed
            </p>
            <p className="text-[32px] text-[#131215] tracking-[0.96px] font-medium mt-2">{stats.closed}</p>
          </div>
          
          <p className="absolute left-[27px] bottom-[21px] text-[12px] text-[#131215] underline tracking-[0.36px] font-['Poppins',sans-serif]">
            View entire list
          </p>
        </div>
      </div>

      {/* High Priority Tickets */}
      <Card>
        <CardHeader>
          <CardTitle>High Priority Tickets</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {highPriorityTickets.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No high priority tickets</p>
          ) : (
            highPriorityTickets.map((ticket) => (
              <div
                key={ticket.id}
                className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                onClick={() => onNavigate('ticket-detail', ticket.id)}
              >
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3 mb-3">
                  <div className="flex items-start gap-3">
                    <div className={`w-3 h-3 rounded-full ${statusColors[ticket.status]} mt-1.5 flex-shrink-0`} />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-900 break-words">
                        Ticket# {ticket.id}
                      </h3>
                      {ticket.priority === 'high' && (
                        <Badge 
                          variant={ticket.status === 'resolved' ? 'default' : 'destructive'} 
                          className={ticket.status === 'resolved' ? 'bg-green-100 text-green-800 mt-1' : 'mt-1'}
                        >
                          High Priority
                        </Badge>
                      )}
                    </div>
                  </div>
                  <span className="text-sm text-gray-500 flex-shrink-0">
                    {new Date(ticket.createdAt).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </span>
                </div>

                <h4 className="font-medium text-gray-900 mb-2 break-words">{ticket.title}</h4>
                <p className="text-sm text-gray-600 mb-3 line-clamp-2 break-words">
                  {ticket.description}
                </p>

                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-sm">
                  <div className="flex items-center gap-2 text-gray-600">
                    <span className="font-medium">From:</span>
                    <span>{ticket.studentName}</span>
                  </div>
                  <button
                    className="text-purple-600 hover:text-purple-700 font-medium text-left sm:text-right"
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigate('ticket-detail', ticket.id);
                    }}
                  >
                    Open Ticket
                  </button>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}