import { useEffect, useState } from 'react';
import { Card, CardContent } from './ui/card';
import { courseAPI } from '@/lib/api';
import type { Course } from '@/types';
import imgImage from "figma:asset/4a48e9ef3542f6dfa5c2b4006a3bd35174343b86.png";
import imgImage1 from "figma:asset/9167c8be93d950c9eebb94ae4a66f19fa94485fa.png";
import imgRectangle126 from "figma:asset/8222eca410c3d1ecebf8045ae4e6e773ae14b8a5.png";

export function MyCourses() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCourses();
  }, []);

  const loadCourses = async () => {
    setLoading(true);
    try {
      const data = await courseAPI.getAll();
      setCourses(data);
    } catch (error) {
      console.error('Failed to load courses:', error);
    } finally {
      setLoading(false);
    }
  };

  const courseImages = [imgImage, imgImage1, imgRectangle126];
  const courseColors = [
    'from-cyan-400 to-cyan-500',
    'from-yellow-400 to-yellow-500',
    'from-purple-400 to-purple-500'
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl md:text-3xl font-bold">My Courses</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {[1, 2, 3].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-0">
                <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                <div className="p-4">
                  <div className="h-6 bg-gray-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Page Title */}
      <h1 className="text-2xl md:text-3xl font-bold text-gray-900">My Courses</h1>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {courses.map((course, index) => (
          <Card
            key={course.id}
            className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group"
          >
            <div className={`relative h-40 md:h-48 bg-gradient-to-br ${courseColors[index % courseColors.length]} overflow-hidden`}>
              {/* Decorative patterns */}
              <div className="absolute inset-0 opacity-20">
                <div className="absolute top-2 left-6 w-20 h-3 bg-white rounded-full transform -rotate-15"></div>
                <div className="absolute top-8 left-2 w-20 h-3 bg-white rounded-full transform -rotate-15"></div>
                <div className="absolute top-10 left-8 w-20 h-3 bg-white rounded-full transform -rotate-15"></div>
                <div className="absolute bottom-8 right-24 w-20 h-3 bg-white rounded-full transform rotate-15"></div>
                <div className="absolute bottom-12 right-20 w-20 h-3 bg-white rounded-full transform rotate-15"></div>
                <div className="absolute bottom-6 right-32 w-20 h-3 bg-white rounded-full transform rotate-15"></div>
              </div>

              {/* Course image */}
              <div className="absolute bottom-0 right-0 w-32 h-28 md:w-36 md:h-32 transform translate-x-4 group-hover:scale-110 transition-transform">
                <img
                  src={courseImages[index % courseImages.length]}
                  alt={course.name}
                  className="w-full h-full object-contain drop-shadow-lg"
                />
              </div>

              {/* Course title */}
              <div className="absolute bottom-4 left-4 md:left-6">
                <h3 className="text-xl md:text-2xl font-medium text-gray-900 drop-shadow">
                  {course.name}
                </h3>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Empty state */}
      {courses.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-gray-500">No courses available</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}