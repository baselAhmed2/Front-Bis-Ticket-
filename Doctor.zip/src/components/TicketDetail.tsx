import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { ArrowLeft, ChevronDown, ChevronUp } from 'lucide-react';
import { ticketAPI } from '@/lib/api';
import type { Ticket } from '@/types';
import { toast } from 'sonner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

interface TicketDetailProps {
  ticketId: string;
  onNavigate: (page: string) => void;
  studentName: string;
}

export function TicketDetail({ ticketId, onNavigate, studentName }: TicketDetailProps) {
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [loading, setLoading] = useState(true);
  const [replyText, setReplyText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [senderInfoExpanded, setSenderInfoExpanded] = useState(true);
  const [selectedStatus, setSelectedStatus] = useState<string>('');

  useEffect(() => {
    loadTicket();
  }, [ticketId]);

  const loadTicket = async () => {
    setLoading(true);
    try {
      const data = await ticketAPI.getById(ticketId);
      setTicket(data);
      setSelectedStatus(data.status);
    } catch (error) {
      console.error('Failed to load ticket:', error);
      toast.error('Failed to load ticket');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (newStatus: string) => {
    if (!ticket) return;
    
    setSelectedStatus(newStatus);
    try {
      await ticketAPI.updateStatus(ticketId, newStatus);
      toast.success('Ticket status updated successfully!');
      await loadTicket();
    } catch (error) {
      console.error('Failed to update status:', error);
      toast.error('Failed to update status');
      setSelectedStatus(ticket.status); // Revert on error
    }
  };

  const handleSubmitReply = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!replyText.trim()) {
      toast.error('Please enter a message');
      return;
    }

    setSubmitting(true);
    try {
      await ticketAPI.addReply(ticketId, {
        message: replyText,
        sender: studentName,
        senderType: 'student',
      });

      toast.success('Reply sent successfully!');
      setReplyText('');
      await loadTicket(); // Reload to show new reply
    } catch (error) {
      console.error('Failed to send reply:', error);
      toast.error('Failed to send reply');
    } finally {
      setSubmitting(false);
    }
  };

  const statusColors = {
    'new': 'bg-blue-500',
    'on-going': 'bg-yellow-500',
    'resolved': 'bg-green-500',
  };

  const getStatusBadge = (status: string) => {
    const configs = {
      'new': { label: 'New', className: 'bg-blue-100 text-blue-800' },
      'on-going': { label: 'On-Going', className: 'bg-yellow-100 text-yellow-800' },
      'resolved': { label: 'Resolved', className: 'bg-green-100 text-green-800' },
    };
    const config = configs[status as keyof typeof configs] || configs.new;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onNavigate('tickets')}
            className="md:hidden"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl md:text-3xl font-bold">Ticket Details</h1>
        </div>
        <Card className="animate-pulse">
          <CardContent className="p-6">
            <div className="h-96 bg-gray-200 rounded"></div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!ticket) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl md:text-3xl font-bold">Ticket Not Found</h1>
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-gray-500 mb-4">The ticket you're looking for doesn't exist.</p>
            <Button onClick={() => onNavigate('tickets')}>Back to Tickets</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onNavigate('tickets')}
          className="md:hidden"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl md:text-3xl font-bold">Tickets</h1>
      </div>

      {/* Ticket Details Card */}
      <Card>
        <CardContent className="p-4 md:p-6 space-y-6">
          {/* Ticket Header */}
          <div className="bg-gray-50 rounded-lg p-4 md:p-6 space-y-4">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
              <div className="flex items-start gap-3 flex-1">
                <div className={`w-3 h-3 rounded-full ${statusColors[ticket.status]} mt-1.5 flex-shrink-0`} />
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900 mb-2 break-words">
                    Ticket# {ticket.id}
                  </h3>
                  <p className="text-sm text-gray-500">{ticket.category}</p>
                </div>
              </div>
              <span className="text-sm text-gray-500">
                Posted at {new Date(ticket.createdAt).toLocaleString('en-US', {
                  hour: '2-digit',
                  minute: '2-digit',
                  month: 'numeric',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </span>
            </div>

            <div>
              <h4 className="font-semibold text-lg mb-2 break-words">{ticket.title}</h4>
              <p className="text-gray-600 whitespace-pre-wrap break-words">{ticket.description}</p>
            </div>
          </div>

          {/* Ticket Sender Information */}
          <div>
            <button
              onClick={() => setSenderInfoExpanded(!senderInfoExpanded)}
              className="flex items-center justify-between w-full mb-4 text-lg font-semibold"
            >
              <span>Ticket Sender Information</span>
              {senderInfoExpanded ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </button>

            {senderInfoExpanded && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>Student ID</Label>
                  <div className="p-3 bg-gray-50 rounded border">
                    {ticket.studentId}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Student Name</Label>
                  <div className="p-3 bg-gray-50 rounded border">
                    {ticket.studentName}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Course</Label>
                  <div className="p-3 bg-gray-50 rounded border flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${statusColors[ticket.status]}`} />
                    {ticket.course || 'N/A'}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Group Number</Label>
                  <div className="p-3 bg-gray-50 rounded border text-center">
                    {ticket.groupNumber || 'N/A'}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Replies */}
          {ticket.replies && ticket.replies.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Last Replays On Ticket</h3>
              {ticket.replies.map((reply) => (
                <div key={reply.id} className="bg-gray-50 rounded-lg p-4 space-y-2">
                  <div className="text-xs text-gray-500">
                    {reply.senderType === 'student' ? 'You' : reply.sender} on{' '}
                    {new Date(reply.createdAt).toLocaleDateString('en-US', {
                      month: 'numeric',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </div>
                  <p className={`text-sm ${reply.senderType === 'admin' ? 'font-semibold' : ''} break-words whitespace-pre-wrap`}>
                    {reply.message}
                  </p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Reply Form */}
      <Card>
        <CardHeader>
          <CardTitle>Reply to Ticket</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmitReply} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Token ID</Label>
                <Input value={ticket.studentId} disabled />
              </div>
              <div className="space-y-2">
                <Label>Request Ticket Type</Label>
                <Input value={ticket.category} disabled />
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={selectedStatus} onValueChange={handleStatusChange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="on-going">On-Going</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reply">Ticket Body</Label>
              <Textarea
                id="reply"
                placeholder="Type ticket issue here..."
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                className="min-h-[120px] resize-none"
              />
            </div>

            <div className="flex justify-end">
              <Button
                type="submit"
                className="bg-purple-600 hover:bg-purple-700 w-full md:w-auto"
                disabled={submitting}
              >
                {submitting ? 'Submitting...' : 'Submit'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}