// API Service Layer - Replace mock data with real API calls

import { Ticket, TicketReply, Course, Student, TicketStats } from '@/types';

// Mock data - Replace with actual API calls
const MOCK_TICKETS: Ticket[] = [
  {
    id: '2023-CS123',
    title: 'How to deposit money to my portal?',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    status: 'on-going',
    priority: 'high',
    category: 'Classwork Issue',
    studentId: '512393207',
    studentName: 'Basel Ahmed',
    course: 'Information Economy',
    groupNumber: 9,
    createdAt: '2026-03-12T12:45:00Z',
    updatedAt: '2026-03-12T12:45:00Z',
    replies: [
      {
        id: '1',
        ticketId: '2023-CS123',
        message: 'Thank you for your inquiry. We are looking into this issue.',
        sender: 'Dr.Bahlol',
        senderType: 'admin',
        createdAt: '2026-03-12T13:00:00Z',
      },
    ],
  },
  {
    id: '2023-CS124',
    title: 'Assignment submission issue',
    description: 'Unable to submit assignment through the portal',
    status: 'new',
    category: 'Technical Issue',
    studentId: '512393207',
    studentName: 'Basel Ahmed',
    course: 'Information Economy',
    groupNumber: 9,
    createdAt: '2026-03-13T10:30:00Z',
    updatedAt: '2026-03-13T10:30:00Z',
  },
  {
    id: '2023-CS125',
    title: 'Grade inquiry',
    description: 'Question about midterm exam grade',
    status: 'resolved',
    category: 'Academic Issue',
    studentId: '512393207',
    studentName: 'Basel Ahmed',
    course: 'Information Economy',
    groupNumber: 9,
    createdAt: '2026-03-10T09:15:00Z',
    updatedAt: '2026-03-11T14:20:00Z',
  },
];

const MOCK_COURSES: Course[] = [
  {
    id: '1',
    name: 'Accounting',
    image: 'figma:asset/78119752a34e20da45d1d852b4c65812f3ec273c.png',
    progress: 75,
  },
  {
    id: '2',
    name: 'Information Economy',
    image: 'figma:asset/78119752a34e20da45d1d852b4c65812f3ec273c.png',
    progress: 60,
  },
  {
    id: '3',
    name: 'Data Structures',
    image: 'figma:asset/78119752a34e20da45d1d852b4c65812f3ec273c.png',
    progress: 90,
  },
];

// API Functions - Replace implementation with actual API calls

export const ticketAPI = {
  // Get all tickets
  getAll: async (filters?: { status?: string; search?: string }): Promise<Ticket[]> => {
    // Replace with: const response = await fetch('/api/tickets');
    // return response.json();
    
    await new Promise(resolve => setTimeout(resolve, 300)); // Simulate network delay
    
    let filtered = [...MOCK_TICKETS];
    
    if (filters?.status && filters.status !== 'all') {
      filtered = filtered.filter(t => t.status === filters.status);
    }
    
    if (filters?.search) {
      const search = filters.search.toLowerCase();
      filtered = filtered.filter(t => 
        t.title.toLowerCase().includes(search) ||
        t.description.toLowerCase().includes(search) ||
        t.id.toLowerCase().includes(search)
      );
    }
    
    return filtered;
  },

  // Get single ticket
  getById: async (id: string): Promise<Ticket | null> => {
    // Replace with: const response = await fetch(`/api/tickets/${id}`);
    // return response.json();
    
    await new Promise(resolve => setTimeout(resolve, 300));
    return MOCK_TICKETS.find(t => t.id === id) || null;
  },

  // Create new ticket
  create: async (data: Partial<Ticket>): Promise<Ticket> => {
    // Replace with: const response = await fetch('/api/tickets', {
    //   method: 'POST',
    //   body: JSON.stringify(data),
    // });
    // return response.json();
    
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newTicket: Ticket = {
      id: `2023-CS${Math.floor(Math.random() * 1000)}`,
      title: data.title || '',
      description: data.description || '',
      status: 'new',
      category: data.category || '',
      studentId: data.studentId || '',
      studentName: data.studentName || '',
      course: data.course,
      groupNumber: data.groupNumber,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      replies: [],
    };
    
    MOCK_TICKETS.unshift(newTicket);
    return newTicket;
  },

  // Add reply to ticket
  addReply: async (ticketId: string, reply: Partial<TicketReply>): Promise<TicketReply> => {
    // Replace with: const response = await fetch(`/api/tickets/${ticketId}/replies`, {
    //   method: 'POST',
    //   body: JSON.stringify(reply),
    // });
    // return response.json();
    
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newReply: TicketReply = {
      id: String(Date.now()),
      ticketId,
      message: reply.message || '',
      sender: reply.sender || '',
      senderType: reply.senderType || 'student',
      createdAt: new Date().toISOString(),
    };
    
    const ticket = MOCK_TICKETS.find(t => t.id === ticketId);
    if (ticket) {
      if (!ticket.replies) ticket.replies = [];
      ticket.replies.push(newReply);
    }
    
    return newReply;
  },

  // Update ticket status
  updateStatus: async (ticketId: string, status: string): Promise<Ticket> => {
    // Replace with: const response = await fetch(`/api/tickets/${ticketId}/status`, {
    //   method: 'PATCH',
    //   body: JSON.stringify({ status }),
    // });
    // return response.json();
    
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const ticket = MOCK_TICKETS.find(t => t.id === ticketId);
    if (!ticket) {
      throw new Error('Ticket not found');
    }
    
    ticket.status = status;
    ticket.updatedAt = new Date().toISOString();
    
    return ticket;
  },

  // Get statistics
  getStats: async (): Promise<TicketStats> => {
    // Replace with: const response = await fetch('/api/tickets/stats');
    // return response.json();
    
    await new Promise(resolve => setTimeout(resolve, 200));
    
    return {
      newTickets: MOCK_TICKETS.filter(t => t.status === 'new').length,
      inProgress: MOCK_TICKETS.filter(t => t.status === 'on-going').length,
      closed: MOCK_TICKETS.filter(t => t.status === 'resolved').length,
    };
  },
};

export const courseAPI = {
  // Get all courses
  getAll: async (): Promise<Course[]> => {
    // Replace with: const response = await fetch('/api/courses');
    // return response.json();
    
    await new Promise(resolve => setTimeout(resolve, 300));
    return MOCK_COURSES;
  },

  // Get single course
  getById: async (id: string): Promise<Course | null> => {
    // Replace with: const response = await fetch(`/api/courses/${id}`);
    // return response.json();
    
    await new Promise(resolve => setTimeout(resolve, 300));
    return MOCK_COURSES.find(c => c.id === id) || null;
  },
};

export const studentAPI = {
  // Get current student info
  getCurrent: async (): Promise<Student> => {
    // Replace with: const response = await fetch('/api/student/me');
    // return response.json();
    
    await new Promise(resolve => setTimeout(resolve, 200));
    
    return {
      id: '512393207',
      name: 'Basel Ahmed',
      email: 'basel.ahmed@example.com',
      avatar: 'figma:asset/de594936ad0a19f927b491e86d6ede3a55fdfe1d.png',
      courses: ['1', '2', '3'],
    };
  },
};