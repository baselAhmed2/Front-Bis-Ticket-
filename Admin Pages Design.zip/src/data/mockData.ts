import type { Ticket, User, Course, AssignedDoctor, DoctorAnalytics, TicketReply } from '../types';

// Mock Ticket Replies
export const mockTicketReplies: TicketReply[] = [
  {
    id: '1',
    ticketId: '1',
    authorName: 'Dr.Mohmed',
    authorRole: 'doctor',
    body: 'Massage Text - Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    createdAt: '12-11-2024',
  },
  {
    id: '2',
    ticketId: '1',
    authorName: 'Basel Ahmed',
    authorRole: 'student',
    body: 'Massage Text - Thank you for the response!',
    createdAt: '13-11-2024',
  },
];

// Mock Tickets
export const mockTickets: Ticket[] = [
  {
    id: '1',
    ticketNumber: '2026-IE123',
    subject: 'How to deposit money to my portal?',
    body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    status: 'ongoing',
    type: 'Classwork Issue',
    studentId: '512393207',
    studentName: 'Basel Ahmed',
    doctorName: 'DR Bahlol',
    courseName: 'Information Economy',
    groupNumber: '9',
    postedAt: 'Posted at 12:45 -3-2026',
    replies: mockTicketReplies,
  },
  {
    id: '2',
    ticketNumber: '2023-CS123',
    subject: 'How to deposit money to my portal?',
    body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet.',
    status: 'new',
    type: 'Deposit Issue',
    studentId: '512393207',
    studentName: 'Ahmed Mohamed',
    doctorName: 'DR Bahlol',
    postedAt: 'Posted at 12:45 AM',
  },
  {
    id: '3',
    ticketNumber: '2023-CS124',
    subject: 'Issue with course enrollment',
    body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet.',
    status: 'resolved',
    type: 'Enrollment Issue',
    studentId: '512393208',
    studentName: 'Ahmed Mohamed',
    doctorName: 'DR Bahlol',
    postedAt: 'Posted at 10:30 AM',
  },
];

// Mock Users
export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Ahmed Mohamed',
    email: 'ahmed@example.com',
    role: 'student',
    studentId: '512393207',
  },
  {
    id: '2',
    name: 'Basel Ahmed',
    email: 'basel@example.com',
    role: 'student',
    studentId: '512393208',
  },
  {
    id: '3',
    name: 'DR Bahlol',
    email: 'bahlol@example.com',
    role: 'doctor',
    doctorId: '122',
  },
];

// Mock Assigned Doctors
export const mockAssignedDoctors: AssignedDoctor[] = [
  {
    id: '1',
    doctorId: '122',
    name: 'Mohamed Abdelsalam',
    courseId: 'BIs123',
  },
  {
    id: '2',
    doctorId: '122',
    name: 'Mohamed Abdelsalam',
    courseId: 'BIs123',
  },
  {
    id: '3',
    doctorId: '122',
    name: 'Mohamed Abdelsalam',
    courseId: 'BIs123',
  },
];

// Mock Courses
export const mockCourses: Course[] = [
  {
    id: '1',
    courseId: 'BIs123',
    courseName: 'Information System',
    level: 'Level 4',
    semester: 'Semester 1',
    subjectId: 'BIs123',
    assignedDoctors: mockAssignedDoctors,
  },
  {
    id: '2',
    courseId: 'CS456',
    courseName: 'Data Structures',
    level: 'Level 3',
    semester: 'Semester 2',
    subjectId: 'CS456',
    assignedDoctors: [],
  },
];

// Mock Doctor Analytics
export const mockDoctorAnalytics: DoctorAnalytics[] = [
  {
    id: '1',
    doctorId: '122',
    name: 'Mohamed Abdelsalam',
    level: 'Level 1',
    totalTickets: 9,
    closedTickets: 9,
  },
  {
    id: '2',
    doctorId: '122',
    name: 'Mohamed Abdelsalam',
    level: 'Level 2',
    totalTickets: 9,
    closedTickets: 9,
  },
  {
    id: '3',
    doctorId: '122',
    name: 'Mohamed Abdelsalam',
    level: 'Level 3',
    totalTickets: 9,
    closedTickets: 9,
  },
  {
    id: '4',
    doctorId: '122',
    name: 'Mohamed Abdelsalam',
    level: 'Level 4',
    totalTickets: 9,
    closedTickets: 9,
  },
  {
    id: '5',
    doctorId: '122',
    name: 'Mohamed Abdelsalam',
    level: 'Level 4',
    totalTickets: 9,
    closedTickets: 9,
  },
];
