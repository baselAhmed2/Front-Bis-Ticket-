import svgPaths from "./svg-ypkqck7wbf";
import imgEllipse73 from "figma:asset/de594936ad0a19f927b491e86d6ede3a55fdfe1d.png";

function AlignLeft() {
  return (
    <div className="absolute left-[20px] size-[30px] top-[27px]" data-name="align-left">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="align-left">
          <path d="M22.5 14.5H5" id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 7.5H5" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 21.5H5" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <div className="relative shrink-0 size-[48px]">
        <img alt="" className="block max-w-none size-full" height="48" src={imgEllipse73} width="48" />
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#1a202c] text-[16px] whitespace-nowrap">
        <p className="leading-[normal]">DR Bahlol</p>
      </div>
    </div>
  );
}

function User() {
  return (
    <div className="absolute bg-[#fafafa] content-stretch flex gap-[12px] h-[56px] items-center left-[1019px] pl-[5px] pr-[18px] py-[12px] rounded-[1000px] top-[14px]" data-name="user">
      <Frame />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[20px] top-[14px]">
      <AlignLeft />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[63px] text-[#2e2c34] text-[18px] top-[31px]">{`Welcome! `}</p>
      <User />
    </div>
  );
}

function TopBar() {
  return (
    <div className="h-[85px] relative shrink-0 w-full" data-name="Top Bar">
      <div className="absolute bg-white h-[85px] left-0 shadow-[0px_4px_40px_1px_rgba(0,0,0,0.03)] top-0 w-[1263px]" />
      <Group10 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[calc(16.67%-3px)] top-0 w-[1263px]">
      <TopBar />
    </div>
  );
}

function Category() {
  return (
    <div className="absolute inset-[8.33%_10.42%_10.42%_8.33%]" data-name="Category">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.875 17.875">
        <g id="Category">
          <path clipRule="evenodd" d={svgPaths.p3aaa82c0} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 1" />
          <path clipRule="evenodd" d={svgPaths.p2a04b900} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 3" />
          <path clipRule="evenodd" d={svgPaths.p10e31300} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 5" />
          <path clipRule="evenodd" d={svgPaths.p120a9d80} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 7" />
        </g>
      </svg>
    </div>
  );
}

function IconlyLightOutlineCategory() {
  return (
    <div className="absolute inset-[10.78%_83.53%_87.17%_7.63%]" data-name="Iconly/Light-Outline/Category">
      <Category />
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[19px] top-[116px]">
      <IconlyLightOutlineCategory />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[51px] text-[#7f56d8] text-[16px] top-[117px]">Dashboard</p>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[52px] top-[174px]">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[52px] text-[#2e2c34] text-[16px] top-[174px]">Tickets</p>
    </div>
  );
}

function MaterialSymbolsLogoutRounded() {
  return (
    <div className="absolute left-[22px] size-[22px] top-[397px]" data-name="material-symbols:logout-rounded">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="material-symbols:logout-rounded">
          <path d={svgPaths.p3c8a9ec0} fill="var(--fill-0, #1E1E1E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute inset-[8.33%_17.34%_8.87%_16.66%]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.52 18.2145">
        <g id="Group 6">
          <g id="Union">
            <path clipRule="evenodd" d={svgPaths.pbece300} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p3a518600} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Profile() {
  return (
    <div className="absolute contents inset-[8.33%_17.34%_8.87%_16.66%]" data-name="Profile">
      <Group4 />
    </div>
  );
}

function IconlyLightOutlineProfile() {
  return (
    <div className="absolute inset-[21.28%_83.53%_76.67%_7.63%]" data-name="Iconly/Light-Outline/Profile">
      <Profile />
    </div>
  );
}

function IconsaxLinearTicketstar() {
  return (
    <div className="absolute left-[20px] size-[22px] top-[173px]" data-name="Iconsax/Linear/ticketstar">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/ticketstar">
          <path d={svgPaths.p388172f0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p19372c00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function UimAnalytics() {
  return (
    <div className="absolute left-[22px] size-[19px] top-[342px]" data-name="uim:analytics">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19">
        <g id="uim:analytics">
          <path d={svgPaths.pe4b5000} fill="var(--fill-0, #1E1E1E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group48() {
  return (
    <div className="absolute contents left-0 top-[217px]">
      <div className="absolute bg-[rgba(127,86,216,0.1)] h-[45px] left-0 top-[217px] w-[249px]" />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute h-[1076px] left-0 top-0 w-[249px]" data-name="Sidebar">
      <div className="absolute h-[1076px] left-0 top-0 w-[249px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 249 1076">
          <path d={svgPaths.p29894d00} fill="var(--fill-0, white)" id="Rectangle 5884" stroke="var(--stroke-0, #E7E7E7)" />
        </svg>
      </div>
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[35px] text-[#2e2c34] text-[24px] top-[28px] uppercase">Ticket Lead</p>
      <Group7 />
      <Group6 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[51px] text-[#2e2c34] text-[16px] top-[230px]">{`Users `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[49px] text-[#2e2c34] text-[16px] top-[286px]">{`Add Course `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium h-[19px] leading-[normal] left-[54px] text-[#2e2c34] text-[16px] top-[342px] w-[95px] whitespace-pre-wrap">{`Analysis `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[53px] text-[#2e2c34] text-[16px] top-[399px]">Logout</p>
      <MaterialSymbolsLogoutRounded />
      <IconlyLightOutlineProfile />
      <IconsaxLinearTicketstar />
      <UimAnalytics />
      <div className="absolute inset-[26.86%_84.81%_71.96%_8.84%]" data-name="Vector">
        <div className="absolute inset-[-5.92%_-4.74%_-11.06%_-4.74%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.3333 14.8181">
            <path d={svgPaths.pcb33180} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
      <Group48 />
    </div>
  );
}

function Category1() {
  return (
    <div className="absolute inset-[8.33%_10.42%_10.42%_8.33%]" data-name="Category">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.875 17.875">
        <g id="Category">
          <path clipRule="evenodd" d={svgPaths.p3aaa82c0} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 1" />
          <path clipRule="evenodd" d={svgPaths.p2a04b900} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 3" />
          <path clipRule="evenodd" d={svgPaths.p10e31300} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 5" />
          <path clipRule="evenodd" d={svgPaths.p120a9d80} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 7" />
        </g>
      </svg>
    </div>
  );
}

function IconlyLightOutlineCategory1() {
  return (
    <div className="absolute inset-[10.78%_83.53%_87.17%_7.63%]" data-name="Iconly/Light-Outline/Category">
      <Category1 />
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[19px] top-[116px]">
      <IconlyLightOutlineCategory1 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[51px] text-[#7f56d8] text-[16px] top-[117px]">Dashboard</p>
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents left-[52px] top-[174px]">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[52px] text-[#2e2c34] text-[16px] top-[174px]">Tickets</p>
    </div>
  );
}

function MaterialSymbolsLogoutRounded1() {
  return (
    <div className="absolute left-[22px] size-[22px] top-[397px]" data-name="material-symbols:logout-rounded">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="material-symbols:logout-rounded">
          <path d={svgPaths.p3c8a9ec0} fill="var(--fill-0, #1E1E1E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute inset-[8.33%_17.34%_8.87%_16.66%]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.52 18.2145">
        <g id="Group 6">
          <g id="Union">
            <path clipRule="evenodd" d={svgPaths.pbece300} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p3a518600} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Profile1() {
  return (
    <div className="absolute contents inset-[8.33%_17.34%_8.87%_16.66%]" data-name="Profile">
      <Group5 />
    </div>
  );
}

function IconlyLightOutlineProfile1() {
  return (
    <div className="absolute inset-[21.28%_83.53%_76.67%_7.63%]" data-name="Iconly/Light-Outline/Profile">
      <Profile1 />
    </div>
  );
}

function IconsaxLinearTicketstar1() {
  return (
    <div className="absolute left-[20px] size-[22px] top-[173px]" data-name="Iconsax/Linear/ticketstar">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/ticketstar">
          <path d={svgPaths.p388172f0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p19372c00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function UimAnalytics1() {
  return (
    <div className="absolute left-[22px] size-[19px] top-[342px]" data-name="uim:analytics">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19">
        <g id="uim:analytics">
          <path d={svgPaths.pe4b5000} fill="var(--fill-0, #1E1E1E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group49() {
  return (
    <div className="absolute contents left-0 top-[217px]">
      <div className="absolute bg-[rgba(127,86,216,0.1)] h-[45px] left-0 top-[217px] w-[249px]" />
    </div>
  );
}

function Sidebar1() {
  return (
    <div className="absolute h-[1076px] left-0 top-0 w-[249px]" data-name="Sidebar">
      <div className="absolute h-[1076px] left-0 top-0 w-[249px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 249 1076">
          <path d={svgPaths.p29894d00} fill="var(--fill-0, white)" id="Rectangle 5884" stroke="var(--stroke-0, #E7E7E7)" />
        </svg>
      </div>
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[35px] text-[#2e2c34] text-[24px] top-[28px] uppercase">Ticket Lead</p>
      <Group8 />
      <Group9 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[51px] text-[#2e2c34] text-[16px] top-[230px]">{`Users `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[49px] text-[#2e2c34] text-[16px] top-[286px]">{`Add Course `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium h-[19px] leading-[normal] left-[54px] text-[#2e2c34] text-[16px] top-[342px] w-[95px] whitespace-pre-wrap">{`Analysis `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[53px] text-[#2e2c34] text-[16px] top-[399px]">Logout</p>
      <MaterialSymbolsLogoutRounded1 />
      <IconlyLightOutlineProfile1 />
      <IconsaxLinearTicketstar1 />
      <UimAnalytics1 />
      <div className="absolute inset-[26.86%_84.81%_71.96%_8.84%]" data-name="Vector">
        <div className="absolute inset-[-5.92%_-4.74%_-11.06%_-4.74%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.3333 14.8181">
            <path d={svgPaths.pcb33180} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
      <Group49 />
    </div>
  );
}

function Card() {
  return (
    <div className="absolute h-[904px] left-0 rounded-[4px] top-0 w-[1194px]" data-name="card">
      <div className="absolute bg-white inset-0 rounded-[4px]" />
    </div>
  );
}

function VuesaxLinearMessageEdit() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/message-edit">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="message-edit">
          <path d={svgPaths.p1b31b600} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Group">
            <path d={svgPaths.p395e4a00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
            <path d={svgPaths.p4b86480} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          </g>
          <g id="Vector_4" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function MessageEdit() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="message-edit">
      <VuesaxLinearMessageEdit />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#7f56d8] content-stretch flex gap-[10px] h-[44px] items-center justify-center left-[1017px] p-[10px] rounded-[4px] top-[27px] w-[157px]" data-name="Button">
      <MessageEdit />
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">New User</p>
      </div>
    </div>
  );
}

function UsersList() {
  return (
    <div className="absolute h-[885px] left-[calc(16.67%+22px)] overflow-clip rounded-[4px] top-[167px] w-[1194px]" data-name="Users List">
      <Card />
      <Button />
    </div>
  );
}

function VuesaxLinearSearchNormal() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/search-normal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="search-normal">
          <path d={svgPaths.p1cd7af0} id="Vector" stroke="var(--stroke-0, #B6B6B6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M16.5 16.5L15 15" id="Vector_2" stroke="var(--stroke-0, #B6B6B6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Vector_3" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function SearchNormal() {
  return (
    <div className="absolute inset-[calc(29.55%-0.41px)_calc(84.25%+0.69px)_calc(29.55%-0.41px)_calc(8.66%-0.83px)]" data-name="search-normal">
      <VuesaxLinearSearchNormal />
    </div>
  );
}

function SearchInput() {
  return (
    <div className="absolute bg-[#fbfbfb] border border-[#e7e7e7] border-solid h-[44px] left-[calc(16.67%+42px)] rounded-[4px] top-[195px] w-[254px]" data-name="Search Input">
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[calc(36.36%-0.27px)_calc(5.77%-0.88px)_calc(34.09%-0.32px)_calc(20.61%-0.59px)] justify-center leading-[0] text-[#b6b6b6] text-[12px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Search  User `}</p>
      </div>
      <SearchNormal />
    </div>
  );
}

function Tittle1() {
  return (
    <div className="content-stretch flex items-center relative shrink-0" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#b4b4b4] text-[12px] text-center tracking-[-0.24px] whitespace-nowrap">
        <p className="leading-[normal]">Prevoius</p>
      </div>
    </div>
  );
}

function Tittle() {
  return (
    <div className="content-stretch flex flex-col h-[31px] items-center justify-center px-[20px] py-[10px] relative rounded-[4px] shrink-0" data-name="Tittle">
      <Tittle1 />
    </div>
  );
}

function Tittle3() {
  return (
    <div className="content-stretch flex items-center relative shrink-0" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[12px] text-center text-white tracking-[-0.24px] w-[20px]">
        <p className="leading-[normal] whitespace-pre-wrap">1</p>
      </div>
    </div>
  );
}

function Tittle2() {
  return (
    <div className="bg-[#7f56d8] content-stretch flex flex-col h-[32px] items-center justify-center p-[10px] relative rounded-[4px] shrink-0" data-name="Tittle">
      <Tittle3 />
    </div>
  );
}

function Tittle5() {
  return (
    <div className="content-stretch flex items-center relative shrink-0" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[12px] text-center tracking-[-0.24px] w-[20px]">
        <p className="leading-[normal] whitespace-pre-wrap">2</p>
      </div>
    </div>
  );
}

function Tittle4() {
  return (
    <div className="content-stretch flex flex-col h-[32px] items-center justify-center p-[10px] relative rounded-[4px] shrink-0" data-name="Tittle">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Tittle5 />
    </div>
  );
}

function Tittle7() {
  return (
    <div className="content-stretch flex items-center relative shrink-0" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#84818a] text-[12px] text-center tracking-[-0.24px] w-[28px]">
        <p className="leading-[normal] whitespace-pre-wrap">Next</p>
      </div>
    </div>
  );
}

function Tittle6() {
  return (
    <div className="content-stretch flex flex-col h-[32px] items-center justify-center px-[20px] py-[10px] relative rounded-[4px] shrink-0" data-name="Tittle">
      <Tittle7 />
    </div>
  );
}

function Page() {
  return (
    <div className="absolute content-stretch flex gap-[10px] items-start left-[calc(75%+45px)] top-[994px]" data-name="Page">
      <Tittle />
      <Tittle2 />
      <Tittle4 />
      <Tittle6 />
    </div>
  );
}

function Group20() {
  return (
    <div className="absolute h-[0.25px] left-[calc(16.67%+42px)] top-[325px] w-[1154.999px]">
      <div className="absolute inset-[-1100%_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1155 3">
          <g id="Group 1000004229">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.504883" x2="1154.5" y1="2.25" y2="2.25" />
            <line id="Line_2" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeWidth="3" x1="1.5" x2="108.027" y1="1.5" y2="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function VuesaxLinearSms() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/sms">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0521 20">
        <g id="sms">
          <path d={svgPaths.p27dd8800} id="Vector" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.p221feb00} id="Vector_2" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_3" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function Sms() {
  return (
    <div className="absolute h-[20px] left-[calc(16.67%+42px)] top-[285px] w-[20.052px]" data-name="sms">
      <VuesaxLinearSms />
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[285px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[calc(16.67%+72.01px)] text-[#7f56d8] text-[14px] top-[295px] w-[72.187px]">
        <p className="leading-[14px] whitespace-pre-wrap">All Users</p>
      </div>
      <Sms />
    </div>
  );
}

function VuesaxLinearSmsNotification() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/sms-notification">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0521 20">
        <g id="sms-notification">
          <path d={svgPaths.p10b8f700} id="Vector" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.pa592f80} id="Vector_2" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.p1bb2a700} id="Vector_3" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_4" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function SmsNotification() {
  return (
    <div className="absolute h-[20px] left-[calc(25%+80px)] top-[285px] w-[20.052px]" data-name="sms-notification">
      <VuesaxLinearSmsNotification />
    </div>
  );
}

function Group18() {
  return (
    <div className="absolute contents left-[calc(25%+80px)] top-[285px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[calc(25%+106.19px)] text-[#84818a] text-[14px] top-[294px] w-[108px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Students `}</p>
      </div>
      <SmsNotification />
    </div>
  );
}

function VuesaxLinearSmsStar() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/sms-star">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0521 20">
        <g id="sms-star">
          <path d={svgPaths.p19a75730} id="Vector" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.pbb23340} id="Vector_2" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Group">
            <path d={svgPaths.p1f80e00} id="Vector_3" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Vector_4" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function SmsStar() {
  return (
    <div className="absolute h-[20px] left-[calc(50%+61px)] top-[283px] w-[20.052px]" data-name="sms-star">
      <VuesaxLinearSmsStar />
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute contents left-[calc(50%+61px)] top-[283px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[calc(50%+91.01px)] text-[#84818a] text-[14px] top-[293px] w-[65.169px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Admins `}</p>
      </div>
      <SmsStar />
    </div>
  );
}

function VuesaxLinearSmsTracking() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/sms-tracking">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0521 20">
        <g id="sms-tracking">
          <path d={svgPaths.p211db1d8} id="Vector" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.p221feb00} id="Vector_2" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d="M1.67101 13.75H6.68402" id="Vector_3" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d="M1.67101 10.4167H4.17752" id="Vector_4" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_5" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function SmsTracking() {
  return (
    <div className="absolute h-[20px] left-[calc(41.67%+24.52px)] top-[285px] w-[20.052px]" data-name="sms-tracking">
      <VuesaxLinearSmsTracking />
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute contents left-[calc(41.67%+24.52px)] top-[285px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[calc(41.67%+54.53px)] text-[#84818a] text-[14px] top-[295px] w-[70.182px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Doctors `}</p>
      </div>
      <SmsTracking />
    </div>
  );
}

function Group19() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[283px]">
      <Group15 />
      <Group18 />
      <Group17 />
      <Group16 />
    </div>
  );
}

function TicketGroup() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[283px]" data-name="Ticket Group">
      <Group20 />
      <Group19 />
    </div>
  );
}

function Group21() {
  return (
    <div className="absolute contents left-[calc(25%+48px)] top-[409px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[calc(25%+48px)] text-[#2e2c34] text-[14px] top-[416.61px] w-[411.934px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Mis information `}</p>
      </div>
    </div>
  );
}

function Group27() {
  return (
    <div className="absolute contents left-[calc(16.67%+101px)] top-[409px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(16.67%+101px)] text-[#2e2c34] text-[14px] top-[416.5px] w-[80px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Name  :`}</p>
      </div>
    </div>
  );
}

function Group23() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[371.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[calc(16.67%+101px)] text-[#2e2c34] text-[16px] top-[383.21px] w-[248.745px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Course ID :  CS 122`}</p>
      </div>
      <div className="absolute left-[calc(16.67%+62px)] size-[22px] top-[371.25px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
          <circle cx="11" cy="11" fill="var(--fill-0, #3B8AFF)" id="Ellipse 931" r="11" />
        </svg>
      </div>
    </div>
  );
}

function Group24() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[368px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(83.33%-12px)] text-[#84818a] text-[12px] top-[375.5px] w-[173px]">
        <p className="leading-[14px] whitespace-pre-wrap">Created At 22-11-2024</p>
      </div>
      <div className="absolute h-0 left-[calc(16.67%+62px)] top-[484.68px] w-[1107.47px]" data-name="Line">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1107.47 1">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.5" x2="1106.97" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Group25() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[368px]">
      <Group21 />
      <Group27 />
      <Group23 />
      <Group24 />
    </div>
  );
}

function Group26() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[349px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[32.43%_4.17%_54.93%_19.44%] rounded-[4px]" />
      <Group25 />
    </div>
  );
}

function Delete() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="delete">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="delete">
          <path d={svgPaths.p10859900} fill="var(--fill-0, white)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-[#e7000b] content-stretch flex gap-[10px] h-[44px] items-center justify-center left-[calc(83.33%-14px)] p-[10px] rounded-[4px] top-[417px] w-[144px]" data-name="Button">
      <Delete />
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Delete User</p>
      </div>
    </div>
  );
}

function Group41() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[349px]">
      <Group26 />
      <Button1 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[3.17%_3.12%_3.13%_3.22%]" data-name="Group">
      <div className="absolute inset-[-1.67%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.2282 23.2401">
          <g id="Group">
            <path d={svgPaths.p31661c03} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
            <path d={svgPaths.pc76f780} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
            <path d={svgPaths.p3f9ea000} id="Vector_3" stroke="var(--stroke-0, white)" strokeWidth="0.75" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function StreamlineUltimateTaskFingerShow() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="streamline-ultimate:task-finger-show">
      <Group />
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute bg-[#7f56d8] content-stretch flex gap-[10px] h-[44px] items-center justify-center left-[calc(66.67%+34px)] p-[10px] rounded-[4px] top-[417px] w-[157px]" data-name="Button">
      <StreamlineUltimateTaskFingerShow />
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">View Details</p>
      </div>
    </div>
  );
}

function Group22() {
  return (
    <div className="absolute contents left-[calc(25%+50px)] top-[571px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[calc(25%+50px)] text-[#2e2c34] text-[14px] top-[578.61px] w-[411.934px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Mohamed Ahmed Sayed  `}</p>
      </div>
    </div>
  );
}

function Group30() {
  return (
    <div className="absolute contents left-[calc(25%+50px)] top-[602px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(25%+50px)] text-[#2e2c34] text-[14px] top-[609.5px] w-[122px]">
        <p className="leading-[14px] whitespace-pre-wrap">30409220104425</p>
      </div>
    </div>
  );
}

function Group31() {
  return (
    <div className="absolute contents left-[calc(16.67%+103px)] top-[571px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(16.67%+103px)] text-[#2e2c34] text-[14px] top-[578.5px] w-[80px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Student  :`}</p>
      </div>
    </div>
  );
}

function Group32() {
  return (
    <div className="absolute contents left-[calc(16.67%+103px)] top-[602px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(16.67%+103px)] text-[#2e2c34] text-[14px] top-[609.5px] w-[80px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`SSN          :`}</p>
      </div>
    </div>
  );
}

function Group33() {
  return (
    <div className="absolute contents left-[calc(16.67%+64px)] top-[533.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[calc(16.67%+103px)] text-[#2e2c34] text-[16px] top-[545.21px] w-[248.745px]">
        <p className="leading-[14px] whitespace-pre-wrap">User ID : 512393207</p>
      </div>
      <div className="absolute left-[calc(16.67%+64px)] size-[22px] top-[533.25px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
          <circle cx="11" cy="11" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="11" />
        </svg>
      </div>
    </div>
  );
}

function Group34() {
  return (
    <div className="absolute contents left-[calc(16.67%+64px)] top-[530px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(83.33%-10px)] text-[#84818a] text-[12px] top-[537.5px] w-[173px]">
        <p className="leading-[14px] whitespace-pre-wrap">Created At 22-11-2024</p>
      </div>
      <div className="absolute h-0 left-[calc(16.67%+64px)] top-[646.68px] w-[1107.47px]" data-name="Line">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1107.47 1">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.5" x2="1106.97" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Group29() {
  return (
    <div className="absolute contents left-[calc(16.67%+64px)] top-[530px]">
      <Group22 />
      <Group30 />
      <Group31 />
      <Group32 />
      <Group33 />
      <Group34 />
    </div>
  );
}

function Group28() {
  return (
    <div className="absolute contents left-[calc(16.67%+44px)] top-[511px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[47.49%_4.03%_39.87%_19.58%] rounded-[4px]" />
      <Group29 />
    </div>
  );
}

function Delete1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="delete">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="delete">
          <path d={svgPaths.p10859900} fill="var(--fill-0, white)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-[#e7000b] content-stretch flex gap-[10px] h-[44px] items-center justify-center left-[calc(83.33%-12px)] p-[10px] rounded-[4px] top-[579px] w-[157px]" data-name="Button">
      <Delete1 />
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Delete User</p>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute inset-[3.17%_3.12%_3.13%_3.22%]" data-name="Group">
      <div className="absolute inset-[-1.67%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.2282 23.2401">
          <g id="Group">
            <path d={svgPaths.p31661c03} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
            <path d={svgPaths.pc76f780} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
            <path d={svgPaths.p3f9ea000} id="Vector_3" stroke="var(--stroke-0, white)" strokeWidth="0.75" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function StreamlineUltimateTaskFingerShow1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="streamline-ultimate:task-finger-show">
      <Group1 />
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute bg-[#7f56d8] content-stretch flex gap-[10px] items-center justify-center left-[calc(66.67%+34px)] p-[10px] rounded-[4px] top-[579px] w-[157px]" data-name="Button">
      <StreamlineUltimateTaskFingerShow1 />
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">View Details</p>
      </div>
    </div>
  );
}

function Group42() {
  return (
    <div className="absolute contents left-[calc(16.67%+44px)] top-[511px]">
      <Group28 />
      <Button3 />
      <Button4 />
    </div>
  );
}

function Group37() {
  return (
    <div className="absolute contents left-[calc(25%+52px)] top-[733px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[calc(25%+52px)] text-[#2e2c34] text-[14px] top-[740.61px] w-[411.934px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Mohamed Ahmed Sayed  `}</p>
      </div>
    </div>
  );
}

function Group38() {
  return (
    <div className="absolute contents left-[calc(25%+52px)] top-[764px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(25%+52px)] text-[#2e2c34] text-[14px] top-[771.5px] w-[122px]">
        <p className="leading-[14px] whitespace-pre-wrap">30409220104425</p>
      </div>
    </div>
  );
}

function Group39() {
  return (
    <div className="absolute contents left-[calc(16.67%+105px)] top-[733px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(16.67%+105px)] text-[#2e2c34] text-[14px] top-[740.5px] w-[80px]">
        <p className="leading-[14px] whitespace-pre-wrap">Admin</p>
      </div>
    </div>
  );
}

function Group40() {
  return (
    <div className="absolute contents left-[calc(16.67%+105px)] top-[764px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(16.67%+105px)] text-[#2e2c34] text-[14px] top-[771.5px] w-[80px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`SSN          :`}</p>
      </div>
    </div>
  );
}

function Group44() {
  return (
    <div className="absolute contents left-[calc(16.67%+66px)] top-[695.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[calc(16.67%+105px)] text-[#2e2c34] text-[16px] top-[707.21px] w-[248.745px]">
        <p className="leading-[14px] whitespace-pre-wrap">User ID : 512393207</p>
      </div>
      <div className="absolute left-[calc(16.67%+66px)] size-[22px] top-[695.25px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
          <circle cx="11" cy="11" fill="var(--fill-0, #54C104)" id="Ellipse 931" r="11" />
        </svg>
      </div>
    </div>
  );
}

function Group45() {
  return (
    <div className="absolute contents left-[calc(16.67%+66px)] top-[692px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(83.33%-8px)] text-[#84818a] text-[12px] top-[699.5px] w-[173px]">
        <p className="leading-[14px] whitespace-pre-wrap">Created At 22-11-2024</p>
      </div>
      <div className="absolute h-0 left-[calc(16.67%+66px)] top-[808.68px] w-[1107.47px]" data-name="Line">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1107.47 1">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.5" x2="1106.97" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Group36() {
  return (
    <div className="absolute contents left-[calc(16.67%+66px)] top-[692px]">
      <Group37 />
      <Group38 />
      <Group39 />
      <Group40 />
      <Group44 />
      <Group45 />
    </div>
  );
}

function Group35() {
  return (
    <div className="absolute contents left-[calc(16.67%+46px)] top-[673px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[62.55%_3.9%_24.81%_19.71%] rounded-[4px]" />
      <Group36 />
    </div>
  );
}

function Delete2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="delete">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="delete">
          <path d={svgPaths.p10859900} fill="var(--fill-0, white)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute bg-[#e7000b] content-stretch flex gap-[10px] h-[44px] items-center justify-center left-[calc(83.33%-10px)] p-[10px] rounded-[4px] top-[741px] w-[157px]" data-name="Button">
      <Delete2 />
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Delete User</p>
      </div>
    </div>
  );
}

function Group43() {
  return (
    <div className="absolute contents left-[calc(16.67%+46px)] top-[673px]">
      <Group35 />
      <Button5 />
    </div>
  );
}

function Group51() {
  return (
    <div className="absolute contents left-[calc(25%+54px)] top-[895px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[calc(25%+54px)] text-[#2e2c34] text-[14px] top-[902.61px] w-[411.934px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Mohamed Ahmed Sayed  `}</p>
      </div>
    </div>
  );
}

function Group52() {
  return (
    <div className="absolute contents left-[calc(25%+54px)] top-[926px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(25%+54px)] text-[#2e2c34] text-[14px] top-[933.5px] w-[122px]">
        <p className="leading-[14px] whitespace-pre-wrap">30409220104425</p>
      </div>
    </div>
  );
}

function Group53() {
  return (
    <div className="absolute contents left-[calc(16.67%+107px)] top-[895px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(16.67%+107px)] text-[#2e2c34] text-[14px] top-[902.5px] w-[80px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Student  :`}</p>
      </div>
    </div>
  );
}

function Group54() {
  return (
    <div className="absolute contents left-[calc(16.67%+107px)] top-[926px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(16.67%+107px)] text-[#2e2c34] text-[14px] top-[933.5px] w-[80px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`SSN          :`}</p>
      </div>
    </div>
  );
}

function Group55() {
  return (
    <div className="absolute contents left-[calc(16.67%+68px)] top-[857.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[calc(16.67%+107px)] text-[#2e2c34] text-[16px] top-[869.21px] w-[248.745px]">
        <p className="leading-[14px] whitespace-pre-wrap">User ID : 512393207</p>
      </div>
      <div className="absolute left-[calc(16.67%+68px)] size-[22px] top-[857.25px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
          <circle cx="11" cy="11" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="11" />
        </svg>
      </div>
    </div>
  );
}

function Group56() {
  return (
    <div className="absolute contents left-[calc(16.67%+68px)] top-[854px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(83.33%-6px)] text-[#84818a] text-[12px] top-[861.5px] w-[173px]">
        <p className="leading-[14px] whitespace-pre-wrap">Created At 22-11-2024</p>
      </div>
      <div className="absolute h-0 left-[calc(16.67%+68px)] top-[970.68px] w-[1107.47px]" data-name="Line">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1107.47 1">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.5" x2="1106.97" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Group50() {
  return (
    <div className="absolute contents left-[calc(16.67%+68px)] top-[854px]">
      <Group51 />
      <Group52 />
      <Group53 />
      <Group54 />
      <Group55 />
      <Group56 />
    </div>
  );
}

function Group47() {
  return (
    <div className="absolute contents left-[calc(16.67%+48px)] top-[835px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[77.6%_3.77%_9.76%_19.84%] rounded-[4px]" />
      <Group50 />
    </div>
  );
}

function Delete3() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="delete">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="delete">
          <path d={svgPaths.p10859900} fill="var(--fill-0, white)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="absolute bg-[#e7000b] content-stretch flex gap-[10px] h-[44px] items-center justify-center left-[calc(83.33%-8px)] p-[10px] rounded-[4px] top-[903px] w-[157px]" data-name="Button">
      <Delete3 />
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Delete User</p>
      </div>
    </div>
  );
}

function Group46() {
  return (
    <div className="absolute contents left-[calc(16.67%+48px)] top-[835px]">
      <Group47 />
      <Button6 />
    </div>
  );
}

function InputArea() {
  return <div className="absolute bg-white border border-[#e7e7e7] border-solid h-[115px] left-[calc(66.67%+67px)] rounded-[4px] top-[180px] w-[152px]" data-name="Input Area" />;
}

function ColumnDropDOwn() {
  return (
    <div className="absolute contents left-[calc(66.67%+67px)] top-[180px]" data-name="Column Drop DOwn">
      <InputArea />
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents inset-[18.31%_21.1%_80.3%_73.41%]">
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[18.31%_21.1%_80.3%_73.41%] justify-center leading-[0] text-[#7f56d8] text-[12px]">
        <p className="leading-[normal] whitespace-pre-wrap">Doctor</p>
      </div>
    </div>
  );
}

function Group58() {
  return (
    <div className="absolute contents left-[calc(66.67%+83px)] top-[197px]">
      <div className="absolute left-[calc(66.67%+83px)] size-[14px] top-[198px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
          <circle cx="7" cy="7" fill="var(--fill-0, #3B8AFF)" id="Ellipse 932" r="7" />
        </svg>
      </div>
      <Group11 />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute contents inset-[21.75%_19.58%_76.86%_73.28%]">
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[21.75%_19.58%_76.86%_73.28%] justify-center leading-[0] text-[#84818a] text-[12px]">
        <p className="leading-[normal] whitespace-pre-wrap">Student</p>
      </div>
    </div>
  );
}

function Group59() {
  return (
    <div className="absolute contents left-[calc(66.67%+81px)] top-[234px]">
      <div className="absolute left-[calc(66.67%+81px)] size-[14px] top-[235px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
          <circle cx="7" cy="7" fill="var(--fill-0, #FAC885)" id="Ellipse 933" r="7" />
        </svg>
      </div>
      <Group12 />
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute contents inset-[24.81%_19.97%_73.79%_73.28%]">
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[24.81%_19.97%_73.79%_73.28%] justify-center leading-[0] text-[#84818a] text-[12px]">
        <p className="leading-[normal] whitespace-pre-wrap">Admin</p>
      </div>
    </div>
  );
}

function Group60() {
  return (
    <div className="absolute contents left-[calc(66.67%+81px)] top-[267px]">
      <div className="absolute left-[calc(66.67%+81px)] size-[14px] top-[268px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
          <circle cx="7" cy="7" fill="var(--fill-0, #54C104)" id="Ellipse 934" r="7" />
        </svg>
      </div>
      <Group13 />
    </div>
  );
}

function Group57() {
  return (
    <div className="absolute contents left-[calc(66.67%+67px)] top-[180px]">
      <ColumnDropDOwn />
      <div className="absolute bg-[rgba(127,86,216,0.05)] h-[34px] left-[calc(66.67%+76px)] rounded-[4px] top-[188px] w-[135px]" />
      <Group58 />
      <Group59 />
      <Group60 />
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute contents left-[calc(66.67%+67px)] top-[180px]">
      <Group57 />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute inset-[3.17%_3.12%_3.13%_3.22%]" data-name="Group">
      <div className="absolute inset-[-1.67%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.2282 23.2401">
          <g id="Group">
            <path d={svgPaths.p31661c03} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
            <path d={svgPaths.pc76f780} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
            <path d={svgPaths.p3f9ea000} id="Vector_3" stroke="var(--stroke-0, white)" strokeWidth="0.75" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function StreamlineUltimateTaskFingerShow2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="streamline-ultimate:task-finger-show">
      <Group2 />
    </div>
  );
}

function Button7() {
  return (
    <div className="absolute bg-[#7f56d8] content-stretch flex gap-[10px] items-center justify-center left-[calc(66.67%+34px)] p-[10px] rounded-[4px] top-[741px] w-[157px]" data-name="Button">
      <StreamlineUltimateTaskFingerShow2 />
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">View Details</p>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute inset-[3.17%_3.12%_3.13%_3.22%]" data-name="Group">
      <div className="absolute inset-[-1.67%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.2282 23.2401">
          <g id="Group">
            <path d={svgPaths.p31661c03} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
            <path d={svgPaths.pc76f780} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
            <path d={svgPaths.p3f9ea000} id="Vector_3" stroke="var(--stroke-0, white)" strokeWidth="0.75" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function StreamlineUltimateTaskFingerShow3() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="streamline-ultimate:task-finger-show">
      <Group3 />
    </div>
  );
}

function Button8() {
  return (
    <div className="absolute bg-[#7f56d8] content-stretch flex gap-[10px] items-center justify-center left-[calc(66.67%+34px)] p-[10px] rounded-[4px] top-[903px] w-[157px]" data-name="Button">
      <StreamlineUltimateTaskFingerShow3 />
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">View Details</p>
      </div>
    </div>
  );
}

export default function TicketMain() {
  return (
    <div className="bg-[#f9f9fb] relative size-full" data-name="Ticket Main">
      <Frame1 />
      <Sidebar />
      <Sidebar1 />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-[calc(16.67%+22px)] text-[#2e2c34] text-[24px] top-[125.5px] whitespace-nowrap">
        <p className="leading-[normal]">{`Users `}</p>
      </div>
      <UsersList />
      <SearchInput />
      <Page />
      <TicketGroup />
      <Group41 />
      <Button2 />
      <Group42 />
      <Group43 />
      <Group46 />
      <Group14 />
      <Button7 />
      <Button8 />
    </div>
  );
}