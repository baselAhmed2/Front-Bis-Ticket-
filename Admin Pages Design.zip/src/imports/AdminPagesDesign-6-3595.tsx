import svgPaths from "./svg-x8fykqtpoi";

function Heading() {
  return (
    <div className="h-[36px] relative shrink-0 w-[162.463px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[36px] left-0 text-[#2e2c34] text-[24px] top-[-0.8px] uppercase">Ticket Lead</p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="h-[104px] relative shrink-0 w-[248.2px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center pl-[32px] relative size-full">
        <Heading />
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
          <g id="Group">
            <path clipRule="evenodd" d={svgPaths.p2e5f1780} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" id="Vector" />
            <path clipRule="evenodd" d={svgPaths.p2790ea00} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" id="Vector_2" />
            <path clipRule="evenodd" d={svgPaths.p31649600} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" id="Vector_3" />
            <path clipRule="evenodd" d={svgPaths.p2fed3000} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" id="Vector_4" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[24px] relative shrink-0 w-[89.55px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[45px] text-[#2e2c34] text-[16px] text-center top-[0.4px]">Dashboard</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[14px] items-center pl-[32px] relative size-full">
          <Container1 />
          <Text />
        </div>
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p1ff1d2f0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.36364" />
          <path d={svgPaths.p91033f0} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.909091" />
        </g>
      </svg>
    </div>
  );
}

function Container2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[24px] relative shrink-0 w-[56.838px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[28.5px] text-[#2e2c34] text-[16px] text-center top-[0.4px]">Tickets</p>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[14px] items-center pl-[32px] relative size-full">
          <Container2 />
          <Text1 />
        </div>
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[0_5.71%]" data-name="Group">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9433 20">
        <g id="Group">
          <path clipRule="evenodd" d={svgPaths.p1dfa98f0} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" id="Vector" />
          <path clipRule="evenodd" d={svgPaths.p3094ef0} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Icon2() {
  return (
    <div className="h-[20px] relative shrink-0 w-[18px]" data-name="Icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <Group />
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="h-[20px] relative shrink-0 w-[18px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon2 />
      </div>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[24px] relative shrink-0 w-[45.038px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[23px] text-[#2e2c34] text-[16px] text-center top-[0.4px]">Users</p>
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[14px] items-center pl-[32px] relative size-full">
          <Container3 />
          <Text2 />
        </div>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="h-[18px] relative shrink-0 w-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 18">
        <g clipPath="url(#clip0_6_3067)" id="Icon">
          <path d={svgPaths.p17b07800} id="Vector" stroke="var(--stroke-0, #7F56D8)" strokeWidth="1.73077" />
        </g>
        <defs>
          <clipPath id="clip0_6_3067">
            <rect fill="white" height="18" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[18px] relative shrink-0 w-[20px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon3 />
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[24px] relative shrink-0 w-[94.338px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.5px] text-[#7f56d8] text-[16px] text-center top-[0.4px]">Add Course</p>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[rgba(127,86,216,0.1)] h-[48px] relative shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[14px] items-center pl-[32px] relative size-full">
          <Container4 />
          <Text3 />
        </div>
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p5d04380} fill="var(--fill-0, #2E2C34)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Container5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon4 />
      </div>
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[24px] relative shrink-0 w-[65.975px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[33px] text-[#2e2c34] text-[16px] text-center top-[0.4px]">Analysis</p>
      </div>
    </div>
  );
}

function Button4() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[14px] items-center pl-[32px] relative size-full">
          <Container5 />
          <Text4 />
        </div>
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="h-[19px] relative shrink-0 w-[18px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 19">
        <g clipPath="url(#clip0_6_3064)" id="Icon">
          <path d={svgPaths.p24e18e30} fill="var(--fill-0, #2E2C34)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_6_3064">
            <rect fill="white" height="19" width="18" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[19px] relative shrink-0 w-[18px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon5 />
      </div>
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[24px] relative shrink-0 w-[58.225px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[29.5px] text-[#2e2c34] text-[16px] text-center top-[0.4px]">Logout</p>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[14px] items-center pl-[32px] relative size-full">
          <Container6 />
          <Text5 />
        </div>
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[248.2px]" data-name="Navigation">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[8px] relative size-full">
        <Button />
        <Button1 />
        <Button2 />
        <Button3 />
        <Button4 />
        <Button5 />
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p26b9fc90} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.36364" />
          <path d={svgPaths.p7630580} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.36364" />
        </g>
      </svg>
    </div>
  );
}

function Container7() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon6 />
      </div>
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[24px] relative shrink-0 w-[102.013px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[51.5px] text-[#2e2c34] text-[16px] text-center top-[0.4px]">Site Settings</p>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[48px] relative shrink-0 w-[248.2px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[14px] items-center pl-[32px] relative size-full">
        <Container7 />
        <Text6 />
      </div>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[729.6px] items-start left-0 pb-[24px] pr-[0.8px] top-0 w-[249px]" data-name="Sidebar">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-r-[0.8px] border-solid inset-0 pointer-events-none" />
      <Container />
      <Navigation />
      <Button6 />
    </div>
  );
}

function Container8() {
  return <div className="absolute left-[1157.6px] size-0 top-[80px]" data-name="Container" />;
}

function Heading1() {
  return (
    <div className="h-[36px] relative shrink-0 w-[98.525px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[36px] left-0 text-[#2e2c34] text-[24px] top-[-0.8px]">Courses</p>
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M4.16667 10H15.8333" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M10 4.16667V15.8333" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Text7() {
  return (
    <div className="h-[21px] relative shrink-0 w-[83.775px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[21px] left-[42px] text-[14px] text-center text-white top-[-0.4px]">Add Course</p>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div className="bg-[#7f56d8] h-[41px] relative rounded-[10px] shrink-0 w-[143.775px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center justify-center relative size-full">
        <Icon7 />
        <Text7 />
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute content-stretch flex h-[41px] items-center justify-between left-[273px] top-[59px] w-[860.6px]" data-name="Container">
      <Heading1 />
      <Button7 />
    </div>
  );
}

function TextInput() {
  return (
    <div className="bg-[#fbfbfb] flex-[1_0_0] h-[42.6px] min-h-px min-w-px relative rounded-[4px]" data-name="Text Input">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center px-[16px] py-[10px] relative size-full">
          <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] relative shrink-0 text-[14px] text-[rgba(10,10,10,0.5)]">Search courses...</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[0.8px] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute content-stretch flex h-[42.6px] items-start left-[273px] top-[123px] w-[860.6px]" data-name="Container">
      <TextInput />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[27px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[27px] left-0 text-[#2e2c34] text-[18px] top-[-1.4px]">Information System</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[21px] left-0 text-[#84818a] text-[14px] top-[-0.4px]">Course ID: BIs123</p>
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[56px] items-start left-0 top-0 w-[612.025px]" data-name="Container">
      <Heading2 />
      <Paragraph />
    </div>
  );
}

function Container16() {
  return <div className="bg-[#f8a534] rounded-[26843500px] shrink-0 size-[12px]" data-name="Container" />;
}

function Text8() {
  return (
    <div className="flex-[1_0_0] h-[21px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[21px] left-0 text-[#757575] text-[14px] top-[-0.4px]">Level 4</p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[21px] relative shrink-0 w-[69.875px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Container16 />
        <Text8 />
      </div>
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p32887f80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p3694d280} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M12.6667 5.33333V9.33333" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14.6667 7.33333H10.6667" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text9() {
  return (
    <div className="h-[18px] relative shrink-0 w-[71.1px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[18px] left-[36px] text-[12px] text-center text-white top-[-0.2px]">Add Doctor</p>
      </div>
    </div>
  );
}

function Button8() {
  return (
    <div className="bg-[#7f56d8] h-[30px] relative rounded-[4px] shrink-0 w-[117.1px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center pl-[12px] relative size-full">
        <Icon8 />
        <Text9 />
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="absolute content-stretch flex gap-[12px] h-[30px] items-center left-[612.03px] top-0 w-[198.975px]" data-name="Container">
      <Container15 />
      <Button8 />
    </div>
  );
}

function Container12() {
  return (
    <div className="h-[56px] relative shrink-0 w-full" data-name="Container">
      <Container13 />
      <Container14 />
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[217.613px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[19.5px] left-0 text-[#84818a] text-[13px] top-[0.6px]">3 Doctor(s) Assigned • Semester 1</p>
      </div>
    </div>
  );
}

function Button9() {
  return (
    <div className="h-[21px] relative shrink-0 w-[87.588px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[21px] left-[44px] text-[#7f56d8] text-[14px] text-center top-[-0.4px]">View Details</p>
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="content-stretch flex h-[21px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Paragraph1 />
      <Button9 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full">
      <Container12 />
      <Container17 />
    </div>
  );
}

function Container11() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[142.6px] items-start left-[273px] pb-[0.8px] pt-[24.8px] px-[24.8px] rounded-[10px] top-[196px] w-[860.6px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[0.8px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <Frame />
    </div>
  );
}

function Heading3() {
  return (
    <div className="h-[27px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[27px] left-0 text-[#2e2c34] text-[18px] top-[-1.4px]">Data Structures</p>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[21px] left-0 text-[#84818a] text-[14px] top-[-0.4px]">Course ID: CS456</p>
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[56px] items-start left-0 top-0 w-[613.375px]" data-name="Container">
      <Heading3 />
      <Paragraph2 />
    </div>
  );
}

function Container23() {
  return <div className="bg-[#f8a534] rounded-[26843500px] shrink-0 size-[12px]" data-name="Container" />;
}

function Text10() {
  return (
    <div className="flex-[1_0_0] h-[21px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[21px] left-0 text-[#757575] text-[14px] top-[-0.4px]">Level 3</p>
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="h-[21px] relative shrink-0 w-[68.525px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Container23 />
        <Text10 />
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p32887f80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p3694d280} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M12.6667 5.33333V9.33333" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14.6667 7.33333H10.6667" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text11() {
  return (
    <div className="h-[18px] relative shrink-0 w-[71.1px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[18px] left-[36px] text-[12px] text-center text-white top-[-0.2px]">Add Doctor</p>
      </div>
    </div>
  );
}

function Button10() {
  return (
    <div className="bg-[#7f56d8] h-[30px] relative rounded-[4px] shrink-0 w-[117.1px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center pl-[12px] relative size-full">
        <Icon9 />
        <Text11 />
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="absolute content-stretch flex gap-[12px] h-[30px] items-center left-[613.38px] top-0 w-[197.625px]" data-name="Container">
      <Container22 />
      <Button10 />
    </div>
  );
}

function Container19() {
  return (
    <div className="h-[56px] relative shrink-0 w-full" data-name="Container">
      <Container20 />
      <Container21 />
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[221.5px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[19.5px] left-0 text-[#84818a] text-[13px] top-[0.6px]">0 Doctor(s) Assigned • Semester 2</p>
      </div>
    </div>
  );
}

function Button11() {
  return (
    <div className="h-[21px] relative shrink-0 w-[87.588px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[21px] left-[44px] text-[#7f56d8] text-[14px] text-center top-[-0.4px]">View Details</p>
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="content-stretch flex h-[21px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Paragraph3 />
      <Button11 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full">
      <Container19 />
      <Container24 />
    </div>
  );
}

function Container18() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[142.6px] items-start left-[273px] pb-[0.8px] pt-[24.8px] px-[24.8px] rounded-[10px] top-[354.6px] w-[860.6px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[0.8px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <Frame1 />
    </div>
  );
}

export default function AdminPagesDesign() {
  return (
    <div className="bg-white relative size-full" data-name="Admin Pages Design">
      <Sidebar />
      <Container8 />
      <Container9 />
      <Container10 />
      <Container11 />
      <Container18 />
    </div>
  );
}