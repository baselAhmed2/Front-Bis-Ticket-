import svgPaths from "./svg-rb5f0ac4t9";
import imgEllipse73 from "figma:asset/ffc5edd5df1e034f97f1621e2ca2d4e33201613f.png";

function Group36() {
  return (
    <div className="absolute contents left-0 top-[330px]">
      <div className="absolute bg-[rgba(127,86,216,0.1)] h-[45px] left-0 top-[330px] w-[249px]" />
    </div>
  );
}

function AlignLeft() {
  return (
    <div className="absolute left-[20px] size-[30px] top-[27px]" data-name="align-left">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="align-left">
          <path d="M22.5 14.5H5" id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 7.5H5" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 21.5H5" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <div className="relative shrink-0 size-[48px]">
        <img alt="" className="absolute block max-w-none size-full" height="48" src={imgEllipse73} width="48" />
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#1a202c] text-[16px] whitespace-nowrap">
        <p className="leading-[normal]">Alex Robert</p>
      </div>
    </div>
  );
}

function User() {
  return (
    <div className="absolute bg-[#fafafa] content-stretch flex gap-[12px] h-[56px] items-center left-[1019px] pl-[5px] pr-[18px] py-[12px] rounded-[1000px] top-[14px]" data-name="user">
      <Frame />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[20px] top-[14px]">
      <AlignLeft />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[63px] text-[#2e2c34] text-[18px] top-[31px]">{`Welcome! `}</p>
      <User />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[calc(8.33%+123px)] top-0 w-[1263px]">
      <div className="h-[85px] relative shrink-0 w-full" data-name="Top Bar">
        <div className="absolute bg-white h-[85px] left-0 shadow-[0px_4px_40px_1px_rgba(0,0,0,0.03)] top-0 w-[1263px]" />
        <Group3 />
      </div>
    </div>
  );
}

function InputArea() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[122px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] left-1/2 text-[14px] text-black text-center top-1/2 w-[50px]">
        <p className="leading-[normal] whitespace-pre-wrap">9</p>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[787px] top-[134px] w-[125px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] text-center w-full">
        <p className="leading-[normal] whitespace-pre-wrap">{`Total Tickets `}</p>
      </div>
      <InputArea />
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents left-[149.6px] top-[164px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[149.6px] text-[#2e2c34] text-[14px] top-[171.61px] w-[379.479px]">
        <p className="leading-[14px] whitespace-pre-wrap">Mohamed Abdelsalam</p>
      </div>
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute contents left-[82.35px] top-[164px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[14px] top-[171.5px] w-[73.697px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Name  :`}</p>
      </div>
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents left-[46.42px] top-[126.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[16px] top-[138.21px] w-[229.147px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Doctor ID :   122`}</p>
      </div>
      <div className="absolute h-[22px] left-[46.42px] top-[126.25px] w-[20.267px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.2667 22">
          <ellipse cx="10.1333" cy="11" fill="var(--fill-0, #3B8AFF)" id="Ellipse 931" rx="10.1333" ry="11" />
        </svg>
      </div>
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute h-0 left-[46.42px] top-[239.68px] w-[1020.215px]">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1020.22 1">
          <g id="Group 1000004235">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.500146" x2="1019.72" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute contents left-[46.42px] top-[126.25px]">
      <Group9 />
      <Group15 />
      <Group11 />
      <Group12 />
    </div>
  );
}

function InputArea1() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[122px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] left-1/2 text-[14px] text-black text-center top-1/2 w-[50px]">
        <p className="leading-[normal] whitespace-pre-wrap">9</p>
      </div>
    </div>
  );
}

function Content1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[948px] top-[134px] w-[125px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] text-center w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Closed</p>
      </div>
      <InputArea1 />
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute contents left-[28px] top-[104px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[13.1%_8.54%_69.77%_2.35%] rounded-[4px]" />
      <Content />
      <Group13 />
      <Content1 />
    </div>
  );
}

function Group29() {
  return (
    <div className="absolute contents left-[28px] top-[104px]">
      <Group14 />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[149.6px] top-[624px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[149.6px] text-[#2e2c34] text-[14px] top-[631.61px] w-[379.479px]">
        <p className="leading-[14px] whitespace-pre-wrap">Mohamed Abdelsalam</p>
      </div>
    </div>
  );
}

function Group18() {
  return (
    <div className="absolute contents left-[82.35px] top-[624px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[14px] top-[631.5px] w-[73.697px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Name  :`}</p>
      </div>
    </div>
  );
}

function Group19() {
  return (
    <div className="absolute contents left-[46.42px] top-[586.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[16px] top-[598.21px] w-[229.147px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Doctor ID :   122`}</p>
      </div>
      <div className="absolute h-[22px] left-[46.42px] top-[586.25px] w-[20.267px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.2667 22">
          <ellipse cx="10.1333" cy="11" fill="var(--fill-0, #3B8AFF)" id="Ellipse 931" rx="10.1333" ry="11" />
        </svg>
      </div>
    </div>
  );
}

function Group20() {
  return (
    <div className="absolute h-0 left-[46.42px] top-[699.68px] w-[1020.215px]">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1020.22 1">
          <g id="Group 1000004235">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.500146" x2="1019.72" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute contents left-[46.42px] top-[586.25px]">
      <Group10 />
      <Group18 />
      <Group19 />
      <Group20 />
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute contents left-[28px] top-[564px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[71.03%_8.54%_11.84%_2.35%] rounded-[4px]" />
      <Group17 />
    </div>
  );
}

function InputArea2() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[122px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] left-1/2 text-[14px] text-black text-center top-1/2 w-[50px]">
        <p className="leading-[normal] whitespace-pre-wrap">9</p>
      </div>
    </div>
  );
}

function Content2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[775px] top-[594px] w-[125px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] text-center w-full">
        <p className="leading-[normal] whitespace-pre-wrap">{`Total Tickets `}</p>
      </div>
      <InputArea2 />
    </div>
  );
}

function InputArea3() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[122px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] left-1/2 text-[14px] text-black text-center top-1/2 w-[50px]">
        <p className="leading-[normal] whitespace-pre-wrap">9</p>
      </div>
    </div>
  );
}

function Content3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[936px] top-[594px] w-[125px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] text-center w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Closed</p>
      </div>
      <InputArea3 />
    </div>
  );
}

function Group32() {
  return (
    <div className="absolute contents left-[28px] top-[564px]">
      <Group16 />
      <Content2 />
      <Content3 />
    </div>
  );
}

function Group23() {
  return (
    <div className="absolute contents left-[149.6px] top-[326px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[149.6px] text-[#2e2c34] text-[14px] top-[333.61px] w-[379.479px]">
        <p className="leading-[14px] whitespace-pre-wrap">Mohamed Abdelsalam</p>
      </div>
    </div>
  );
}

function Group24() {
  return (
    <div className="absolute contents left-[82.35px] top-[326px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[14px] top-[333.5px] w-[73.697px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Name  :`}</p>
      </div>
    </div>
  );
}

function Group25() {
  return (
    <div className="absolute contents left-[46.42px] top-[288.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[16px] top-[300.21px] w-[229.147px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Doctor ID :   122`}</p>
      </div>
      <div className="absolute h-[22px] left-[46.42px] top-[288.25px] w-[20.267px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.2667 22">
          <ellipse cx="10.1333" cy="11" fill="var(--fill-0, #3B8AFF)" id="Ellipse 931" rx="10.1333" ry="11" />
        </svg>
      </div>
    </div>
  );
}

function Group26() {
  return (
    <div className="absolute h-0 left-[46.42px] top-[401.68px] w-[1020.215px]">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1020.22 1">
          <g id="Group 1000004235">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.500146" x2="1019.72" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group22() {
  return (
    <div className="absolute contents left-[46.42px] top-[288.25px]">
      <Group23 />
      <Group24 />
      <Group25 />
      <Group26 />
    </div>
  );
}

function Group21() {
  return (
    <div className="absolute contents left-[28px] top-[266px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[33.5%_8.54%_49.37%_2.35%] rounded-[4px]" />
      <Group22 />
    </div>
  );
}

function Group30() {
  return (
    <div className="absolute contents left-[28px] top-[266px]">
      <Group21 />
    </div>
  );
}

function Group31() {
  return (
    <div className="absolute contents left-[149.6px] top-[786px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[149.6px] text-[#2e2c34] text-[14px] top-[793.61px] w-[379.479px]">
        <p className="leading-[14px] whitespace-pre-wrap">Mohamed Abdelsalam</p>
      </div>
    </div>
  );
}

function Group34() {
  return (
    <div className="absolute contents left-[82.35px] top-[786px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[14px] top-[793.5px] w-[73.697px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Name  :`}</p>
      </div>
    </div>
  );
}

function Group35() {
  return (
    <div className="absolute contents left-[46.42px] top-[748.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[16px] top-[760.21px] w-[229.147px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Doctor ID :   122`}</p>
      </div>
      <div className="absolute h-[22px] left-[46.42px] top-[748.25px] w-[20.267px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.2667 22">
          <ellipse cx="10.1333" cy="11" fill="var(--fill-0, #3B8AFF)" id="Ellipse 931" rx="10.1333" ry="11" />
        </svg>
      </div>
    </div>
  );
}

function Group37() {
  return (
    <div className="absolute h-0 left-[46.42px] top-[861.68px] w-[1020.215px]">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1020.22 1">
          <g id="Group 1000004235">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.500146" x2="1019.72" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group28() {
  return (
    <div className="absolute contents left-[46.42px] top-[748.25px]">
      <Group31 />
      <Group34 />
      <Group35 />
      <Group37 />
    </div>
  );
}

function Group27() {
  return (
    <div className="absolute contents left-[28px] top-[726px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[91.44%_8.54%_-8.56%_2.35%] rounded-[4px]" />
      <Group28 />
    </div>
  );
}

function Group33() {
  return (
    <div className="absolute contents left-[28px] top-[726px]">
      <Group27 />
    </div>
  );
}

function Group41() {
  return (
    <div className="absolute contents left-[149.6px] top-[488px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[149.6px] text-[#2e2c34] text-[14px] top-[495.61px] w-[379.479px]">
        <p className="leading-[14px] whitespace-pre-wrap">Mohamed Abdelsalam</p>
      </div>
    </div>
  );
}

function Group42() {
  return (
    <div className="absolute contents left-[82.35px] top-[488px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[14px] top-[495.5px] w-[73.697px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Name  :`}</p>
      </div>
    </div>
  );
}

function Group43() {
  return (
    <div className="absolute contents left-[46.42px] top-[450.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[16px] top-[462.21px] w-[229.147px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Doctor ID :   122`}</p>
      </div>
      <div className="absolute h-[22px] left-[46.42px] top-[450.25px] w-[20.267px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.2667 22">
          <ellipse cx="10.1333" cy="11" fill="var(--fill-0, #3B8AFF)" id="Ellipse 931" rx="10.1333" ry="11" />
        </svg>
      </div>
    </div>
  );
}

function Group44() {
  return (
    <div className="absolute h-0 left-[46.42px] top-[563.68px] w-[1020.215px]">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1020.22 1">
          <g id="Group 1000004235">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.500146" x2="1019.72" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group40() {
  return (
    <div className="absolute contents left-[46.42px] top-[450.25px]">
      <Group41 />
      <Group42 />
      <Group43 />
      <Group44 />
    </div>
  );
}

function Group39() {
  return (
    <div className="absolute contents left-[28px] top-[428px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[53.9%_8.54%_28.97%_2.35%] rounded-[4px]" />
      <Group40 />
    </div>
  );
}

function InputArea4() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[122px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] left-1/2 text-[14px] text-black text-center top-1/2 w-[50px]">
        <p className="leading-[normal] whitespace-pre-wrap">9</p>
      </div>
    </div>
  );
}

function Content4() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[778px] top-[458px] w-[125px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] text-center w-full">
        <p className="leading-[normal] whitespace-pre-wrap">{`Total Tickets `}</p>
      </div>
      <InputArea4 />
    </div>
  );
}

function InputArea5() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[122px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] left-1/2 text-[14px] text-black text-center top-1/2 w-[50px]">
        <p className="leading-[normal] whitespace-pre-wrap">9</p>
      </div>
    </div>
  );
}

function Content5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[939px] top-[458px] w-[125px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] text-center w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Closed</p>
      </div>
      <InputArea5 />
    </div>
  );
}

function Group38() {
  return (
    <div className="absolute contents left-[28px] top-[428px]">
      <Group39 />
      <Content4 />
      <Content5 />
    </div>
  );
}

function Group48() {
  return (
    <div className="absolute contents left-[149.6px] top-[948px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[149.6px] text-[#2e2c34] text-[14px] top-[955.61px] w-[379.479px]">
        <p className="leading-[14px] whitespace-pre-wrap">Mohamed Abdelsalam</p>
      </div>
    </div>
  );
}

function Group49() {
  return (
    <div className="absolute contents left-[82.35px] top-[948px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[14px] top-[955.5px] w-[73.697px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Name  :`}</p>
      </div>
    </div>
  );
}

function Group50() {
  return (
    <div className="absolute contents left-[46.42px] top-[910.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[82.35px] text-[#2e2c34] text-[16px] top-[922.21px] w-[229.147px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Doctor ID :   122`}</p>
      </div>
      <div className="absolute h-[22px] left-[46.42px] top-[910.25px] w-[20.267px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.2667 22">
          <ellipse cx="10.1333" cy="11" fill="var(--fill-0, #3B8AFF)" id="Ellipse 931" rx="10.1333" ry="11" />
        </svg>
      </div>
    </div>
  );
}

function Group51() {
  return (
    <div className="absolute h-0 left-[46.42px] top-[1023.68px] w-[1020.215px]">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1020.22 1">
          <g id="Group 1000004235">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.500146" x2="1019.72" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group47() {
  return (
    <div className="absolute contents left-[46.42px] top-[910.25px]">
      <Group48 />
      <Group49 />
      <Group50 />
      <Group51 />
    </div>
  );
}

function Group46() {
  return (
    <div className="absolute contents left-[28px] top-[888px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[111.84%_8.54%_-28.97%_2.35%] rounded-[4px]" />
      <Group47 />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#e7000b] content-stretch flex gap-[10px] h-[44px] items-center justify-center left-[851px] p-[10px] rounded-[4px] top-[932px] w-[143px]" data-name="Button">
      <div className="overflow-clip relative shrink-0 size-[24px]" data-name="delete">
        <div className="absolute inset-[12.5%_16.67%]" data-name="icon">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 18">
            <path d={svgPaths.p3dc18500} fill="var(--fill-0, white)" id="icon" />
          </svg>
        </div>
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Delete User</p>
      </div>
    </div>
  );
}

function Group45() {
  return (
    <div className="absolute contents left-[28px] top-[888px]">
      <Group46 />
      <Button />
    </div>
  );
}

function InputArea6() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[122px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] left-1/2 text-[14px] text-black text-center top-1/2 w-[50px]">
        <p className="leading-[normal] whitespace-pre-wrap">9</p>
      </div>
    </div>
  );
}

function Content6() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[781px] top-[296px] w-[125px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] text-center w-full">
        <p className="leading-[normal] whitespace-pre-wrap">{`Total Tickets `}</p>
      </div>
      <InputArea6 />
    </div>
  );
}

function InputArea7() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[122px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] left-1/2 text-[14px] text-black text-center top-1/2 w-[50px]">
        <p className="leading-[normal] whitespace-pre-wrap">9</p>
      </div>
    </div>
  );
}

function Content7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[942px] top-[296px] w-[125px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] text-center w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Closed</p>
      </div>
      <InputArea7 />
    </div>
  );
}

function UsersList() {
  return (
    <div className="absolute h-[794px] left-[calc(8.33%+123px)] overflow-clip rounded-[4px] top-[166px] w-[1194px]" data-name="Users List">
      <div className="absolute h-[904px] left-0 rounded-[4px] top-0 w-[1194px]" data-name="card">
        <div className="absolute bg-white inset-0 rounded-[4px]" />
      </div>
      <Group29 />
      <Group32 />
      <Group30 />
      <Group33 />
      <Group38 />
      <Group45 />
      <Content6 />
      <Content7 />
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute h-[0.151px] left-[calc(16.67%+38px)] top-[237.1px] w-[1154.999px]">
      <div className="absolute inset-[-1891.91%_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1155 3.00023">
          <g id="Group 1000004229">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.503906" x2="1154.5" y1="2.34938" y2="2.34938" />
            <line id="Line_2" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeWidth="3" x1="1.5" x2="108.027" y1="1.5" y2="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents left-[calc(16.67%+72px)] top-[214.2px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[8.435px] justify-center leading-[0] left-[calc(16.67%+72px)] text-[#7f56d8] text-[14px] top-[218.42px] w-[51px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Level 1 `}</p>
      </div>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[calc(25%+74px)] top-[213px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[8.435px] justify-center leading-[0] left-[calc(25%+83px)] text-[#84818a] text-[14px] top-[218.42px] w-[54px]">
        <p className="leading-[14px] whitespace-pre-wrap">Level 2</p>
      </div>
      <div className="absolute h-[12.05px] left-[calc(25%+74px)] top-[213px] w-[20.052px]" data-name="sms-notification" />
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents font-['Montserrat:Medium',sans-serif] font-medium leading-[0] left-[calc(33.33%+97px)] text-[#84818a] text-[14px] top-[213.6px]">
      <div className="-translate-y-1/2 absolute flex flex-col h-[7.832px] justify-center left-[calc(33.33%+97px)] top-[218.72px] w-[70.182px]">
        <p className="leading-[14px] whitespace-pre-wrap">Level 3</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[7.832px] justify-center left-[calc(50%+2px)] top-[217.52px] w-[70.182px]">
        <p className="leading-[14px] whitespace-pre-wrap">Level 3</p>
      </div>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[calc(16.67%+72px)] top-[213px]">
      <Group4 />
      <Group6 />
      <Group5 />
    </div>
  );
}

function TicketGroup() {
  return (
    <div className="absolute contents left-[calc(16.67%+38px)] top-[213px]" data-name="Ticket Group">
      <Group8 />
      <Group7 />
    </div>
  );
}

function Category() {
  return (
    <div className="absolute inset-[8.33%_10.42%_10.42%_8.33%]" data-name="Category">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.3624 17.875">
        <g id="Category">
          <path clipRule="evenodd" d={svgPaths.p16928b40} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 1" />
          <path clipRule="evenodd" d={svgPaths.pad4fc40} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 3" />
          <path clipRule="evenodd" d={svgPaths.p3f195280} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 5" />
          <path clipRule="evenodd" d={svgPaths.p3ef5d800} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 7" />
        </g>
      </svg>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[16.33px] top-[116px]">
      <div className="absolute inset-[10.78%_83.53%_87.17%_7.63%]" data-name="Iconly/Light-Outline/Category">
        <Category />
      </div>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[51px] text-[#7f56d8] text-[16px] top-[117px]">Dashboard</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[52px] top-[174px]">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[52px] text-[#2e2c34] text-[16px] top-[174px]">Tickets</p>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[8.33%_17.33%_8.87%_16.67%]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.479 18.2145">
        <g id="Group 6">
          <g id="Union">
            <path clipRule="evenodd" d={svgPaths.p20125980} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p1742e600} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Profile() {
  return (
    <div className="absolute contents inset-[8.33%_17.33%_8.87%_16.67%]" data-name="Profile">
      <Group />
    </div>
  );
}

function IconsaxLinearTicketstar() {
  return (
    <div className="absolute left-[20px] size-[22px] top-[173px]" data-name="Iconsax/Linear/ticketstar">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/ticketstar">
          <path d={svgPaths.p388172f0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p19372c00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function UimAnalytics() {
  return (
    <div className="absolute left-[22px] size-[19px] top-[342px]" data-name="uim:analytics">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19">
        <g id="uim:analytics">
          <path d={svgPaths.pe4b5000} fill="var(--fill-0, #1E1E1E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute h-[1076px] left-0 top-0 w-[214px]" data-name="Sidebar">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[35px] text-[#2e2c34] text-[24px] top-[28px] uppercase">Ticket Lead</p>
      <Group2 />
      <Group1 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[51px] text-[#2e2c34] text-[16px] top-[230px]">{`Users `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[49px] text-[#2e2c34] text-[16px] top-[286px]">{`Add Course `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium h-[19px] leading-[normal] left-[54px] text-[#2e2c34] text-[16px] top-[342px] w-[95px] whitespace-pre-wrap">{`Analysis `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[53px] text-[#2e2c34] text-[16px] top-[399px]">Logout</p>
      <div className="absolute left-[22px] size-[22px] top-[397px]" data-name="material-symbols:logout-rounded">
        <div className="absolute inset-[12.5%_14.17%_12.5%_12.5%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.1333 16.5">
            <path d={svgPaths.p25f94200} fill="var(--fill-0, #1E1E1E)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[21.28%_83.53%_76.67%_7.63%]" data-name="Iconly/Light-Outline/Profile">
        <Profile />
      </div>
      <IconsaxLinearTicketstar />
      <UimAnalytics />
      <div className="absolute inset-[26.86%_84.81%_71.96%_8.84%]" data-name="Vector">
        <div className="absolute inset-[-5.92%_-5.51%_-12.09%_-5.51%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.1078 14.9476">
            <path d={svgPaths.p20209f40} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

export default function TicketMain() {
  return (
    <div className="bg-[#f9f9fb] relative size-full" data-name="Ticket Main">
      <Group36 />
      <Frame1 />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-[calc(16.67%+22px)] text-[#2e2c34] text-[24px] top-[125.5px] whitespace-nowrap">
        <p className="leading-[normal]">Most Doctors Get Tickts</p>
      </div>
      <UsersList />
      <TicketGroup />
      <Sidebar />
    </div>
  );
}