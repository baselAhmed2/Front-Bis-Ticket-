import svgPaths from "./svg-twjepa4tlm";

function Heading1() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-[98.495px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[32px] left-0 text-[#2e2c34] text-[24px] top-[-0.82px]">Courses</p>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="h-[19.99px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/2 left-[20.83%] right-[20.83%] top-1/2" data-name="Vector">
        <div className="absolute inset-[-0.83px_-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.327 1.66587">
            <path d="M0.832935 0.832935H12.494" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-[20.83%] left-1/2 right-1/2 top-[20.83%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-0.83px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.66587 13.327">
            <path d="M0.832935 0.832935V12.494" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#7f56d8] relative rounded-[10px] shrink-0 size-[35.961px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[7.985px] px-[7.985px] relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="h-[35.961px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between relative size-full">
          <Heading1 />
          <Button />
        </div>
      </div>
    </div>
  );
}

function Heading2() {
  return (
    <div className="absolute h-[24.011px] left-[17.17px] top-[17.17px] w-[304.282px]" data-name="Heading 3">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[24px] left-0 text-[#0a0a0a] text-[16px] top-[0.36px]">Course Information</p>
    </div>
  );
}

function Label() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#2e2a40] text-[14px] top-[0.18px]">Course ID</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="bg-white h-[46.325px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="absolute font-['Arial:Regular',sans-serif] leading-[20px] left-[17.17px] not-italic text-[#757575] text-[14px] top-[11.17px]">BIs123</p>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex flex-col gap-[3.983px] h-[70.298px] items-start relative shrink-0 w-full" data-name="Container">
      <Label />
      <Container4 />
    </div>
  );
}

function Label1() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#2e2a40] text-[14px] top-[0.18px]">Student Name</p>
    </div>
  );
}

function Container6() {
  return (
    <div className="bg-white h-[46.325px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="absolute font-['Arial:Regular',sans-serif] leading-[20px] left-[17.17px] not-italic text-[#757575] text-[14px] top-[11.17px]">Information System</p>
    </div>
  );
}

function Container5() {
  return (
    <div className="content-stretch flex flex-col gap-[3.983px] h-[70.298px] items-start relative shrink-0 w-full" data-name="Container">
      <Label1 />
      <Container6 />
    </div>
  );
}

function Label2() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#2e2a40] text-[14px] top-[0.18px]">Course</p>
    </div>
  );
}

function Container9() {
  return <div className="absolute bg-[#f8a534] left-[17.17px] opacity-60 rounded-[39602500px] size-[11.987px] top-[17.17px]" data-name="Container" />;
}

function Container8() {
  return (
    <div className="bg-white h-[46.325px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container9 />
      <p className="absolute font-['Arial:Regular',sans-serif] leading-[20px] left-[37.14px] not-italic text-[#757575] text-[14px] top-[11.17px]">Level 4</p>
    </div>
  );
}

function Container7() {
  return (
    <div className="content-stretch flex flex-col gap-[3.983px] h-[70.298px] items-start relative shrink-0 w-full" data-name="Container">
      <Label2 />
      <Container8 />
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[11.987px] h-[234.869px] items-start left-[17.17px] top-[57.17px] w-[304.282px]" data-name="Container">
      <Container3 />
      <Container5 />
      <Container7 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="absolute h-[24.011px] left-[17.17px] top-[316.03px] w-[304.282px]" data-name="Heading 3">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[24px] left-0 text-[#0a0a0a] text-[16px] top-[0.36px]">Assigned Doctors</p>
    </div>
  );
}

function Label3() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#2e2a40] text-[14px] top-[0.18px]">Doctor ID</p>
    </div>
  );
}

function TextInput() {
  return (
    <div className="bg-white h-[46.325px] relative rounded-[4px] shrink-0 w-full" data-name="Text Input">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center px-[16px] py-[12px] relative size-full">
          <p className="font-['Arial:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[14px] text-[rgba(117,117,117,0.5)]">Enter Doctor ID</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Container11() {
  return (
    <div className="content-stretch flex flex-col gap-[3.983px] h-[70.298px] items-start relative shrink-0 w-full" data-name="Container">
      <Label3 />
      <TextInput />
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#7f56d8] h-[39.981px] relative rounded-[4px] shrink-0 w-full" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[24px] left-[135.86px] text-[16px] text-center text-white top-[8.35px]">Save</p>
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute bg-[#fcfcfc] content-stretch flex flex-col gap-[11.987px] h-[156.604px] items-start left-[17.17px] pb-[1.18px] pt-[17.169px] px-[17.169px] rounded-[10px] top-[356.03px] w-[304.282px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <Container11 />
      <Button1 />
    </div>
  );
}

function Container14() {
  return <div className="bg-[#3b8aff] rounded-[39602500px] shrink-0 size-[19.99px]" data-name="Container" />;
}

function Paragraph() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[#0a0a0a] text-[14px] top-[0.18px]">Doctor ID : 122</p>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#2e2c34] text-[14px] top-[0.18px]">Name : Mohamed Abdelsalam</p>
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[39.981px] relative shrink-0 w-[212.795px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Paragraph />
        <Paragraph1 />
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="content-stretch flex gap-[11.987px] h-[39.981px] items-center relative shrink-0 w-full" data-name="Container">
      <Container14 />
      <Container15 />
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute left-[82.1px] size-[15.989px] top-[9.98px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9887 15.9887">
        <g clipPath="url(#clip0_6_1699)" id="Icon">
          <path d="M6.66194 7.32814V11.3253" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33239" />
          <path d="M9.32672 7.32814V11.3253" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33239" />
          <path d={svgPaths.p104fb680} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33239" />
          <path d="M1.99858 3.99716H13.9901" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33239" />
          <path d={svgPaths.p2f307d68} id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33239" />
        </g>
        <defs>
          <clipPath id="clip0_6_1699">
            <rect fill="white" height="15.9887" width="15.9887" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[#e7000b] h-[35.961px] relative rounded-[4px] shrink-0 w-full" data-name="Button">
      <Icon1 />
      <p className="-translate-x-1/2 absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[20px] left-[147.57px] text-[14px] text-center text-white top-[8.17px]">Delete User</p>
    </div>
  );
}

function Container12() {
  return (
    <div className="absolute bg-[#fefefe] content-stretch flex flex-col gap-[11.987px] h-[122.266px] items-start left-[17.17px] pb-[1.18px] pt-[17.169px] px-[17.169px] rounded-[10px] top-[528.62px] w-[304.282px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <Container13 />
      <Button2 />
    </div>
  );
}

function Container1() {
  return (
    <div className="bg-white h-[668.057px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <Heading2 />
      <Container2 />
      <Heading3 />
      <Container10 />
      <Container12 />
    </div>
  );
}

function CoursesScreen() {
  return (
    <div className="bg-[#f9f9fb] h-[855.956px] relative shrink-0 w-full" data-name="CoursesScreen">
      <div className="content-stretch flex flex-col gap-[23.992px] items-start pt-[87.965px] px-[15.989px] relative size-full">
        <Container />
        <Container1 />
      </div>
    </div>
  );
}

function Body() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[853.319px] items-start left-0 top-0 w-[370.598px]" data-name="Body">
      <CoursesScreen />
    </div>
  );
}

function Icon2() {
  return (
    <div className="h-[23.992px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.83%_16.67%_79.17%_16.67%]" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-1/2 left-[16.67%] right-[16.67%] top-1/2" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[79.17%_16.67%_20.83%_16.67%]" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="relative rounded-[10px] shrink-0 size-[39.962px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[7.985px] px-[7.985px] relative size-full">
        <Icon2 />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[27.994px] relative shrink-0 w-[121.842px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[28px] left-0 text-[#2e2c34] text-[18px] top-[-0.64px]">TICKET LEAD</p>
      </div>
    </div>
  );
}

function ImageUser() {
  return <div className="rounded-[39602500px] shrink-0 size-[39.999px]" data-name="Image (User)" />;
}

function App() {
  return (
    <div className="absolute bg-white content-stretch flex h-[63.973px] items-center justify-between left-0 pl-[8.004px] pr-[15.989px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] top-0 w-[370.598px]" data-name="App">
      <Button3 />
      <Heading />
      <ImageUser />
    </div>
  );
}

function Heading4() {
  return (
    <div className="h-[28.012px] relative shrink-0 w-full" data-name="Heading 2">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[28px] left-0 text-[#2e2c34] text-[20px] top-[-0.82px] uppercase">Ticket Lead</p>
    </div>
  );
}

function Icon3() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g id="Icon">
          <path d={svgPaths.p347b5000} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p2310bb80} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p33187040} id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p1add1340} id="Vector_4" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-[206.82px]" data-name="Button">
      <Icon3 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Dashboard</p>
    </div>
  );
}

function Icon4() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g clipPath="url(#clip0_6_1685)" id="Icon">
          <path d={svgPaths.p26db4f00} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 4.16467V5.83054" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 14.1599V15.8258" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 9.16228V10.8282" id="Vector_4" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
        <defs>
          <clipPath id="clip0_6_1685">
            <rect fill="white" height="19.9904" width="19.9904" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-[206.82px]" data-name="Button">
      <Icon4 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Tickets</p>
    </div>
  );
}

function Icon5() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g clipPath="url(#clip0_6_1673)" id="Icon">
          <path d={svgPaths.p242da100} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p31dd1980} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p19a3b080} id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p29dffb00} id="Vector_4" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
        <defs>
          <clipPath id="clip0_6_1673">
            <rect fill="white" height="19.9904" width="19.9904" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-[206.82px]" data-name="Button">
      <Icon5 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Users</p>
    </div>
  );
}

function Icon6() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g clipPath="url(#clip0_6_1695)" id="Icon">
          <path d="M9.99522 5.83054V17.4916" id="Vector" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p1e385f00} id="Vector_2" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
        <defs>
          <clipPath id="clip0_6_1695">
            <rect fill="white" height="19.9904" width="19.9904" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="bg-[rgba(127,86,216,0.2)] h-[47.984px] relative rounded-[10px] shrink-0 w-[206.82px]" data-name="Button">
      <Icon6 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#7f56d8] text-[16px] top-[12.35px]">Courses</p>
    </div>
  );
}

function Icon7() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g id="Icon">
          <path d={svgPaths.p1f3f330} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M14.9928 14.1599V7.49641" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 14.1599V4.16467" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M6.66348 14.1599V11.6611" id="Vector_4" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-[206.82px]" data-name="Button">
      <Icon7 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Analysis</p>
    </div>
  );
}

function Icon8() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g id="Icon">
          <path d={svgPaths.p16840600} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M17.4916 9.99522H7.49641" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p543d000} id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
      </svg>
    </div>
  );
}

function Button9() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-[206.82px]" data-name="Button">
      <Icon8 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Logout</p>
    </div>
  );
}

function Navigation() {
  return (
    <div className="content-stretch flex flex-col gap-[7.985px] h-[327.832px] items-start relative shrink-0" data-name="Navigation">
      <Button4 />
      <Button5 />
      <Button6 />
      <Button7 />
      <Button8 />
      <Button9 />
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[435.825px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col gap-[31.996px] items-start pt-[23.992px] px-[23.992px] relative size-full">
        <Heading4 />
        <Navigation />
      </div>
    </div>
  );
}

function App1() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[853.319px] items-start left-[-255.98px] pr-[1.18px] top-0 w-[255.984px]" data-name="App">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-r-[1.18px] border-solid inset-0 pointer-events-none" />
      <Container16 />
    </div>
  );
}

export default function ResponsiveMobileView() {
  return (
    <div className="bg-white relative size-full" data-name="Responsive Mobile View">
      <Body />
      <App />
      <App1 />
    </div>
  );
}