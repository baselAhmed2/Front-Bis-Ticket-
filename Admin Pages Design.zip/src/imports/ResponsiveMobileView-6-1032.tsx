import svgPaths from "./svg-csrt0pro91";

function Heading1() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-full" data-name="Heading 2">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[32px] left-0 text-[#2e2c34] text-[24px] top-[-0.82px]">Most Doctors Get Tickts</p>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#7f56d8] h-[38.321px] relative rounded-[10px] shrink-0 w-[76.753px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#7f56d8] border-b-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-[37.99px] text-[14px] text-center text-white top-[8.76px]">Level 1</p>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-white h-[38.321px] relative rounded-[10px] shrink-0 w-[82.009px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-[41.67px] text-[#2e2c34] text-[14px] text-center top-[9.35px]">Level 2</p>
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-white h-[38.321px] relative rounded-[10px] shrink-0 w-[81.953px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-[41.67px] text-[#2e2c34] text-[14px] text-center top-[9.35px]">Level 3</p>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-white h-[38.321px] relative rounded-[10px] shrink-0 w-[83.318px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-[41.17px] text-[#2e2c34] text-[14px] text-center top-[9.35px]">Level 4</p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex gap-[7.985px] h-[68.731px] items-start overflow-clip relative shrink-0 w-full" data-name="Container">
      <Button />
      <Button1 />
      <Button2 />
      <Button3 />
    </div>
  );
}

function Container4() {
  return <div className="bg-[#3b8aff] rounded-[39602500px] shrink-0 size-[11.987px]" data-name="Container" />;
}

function Paragraph() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[#0a0a0a] text-[14px] top-[0.18px]">Doctor ID : 122</p>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#2e2c34] text-[14px] top-[0.18px]">Name : Mohamed Abdelsalam</p>
    </div>
  );
}

function Container5() {
  return (
    <div className="h-[39.981px] relative shrink-0 w-[212.795px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Paragraph />
        <Paragraph1 />
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex gap-[11.987px] h-[39.981px] items-center relative shrink-0 w-full" data-name="Container">
      <Container4 />
      <Container5 />
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[16.007px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Arial:Regular',sans-serif] leading-[16px] left-[72.26px] not-italic text-[#84818a] text-[12px] text-center top-[-2.18px]">Total Tickets</p>
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Montserrat:Bold',sans-serif] font-bold leading-[32px] left-[72.39px] text-[#0a0a0a] text-[24px] text-center top-[0.36px]">9</p>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.983px] h-[51.968px] items-start left-0 top-0 w-[144.138px]" data-name="Container">
      <Paragraph2 />
      <Paragraph3 />
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="h-[16.007px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Arial:Regular',sans-serif] leading-[16px] left-[72.18px] not-italic text-[#84818a] text-[12px] text-center top-[-2.18px]">Closed</p>
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Montserrat:Bold',sans-serif] font-bold leading-[32px] left-[72.39px] text-[#0a0a0a] text-[24px] text-center top-[0.36px]">9</p>
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.983px] h-[51.968px] items-start left-[160.13px] top-0 w-[144.156px]" data-name="Container">
      <Paragraph4 />
      <Paragraph5 />
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[51.968px] relative shrink-0 w-full" data-name="Container">
      <Container7 />
      <Container8 />
    </div>
  );
}

function Container2() {
  return (
    <div className="bg-white h-[142.275px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="content-stretch flex flex-col gap-[15.989px] items-start pb-[1.18px] pt-[17.169px] px-[17.169px] relative size-full">
        <Container3 />
        <Container6 />
      </div>
    </div>
  );
}

function Container11() {
  return <div className="bg-[#3b8aff] rounded-[39602500px] shrink-0 size-[11.987px]" data-name="Container" />;
}

function Paragraph6() {
  return (
    <div className="absolute h-[19.99px] left-0 top-0 w-[212.795px]" data-name="Paragraph">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[#0a0a0a] text-[14px] top-[0.18px]">Doctor ID : 122</p>
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="absolute h-[19.99px] left-0 top-[19.99px] w-[212.795px]" data-name="Paragraph">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#2e2c34] text-[14px] top-[0.18px]">Name : Mohamed Abdelsalam</p>
    </div>
  );
}

function Container12() {
  return (
    <div className="h-[39.981px] relative shrink-0 w-[212.795px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Paragraph6 />
        <Paragraph7 />
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex gap-[11.987px] h-[39.981px] items-center relative shrink-0 w-full" data-name="Container">
      <Container11 />
      <Container12 />
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="h-[16.007px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Arial:Regular',sans-serif] leading-[16px] left-[72.26px] not-italic text-[#84818a] text-[12px] text-center top-[-2.18px]">Total Tickets</p>
    </div>
  );
}

function Paragraph9() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Montserrat:Bold',sans-serif] font-bold leading-[32px] left-[72.39px] text-[#0a0a0a] text-[24px] text-center top-[0.36px]">9</p>
    </div>
  );
}

function Container14() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.983px] h-[51.968px] items-start left-0 top-0 w-[144.138px]" data-name="Container">
      <Paragraph8 />
      <Paragraph9 />
    </div>
  );
}

function Paragraph10() {
  return (
    <div className="h-[16.007px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Arial:Regular',sans-serif] leading-[16px] left-[72.18px] not-italic text-[#84818a] text-[12px] text-center top-[-2.18px]">Closed</p>
    </div>
  );
}

function Paragraph11() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Montserrat:Bold',sans-serif] font-bold leading-[32px] left-[72.39px] text-[#0a0a0a] text-[24px] text-center top-[0.36px]">9</p>
    </div>
  );
}

function Container15() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.983px] h-[51.968px] items-start left-[160.13px] top-0 w-[144.156px]" data-name="Container">
      <Paragraph10 />
      <Paragraph11 />
    </div>
  );
}

function Container13() {
  return (
    <div className="h-[51.968px] relative shrink-0 w-full" data-name="Container">
      <Container14 />
      <Container15 />
    </div>
  );
}

function Container9() {
  return (
    <div className="bg-white h-[142.275px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="content-stretch flex flex-col gap-[15.989px] items-start pb-[1.18px] pt-[17.169px] px-[17.169px] relative size-full">
        <Container10 />
        <Container13 />
      </div>
    </div>
  );
}

function Container18() {
  return <div className="bg-[#3b8aff] rounded-[39602500px] shrink-0 size-[11.987px]" data-name="Container" />;
}

function Paragraph12() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[#0a0a0a] text-[14px] top-[0.18px]">Doctor ID : 122</p>
    </div>
  );
}

function Paragraph13() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#2e2c34] text-[14px] top-[0.18px]">Name : Mohamed Abdelsalam</p>
    </div>
  );
}

function Container19() {
  return (
    <div className="h-[39.981px] relative shrink-0 w-[212.795px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Paragraph12 />
        <Paragraph13 />
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="content-stretch flex gap-[11.987px] h-[39.981px] items-center relative shrink-0 w-full" data-name="Container">
      <Container18 />
      <Container19 />
    </div>
  );
}

function Paragraph14() {
  return (
    <div className="h-[16.007px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Arial:Regular',sans-serif] leading-[16px] left-[72.26px] not-italic text-[#84818a] text-[12px] text-center top-[-2.18px]">Total Tickets</p>
    </div>
  );
}

function Paragraph15() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Montserrat:Bold',sans-serif] font-bold leading-[32px] left-[72.39px] text-[#0a0a0a] text-[24px] text-center top-[0.36px]">9</p>
    </div>
  );
}

function Container21() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.983px] h-[51.968px] items-start left-0 top-0 w-[144.138px]" data-name="Container">
      <Paragraph14 />
      <Paragraph15 />
    </div>
  );
}

function Paragraph16() {
  return (
    <div className="h-[16.007px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Arial:Regular',sans-serif] leading-[16px] left-[72.18px] not-italic text-[#84818a] text-[12px] text-center top-[-2.18px]">Closed</p>
    </div>
  );
}

function Paragraph17() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Montserrat:Bold',sans-serif] font-bold leading-[32px] left-[72.39px] text-[#0a0a0a] text-[24px] text-center top-[0.36px]">9</p>
    </div>
  );
}

function Container22() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.983px] h-[51.968px] items-start left-[160.13px] top-0 w-[144.156px]" data-name="Container">
      <Paragraph16 />
      <Paragraph17 />
    </div>
  );
}

function Container20() {
  return (
    <div className="h-[51.968px] relative shrink-0 w-full" data-name="Container">
      <Container21 />
      <Container22 />
    </div>
  );
}

function Container16() {
  return (
    <div className="bg-white h-[142.275px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="content-stretch flex flex-col gap-[15.989px] items-start pb-[1.18px] pt-[17.169px] px-[17.169px] relative size-full">
        <Container17 />
        <Container20 />
      </div>
    </div>
  );
}

function Container25() {
  return <div className="bg-[#3b8aff] rounded-[39602500px] shrink-0 size-[11.987px]" data-name="Container" />;
}

function Paragraph18() {
  return (
    <div className="absolute h-[19.99px] left-0 top-0 w-[212.795px]" data-name="Paragraph">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[#0a0a0a] text-[14px] top-[0.18px]">Doctor ID : 122</p>
    </div>
  );
}

function Paragraph19() {
  return (
    <div className="absolute h-[19.99px] left-0 top-[19.99px] w-[212.795px]" data-name="Paragraph">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#2e2c34] text-[14px] top-[0.18px]">Name : Mohamed Abdelsalam</p>
    </div>
  );
}

function Container26() {
  return (
    <div className="h-[39.981px] relative shrink-0 w-[212.795px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Paragraph18 />
        <Paragraph19 />
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="content-stretch flex gap-[11.987px] h-[39.981px] items-center relative shrink-0 w-full" data-name="Container">
      <Container25 />
      <Container26 />
    </div>
  );
}

function Paragraph20() {
  return (
    <div className="h-[16.007px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Arial:Regular',sans-serif] leading-[16px] left-[72.26px] not-italic text-[#84818a] text-[12px] text-center top-[-2.18px]">Total Tickets</p>
    </div>
  );
}

function Paragraph21() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Montserrat:Bold',sans-serif] font-bold leading-[32px] left-[72.39px] text-[#0a0a0a] text-[24px] text-center top-[0.36px]">9</p>
    </div>
  );
}

function Container28() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.983px] h-[51.968px] items-start left-0 top-0 w-[144.138px]" data-name="Container">
      <Paragraph20 />
      <Paragraph21 />
    </div>
  );
}

function Paragraph22() {
  return (
    <div className="h-[16.007px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Arial:Regular',sans-serif] leading-[16px] left-[72.18px] not-italic text-[#84818a] text-[12px] text-center top-[-2.18px]">Closed</p>
    </div>
  );
}

function Paragraph23() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Montserrat:Bold',sans-serif] font-bold leading-[32px] left-[72.39px] text-[#0a0a0a] text-[24px] text-center top-[0.36px]">9</p>
    </div>
  );
}

function Container29() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.983px] h-[51.968px] items-start left-[160.13px] top-0 w-[144.156px]" data-name="Container">
      <Paragraph22 />
      <Paragraph23 />
    </div>
  );
}

function Container27() {
  return (
    <div className="h-[51.968px] relative shrink-0 w-full" data-name="Container">
      <Container28 />
      <Container29 />
    </div>
  );
}

function Container23() {
  return (
    <div className="bg-white h-[142.275px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="content-stretch flex flex-col gap-[15.989px] items-start pb-[1.18px] pt-[17.169px] px-[17.169px] relative size-full">
        <Container24 />
        <Container27 />
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex flex-col gap-[15.989px] h-[617.066px] items-start relative shrink-0 w-full" data-name="Container">
      <Container2 />
      <Container9 />
      <Container16 />
      <Container23 />
    </div>
  );
}

function AnalysisScreen() {
  return (
    <div className="bg-[#f9f9fb] h-[877.716px] relative shrink-0 w-full" data-name="AnalysisScreen">
      <div className="content-stretch flex flex-col gap-[23.992px] items-start pt-[87.965px] px-[15.989px] relative size-full">
        <Heading1 />
        <Container />
        <Container1 />
      </div>
    </div>
  );
}

function Body() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[853.319px] items-start left-0 top-0 w-[370.598px]" data-name="Body">
      <AnalysisScreen />
    </div>
  );
}

function Icon() {
  return (
    <div className="h-[23.992px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.83%_16.67%_79.17%_16.67%]" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-1/2 left-[16.67%] right-[16.67%] top-1/2" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[79.17%_16.67%_20.83%_16.67%]" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button4() {
  return (
    <div className="relative rounded-[10px] shrink-0 size-[39.962px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[7.985px] px-[7.985px] relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[27.994px] relative shrink-0 w-[121.842px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[28px] left-0 text-[#2e2c34] text-[18px] top-[-0.64px]">TICKET LEAD</p>
      </div>
    </div>
  );
}

function ImageUser() {
  return <div className="rounded-[39602500px] shrink-0 size-[39.999px]" data-name="Image (User)" />;
}

function App() {
  return (
    <div className="absolute bg-white content-stretch flex h-[63.973px] items-center justify-between left-0 pl-[8.004px] pr-[15.989px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] top-0 w-[370.598px]" data-name="App">
      <Button4 />
      <Heading />
      <ImageUser />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[28.012px] relative shrink-0 w-full" data-name="Heading 2">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[28px] left-0 text-[#2e2c34] text-[20px] top-[-0.82px] uppercase">Ticket Lead</p>
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g id="Icon">
          <path d={svgPaths.p347b5000} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p2310bb80} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p33187040} id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p1add1340} id="Vector_4" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon1 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Dashboard</p>
    </div>
  );
}

function Icon2() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g clipPath="url(#clip0_6_1741)" id="Icon">
          <path d={svgPaths.p26db4f00} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 4.16467V5.83054" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 14.1599V15.8258" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 9.16228V10.8282" id="Vector_4" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
        <defs>
          <clipPath id="clip0_6_1741">
            <rect fill="white" height="19.9904" width="19.9904" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon2 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Tickets</p>
    </div>
  );
}

function Icon3() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g clipPath="url(#clip0_6_1719)" id="Icon">
          <path d={svgPaths.p242da100} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p31dd1980} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p19a3b080} id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p29dffb00} id="Vector_4" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
        <defs>
          <clipPath id="clip0_6_1719">
            <rect fill="white" height="19.9904" width="19.9904" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon3 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Users</p>
    </div>
  );
}

function Icon4() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g clipPath="url(#clip0_6_1731)" id="Icon">
          <path d="M9.99522 5.83054V17.4916" id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p1e385f00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
        <defs>
          <clipPath id="clip0_6_1731">
            <rect fill="white" height="19.9904" width="19.9904" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon4 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Courses</p>
    </div>
  );
}

function Icon5() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g id="Icon">
          <path d={svgPaths.p1f3f330} id="Vector" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M14.9928 14.1599V7.49641" id="Vector_2" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 14.1599V4.16467" id="Vector_3" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M6.66348 14.1599V11.6611" id="Vector_4" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
      </svg>
    </div>
  );
}

function Button9() {
  return (
    <div className="bg-[rgba(127,86,216,0.2)] h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon5 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#7f56d8] text-[16px] top-[12.35px]">Analysis</p>
    </div>
  );
}

function Icon6() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g id="Icon">
          <path d={svgPaths.p16840600} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M17.4916 9.99522H7.49641" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p543d000} id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
      </svg>
    </div>
  );
}

function Button10() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon6 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Logout</p>
    </div>
  );
}

function Navigation() {
  return (
    <div className="content-stretch flex flex-col gap-[7.985px] h-[327.832px] items-start relative shrink-0 w-full" data-name="Navigation">
      <Button5 />
      <Button6 />
      <Button7 />
      <Button8 />
      <Button9 />
      <Button10 />
    </div>
  );
}

function Container30() {
  return (
    <div className="h-[435.825px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col gap-[31.996px] items-start pt-[23.992px] px-[23.992px] relative size-full">
        <Heading2 />
        <Navigation />
      </div>
    </div>
  );
}

function App1() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[853.319px] items-start left-[-255.98px] pr-[1.18px] top-0 w-[255.984px]" data-name="App">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-r-[1.18px] border-solid inset-0 pointer-events-none" />
      <Container30 />
    </div>
  );
}

export default function ResponsiveMobileView() {
  return (
    <div className="bg-white relative size-full" data-name="Responsive Mobile View">
      <Body />
      <App />
      <App1 />
    </div>
  );
}