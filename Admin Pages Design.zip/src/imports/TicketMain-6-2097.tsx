import svgPaths from "./svg-6am2xkkp4v";
import imgEllipse73 from "figma:asset/ffc5edd5df1e034f97f1621e2ca2d4e33201613f.png";

function AlignLeft() {
  return (
    <div className="absolute left-[20px] size-[30px] top-[27px]" data-name="align-left">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="align-left">
          <path d="M22.5 14.5H5" id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 7.5H5" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 21.5H5" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <div className="relative shrink-0 size-[48px]">
        <img alt="" className="absolute block max-w-none size-full" height="48" src={imgEllipse73} width="48" />
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#1a202c] text-[16px] whitespace-nowrap">
        <p className="leading-[normal]">DR Bahlol</p>
      </div>
    </div>
  );
}

function User() {
  return (
    <div className="absolute bg-[#fafafa] content-stretch flex gap-[12px] h-[56px] items-center left-[1019px] pl-[5px] pr-[18px] py-[12px] rounded-[1000px] top-[14px]" data-name="user">
      <Frame />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents left-[20px] top-[14px]">
      <AlignLeft />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[63px] text-[#2e2c34] text-[18px] top-[31px]">{`Welcome! `}</p>
      <User />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[calc(8.33%+123px)] top-0 w-[1263px]">
      <div className="h-[85px] relative shrink-0 w-full" data-name="Top Bar">
        <div className="absolute bg-white h-[85px] left-0 shadow-[0px_4px_40px_1px_rgba(0,0,0,0.03)] top-0 w-[1263px]" />
        <Group4 />
      </div>
    </div>
  );
}

function Category() {
  return (
    <div className="absolute inset-[8.33%_10.42%_10.42%_8.33%]" data-name="Category">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.875 17.875">
        <g id="Category">
          <path clipRule="evenodd" d={svgPaths.p1b0dd80} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 1" />
          <path clipRule="evenodd" d={svgPaths.p1d036400} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 3" />
          <path clipRule="evenodd" d={svgPaths.pdd4a200} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 5" />
          <path clipRule="evenodd" d={svgPaths.p20c71180} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 7" />
        </g>
      </svg>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[19px] top-[116px]">
      <div className="absolute inset-[10.78%_83.53%_87.17%_7.63%]" data-name="Iconly/Light-Outline/Category">
        <Category />
      </div>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[51px] text-[#7f56d8] text-[16px] top-[117px]">Dashboard</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[52px] top-[174px]">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[52px] text-[#2e2c34] text-[16px] top-[174px]">Tickets</p>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[8.33%_17.33%_8.87%_16.67%]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.52 18.2145">
        <g id="Group 6">
          <g id="Union">
            <path clipRule="evenodd" d={svgPaths.pbece300} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p3a518600} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Profile() {
  return (
    <div className="absolute contents inset-[8.33%_17.33%_8.87%_16.67%]" data-name="Profile">
      <Group />
    </div>
  );
}

function IconsaxLinearTicketstar() {
  return (
    <div className="absolute left-[20px] size-[22px] top-[173px]" data-name="Iconsax/Linear/ticketstar">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/ticketstar">
          <path d={svgPaths.p388172f0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p19372c00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function UimAnalytics() {
  return (
    <div className="absolute left-[22px] size-[19px] top-[342px]" data-name="uim:analytics">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19">
        <g id="uim:analytics">
          <path d={svgPaths.pe4b5000} fill="var(--fill-0, #1E1E1E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute contents left-0 top-[1001px]">
      <div className="absolute bg-[rgba(127,86,216,0.1)] h-[45px] left-0 top-[1001px] w-[249px]" />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute h-[1076px] left-0 top-0 w-[249px]" data-name="Sidebar">
      <div className="absolute h-[1076px] left-0 top-0 w-[249px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 249 1076">
          <path d={svgPaths.p29894d00} fill="var(--fill-0, white)" id="Rectangle 5884" stroke="var(--stroke-0, #E7E7E7)" />
        </svg>
      </div>
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[35px] text-[#2e2c34] text-[24px] top-[28px] uppercase">Ticket Lead</p>
      <Group3 />
      <Group2 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[51px] text-[#2e2c34] text-[16px] top-[230px]">{`Users `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[49px] text-[#2e2c34] text-[16px] top-[286px]">{`Add Course `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium h-[19px] leading-[normal] left-[54px] text-[#2e2c34] text-[16px] top-[342px] w-[95px] whitespace-pre-wrap">{`Analysis `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[53px] text-[#2e2c34] text-[16px] top-[399px]">Logout</p>
      <div className="absolute left-[22px] size-[22px] top-[397px]" data-name="material-symbols:logout-rounded">
        <div className="absolute inset-[12.5%_14.17%_12.5%_12.5%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.1333 16.5">
            <path d={svgPaths.p25f94200} fill="var(--fill-0, #1E1E1E)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[21.28%_83.53%_76.67%_7.63%]" data-name="Iconly/Light-Outline/Profile">
        <Profile />
      </div>
      <IconsaxLinearTicketstar />
      <UimAnalytics />
      <div className="absolute inset-[26.86%_84.81%_71.96%_8.84%]" data-name="Vector">
        <div className="absolute inset-[-5.92%_-4.74%_-11.06%_-4.74%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.3333 14.8181">
            <path d={svgPaths.pcb33180} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
      <Group12 />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[68px] top-[1016px]">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[68px] text-[#2e2c34] text-[16px] top-[1016px]">Site Settings</p>
    </div>
  );
}

function IconsaxLinearSetting() {
  return (
    <div className="absolute left-[36px] size-[22px] top-[1016px]" data-name="Iconsax/Linear/setting">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/setting">
          <path d={svgPaths.p1d7fb300} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p31cea00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[calc(25%+32px)] top-[233px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[calc(25%+32px)] text-[#2e2c34] text-[14px] top-[240.61px] w-[411.934px]">
        <p className="whitespace-pre-wrap">
          <span className="leading-[14px]">{`Delete Include All Data  `}</span>
          <span className="leading-[14px] text-[#e7000b]">Except Users</span>
        </p>
      </div>
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[calc(16.67%+85px)] top-[233px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(16.67%+85px)] text-[#2e2c34] text-[14px] top-[240.5px] w-[80px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Doctor  :`}</p>
      </div>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[calc(16.67%+46px)] top-[192.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[calc(16.67%+85px)] text-[#2e2c34] text-[16px] top-[204.21px] w-[248.745px]">
        <p className="leading-[14px] whitespace-pre-wrap">Delete all Temporary Data</p>
      </div>
      <div className="absolute left-[calc(16.67%+46px)] size-[22px] top-[192.25px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
          <circle cx="11" cy="11" fill="var(--fill-0, #3B8AFF)" id="Ellipse 931" r="11" />
        </svg>
      </div>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[calc(16.67%+46px)] top-[189px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(75%+98px)] text-[#84818a] text-[12px] top-[196.5px] w-[173px]">
        <p className="leading-[14px] whitespace-pre-wrap">Created At 22-11-2024</p>
      </div>
      <div className="absolute h-0 left-[calc(16.67%+46px)] top-[305.68px] w-[1107.47px]" data-name="Line">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1107.47 1">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.5" x2="1106.97" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[calc(16.67%+46px)] top-[189px]">
      <Group5 />
      <Group10 />
      <Group6 />
      <Group7 />
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents left-[calc(16.67%+26px)] top-[170px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[15.8%_5.22%_71.56%_18.39%] rounded-[4px]" />
      <Group8 />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#e7000b] content-stretch flex gap-[10px] h-[44px] items-center justify-center left-[calc(75%+96px)] p-[10px] rounded-[4px] top-[238px] w-[157px]" data-name="Button">
      <div className="overflow-clip relative shrink-0 size-[24px]" data-name="delete">
        <div className="absolute inset-[12.5%_16.67%]" data-name="icon">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 18">
            <path d={svgPaths.p3dc18500} fill="var(--fill-0, white)" id="icon" />
          </svg>
        </div>
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Delete User</p>
      </div>
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents left-[calc(16.67%+26px)] top-[170px]">
      <Group9 />
      <Button />
    </div>
  );
}

export default function TicketMain() {
  return (
    <div className="bg-[#f9f9fb] relative size-full" data-name="Ticket Main">
      <Frame1 />
      <Sidebar />
      <div className="absolute left-[calc(50%+89px)] size-[23px] top-[860px]" data-name="zondicons:view-show">
        <div className="absolute inset-[19.98%_1%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.54 13.8092">
            <path d={svgPaths.p31406d00} fill="var(--fill-0, white)" id="Vector" />
          </svg>
        </div>
      </div>
      <Group1 />
      <IconsaxLinearSetting />
      <Group11 />
    </div>
  );
}