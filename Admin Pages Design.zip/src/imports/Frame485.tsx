import svgPaths from "./svg-acdwjucxyd";
import imgImage from "figma:asset/4a48e9ef3542f6dfa5c2b4006a3bd35174343b86.png";

function Group1() {
  return (
    <div className="absolute contents left-[27px] top-[8px]" data-name="Group">
      <div className="absolute flex h-[31.072px] items-center justify-center left-[123px] top-[11px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-15 flex-none">
          <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
      <div className="absolute flex h-[31.072px] items-center justify-center left-[27px] top-[8px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-15 flex-none">
          <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
      <div className="absolute flex h-[31.072px] items-center justify-center left-[35px] top-[36px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-15 flex-none">
          <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[97.84px] top-[37.82px]" data-name="Group">
      <div className="absolute flex h-[31.072px] items-center justify-center left-[97.84px] top-[62.82px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-165">
          <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
      <div className="absolute flex h-[31.072px] items-center justify-center left-[193.84px] top-[65.82px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-165">
          <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
      <div className="absolute flex h-[31.072px] items-center justify-center left-[185.84px] top-[37.82px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-165">
          <div className="bg-[rgba(255,255,255,0.24)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[27px] top-[8px]" data-name="Group">
      <Group1 />
      <Group2 />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents font-['Poppins:Medium',sans-serif] leading-[normal] left-[24px] not-italic text-[#131215] top-[22px]" data-name="Group">
      <p className="absolute left-[24px] text-[16px] top-[22px] tracking-[0.48px]" dir="auto">
        New Ticket
      </p>
      <p className="absolute left-[24px] text-[32px] top-[62px] tracking-[0.96px]">20</p>
    </div>
  );
}

export default function Frame() {
  return (
    <div className="relative rounded-[34px] size-full">
      <div className="absolute h-[159px] left-0 top-0 w-[300px]" data-name="Subtract">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 300 159">
          <path d={svgPaths.p15875b80} fill="var(--fill-0, #0BF4C8)" id="Subtract" />
        </svg>
      </div>
      <Group />
      <div className="absolute h-[110px] left-[150px] shadow-[0px_4px_4px_0px_#34dabb] top-[43px] w-[136px]" data-name="Image">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[121.17%] left-[-22.5%] max-w-none top-[-13.81%] w-[138.17%]" src={imgImage} />
        </div>
      </div>
      <Group3 />
      <p className="[text-decoration-skip-ink:none] absolute decoration-solid font-['Poppins:Regular',sans-serif] leading-[normal] left-[27px] not-italic text-[#131215] text-[12px] top-[119px] tracking-[0.36px] underline w-[94px] whitespace-pre-wrap">View entire list</p>
    </div>
  );
}