import svgPaths from "./svg-av16d50knt";
import imgImage from "figma:asset/9167c8be93d950c9eebb94ae4a66f19fa94485fa.png";

function Group2() {
  return (
    <div className="absolute contents left-[22px] top-[6px]" data-name="Group">
      <div className="absolute flex h-[31.072px] items-center justify-center left-[118px] top-[9px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-15 flex-none">
          <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
      <div className="absolute flex h-[31.072px] items-center justify-center left-[22px] top-[6px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-15 flex-none">
          <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
      <div className="absolute flex h-[31.072px] items-center justify-center left-[30px] top-[34px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-15 flex-none">
          <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[92.84px] top-[35.82px]" data-name="Group">
      <div className="absolute flex h-[31.072px] items-center justify-center left-[92.84px] top-[60.82px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-165">
          <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
      <div className="absolute flex h-[31.072px] items-center justify-center left-[188.84px] top-[120.37px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-165">
          <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
      <div className="absolute flex h-[31.072px] items-center justify-center left-[180.84px] top-[35.82px] w-[79.155px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-165">
          <div className="bg-[rgba(255,255,255,0.1)] h-[11px] rounded-[100px] w-[79px]" data-name="Rectangle" />
        </div>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[22px] top-[6px]" data-name="Group">
      <Group2 />
      <Group3 />
    </div>
  );
}

function Frame() {
  return (
    <div className="absolute h-[159px] left-0 overflow-clip rounded-[34px] top-0 w-[300px]">
      <div className="absolute h-[159px] left-0 top-0 w-[300px]" data-name="Subtract">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 300 159">
          <path d={svgPaths.p67e2d00} fill="var(--fill-0, #FAD85D)" id="Subtract" />
        </svg>
      </div>
      <Group1 />
      <div className="absolute h-[135px] left-[126px] shadow-[0px_8px_8px_0px_#f1cb41] top-[18px] w-[169px]" data-name="Image">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[118.18%] left-[-12.79%] max-w-none top-[-9.52%] w-[125.64%]" src={imgImage} />
        </div>
      </div>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents font-['Poppins:Medium',sans-serif] leading-[normal] left-[24px] not-italic text-[#131215] top-[22px] whitespace-pre-wrap" data-name="Group">
      <p className="absolute left-[24px] text-[16px] top-[22px] tracking-[0.48px] w-[125px]">{` In Progress `}</p>
      <p className="absolute left-[24px] text-[32px] top-[62px] tracking-[0.96px] w-[72px]">750</p>
    </div>
  );
}

export default function Group() {
  return (
    <div className="relative size-full" data-name="Group">
      <Frame />
      <Group4 />
      <p className="[text-decoration-skip-ink:none] absolute decoration-solid font-['Poppins:Regular',sans-serif] leading-[normal] left-[27px] not-italic text-[#131215] text-[12px] top-[119px] tracking-[0.36px] underline w-[94px] whitespace-pre-wrap">View entire list</p>
    </div>
  );
}