import svgPaths from "./svg-fsm9fl4lrj";
import imgEllipse73 from "figma:asset/ffc5edd5df1e034f97f1621e2ca2d4e33201613f.png";

function Group4() {
  return (
    <div className="absolute contents left-[142.6px] top-[707px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15.217px] justify-center leading-[0] left-[142.6px] text-[#2e2c34] text-[14px] top-[714.61px] w-[379.479px]">
        <p className="leading-[14px] whitespace-pre-wrap">Mohamed Abdelsalam</p>
      </div>
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents left-[75.35px] top-[707px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[75.35px] text-[#2e2c34] text-[14px] top-[714.5px] w-[73.697px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Name  :`}</p>
      </div>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[39.42px] top-[669.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[75.35px] text-[#2e2c34] text-[16px] top-[681.21px] w-[229.147px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Doctor ID :   122`}</p>
      </div>
      <div className="absolute h-[22px] left-[39.42px] top-[669.25px] w-[20.267px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.2667 22">
          <ellipse cx="10.1333" cy="11" fill="var(--fill-0, #3B8AFF)" id="Ellipse 931" rx="10.1333" ry="11" />
        </svg>
      </div>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute h-0 left-[39.42px] top-[782.68px] w-[1020.215px]">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1020.22 1">
          <g id="Group 1000004235">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.500146" x2="1019.72" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[39.42px] top-[669.25px]">
      <Group4 />
      <Group9 />
      <Group5 />
      <Group6 />
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[21px] top-[647px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[66.63%_9.21%_19.36%_1.76%] rounded-[4px]" />
      <Group7 />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#e7000b] content-stretch flex gap-[10px] h-[44px] items-center justify-center left-[850px] p-[10px] rounded-[4px] top-[693px] w-[143px]" data-name="Button">
      <div className="overflow-clip relative shrink-0 size-[24px]" data-name="delete">
        <div className="absolute inset-[12.5%_16.67%]" data-name="icon">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 18">
            <path d={svgPaths.p3dc18500} fill="var(--fill-0, white)" id="icon" />
          </svg>
        </div>
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Delete User</p>
      </div>
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute contents left-[21px] top-[647px]">
      <Group8 />
      <Button />
    </div>
  );
}

function ReplyTicketBox() {
  return (
    <div className="absolute inset-[2.7%_7.03%_75.69%_1.76%]" data-name="Reply ticket Box">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1090 209.814">
        <g id="Reply ticket Box">
          <path d={svgPaths.p16255900} fill="var(--fill-0, #FCFCFC)" id="Rectangle 6715" stroke="var(--stroke-0, #E7E7E7)" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-[#7f56d8] content-stretch flex h-[44px] items-center justify-center left-[725px] p-[10px] rounded-[4px] top-[425px] w-[157px]" data-name="Button">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">{`Save `}</p>
      </div>
    </div>
  );
}

function InputArea() {
  return (
    <div className="absolute content-stretch flex h-[50px] items-center left-[200px] px-[20px] py-[16px] rounded-[4px] top-[422px] w-[366px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">Enter Doctor ID</p>
      </div>
    </div>
  );
}

function VuesaxLinearArrowDown() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-down">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
        <g id="arrow-down">
          <path d={svgPaths.p2c331200} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_2" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function ReplyTicketBox2() {
  return (
    <div className="absolute contents left-[63px] top-[390px]" data-name="Reply ticket Box">
      <div className="absolute inset-[40.16%_7.95%_46.45%_5.27%]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1037 130">
          <path d={svgPaths.pc8f4300} fill="var(--fill-0, #FCFCFC)" id="Rectangle 6715" stroke="var(--stroke-0, #E7E7E7)" />
        </svg>
      </div>
      <Button1 />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] left-[93px] text-[#2e2a40] text-[14px] top-[447px] w-[320px]">
        <p className="leading-[normal] whitespace-pre-wrap">Doctor ID</p>
      </div>
      <InputArea />
      <div className="absolute flex items-center justify-center left-[993px] size-[34px] top-[432px]">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[34px]" data-name="vuesax/linear/arrow-down">
            <VuesaxLinearArrowDown />
          </div>
        </div>
      </div>
    </div>
  );
}

function ReplyTicketBox1() {
  return (
    <div className="absolute contents left-[21px] top-[294px]" data-name="Reply ticket Box">
      <div className="absolute inset-[30.28%_7.03%_42.53%_1.76%]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1090 264">
          <path d={svgPaths.p3f36e500} fill="var(--fill-0, #FCFCFC)" id="Rectangle 6715" stroke="var(--stroke-0, #E7E7E7)" />
        </svg>
      </div>
      <ReplyTicketBox2 />
    </div>
  );
}

function OutputArea() {
  return (
    <div className="bg-white content-stretch flex h-[50px] items-center px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Output Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] tracking-[-0.28px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Information  System `}</p>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[453px] top-[104px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Student Name `}</p>
      </div>
      <OutputArea />
    </div>
  );
}

function Content1() {
  return <div className="absolute h-[141px] left-[35px] top-[291px] w-[967px]" data-name="Content" />;
}

function Tittle() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[37px] top-[52px] w-[53px]" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[18px] w-[292px]">
        <p className="leading-[1.5] whitespace-pre-wrap">{` Course Information `}</p>
      </div>
    </div>
  );
}

function OutputArea1() {
  return (
    <div className="bg-white content-stretch flex h-[50px] items-center px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Output Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] tracking-[-0.28px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">BIs123</p>
      </div>
    </div>
  );
}

function Content2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[117px] top-[104px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">Course ID</p>
      </div>
      <OutputArea1 />
    </div>
  );
}

function InputArea1() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="absolute left-[20px] size-[15px] top-[17.5px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="7.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[34%_17.65%_34%_16.61%] justify-center leading-[0] text-[#757575] text-[14px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Level 4 `}</p>
      </div>
    </div>
  );
}

function Content3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[789px] top-[104px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Course `}</p>
      </div>
      <InputArea1 />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[117px] top-[104px]">
      <Content2 />
      <Content3 />
    </div>
  );
}

function InputArea2() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="absolute left-[20px] size-[15px] top-[17.5px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="7.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[34%_17.65%_34%_16.61%] justify-center leading-[0] text-[#757575] text-[14px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Level 4 `}</p>
      </div>
    </div>
  );
}

function Content4() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[789px] top-[104px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Course `}</p>
      </div>
      <InputArea2 />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute contents left-[789px] top-[104px]">
      <Content4 />
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents left-[35px] top-[52px]">
      <Content1 />
      <Tittle />
      <Group10 />
      <Group12 />
    </div>
  );
}

function Tittle1() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[36px] top-[322px] w-[201px]" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[18px] w-[292px]">
        <p className="leading-[1.5] whitespace-pre-wrap">{`Assigned Doctors `}</p>
      </div>
    </div>
  );
}

function Content5() {
  return <div className="absolute h-[76px] left-[1016px] top-[104px] w-[125px]" data-name="Content" />;
}

function ReplyDetailTicket() {
  return (
    <div className="absolute h-[971px] left-[calc(16.67%+21px)] overflow-clip rounded-[4px] top-[168px] w-[1195px]" data-name="Reply Detail Ticket">
      <div className="absolute h-[828px] left-0 rounded-[4px] top-0 w-[1195px]" data-name="card">
        <div className="absolute bg-white inset-0 rounded-[4px]" />
      </div>
      <Group13 />
      <ReplyTicketBox />
      <ReplyTicketBox1 />
      <Content />
      <Group11 />
      <Tittle1 />
      <Content5 />
    </div>
  );
}

function Category() {
  return (
    <div className="absolute inset-[8.33%_10.42%_10.42%_8.33%]" data-name="Category">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.875 17.875">
        <g id="Category">
          <path clipRule="evenodd" d={svgPaths.p1b0dd80} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 1" />
          <path clipRule="evenodd" d={svgPaths.p1d036400} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 3" />
          <path clipRule="evenodd" d={svgPaths.pdd4a200} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 5" />
          <path clipRule="evenodd" d={svgPaths.p20c71180} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 7" />
        </g>
      </svg>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[19px] top-[116px]">
      <div className="absolute inset-[10.78%_83.53%_87.17%_7.63%]" data-name="Iconly/Light-Outline/Category">
        <Category />
      </div>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[51px] text-[#7f56d8] text-[16px] top-[117px]">Dashboard</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[52px] top-[174px]">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[52px] text-[#2e2c34] text-[16px] top-[174px]">Tickets</p>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[8.33%_17.33%_8.87%_16.67%]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.52 18.2145">
        <g id="Group 6">
          <g id="Union">
            <path clipRule="evenodd" d={svgPaths.pbece300} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p3a518600} fill="var(--fill-0, #2E2C34)" fillRule="evenodd" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Profile() {
  return (
    <div className="absolute contents inset-[8.33%_17.33%_8.87%_16.67%]" data-name="Profile">
      <Group />
    </div>
  );
}

function IconsaxLinearTicketstar() {
  return (
    <div className="absolute left-[20px] size-[22px] top-[173px]" data-name="Iconsax/Linear/ticketstar">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/ticketstar">
          <path d={svgPaths.p388172f0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p19372c00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function UimAnalytics() {
  return (
    <div className="absolute left-[22px] size-[19px] top-[342px]" data-name="uim:analytics">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19">
        <g id="uim:analytics">
          <path d={svgPaths.pe4b5000} fill="var(--fill-0, #1E1E1E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute h-[1076px] left-0 top-0 w-[249px]" data-name="Sidebar">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[35px] text-[#2e2c34] text-[24px] top-[28px] uppercase">Ticket Lead</p>
      <Group2 />
      <Group1 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[51px] text-[#2e2c34] text-[16px] top-[230px]">{`Users `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[49px] text-[#2e2c34] text-[16px] top-[286px]">{`Add Course `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium h-[19px] leading-[normal] left-[54px] text-[#2e2c34] text-[16px] top-[342px] w-[95px] whitespace-pre-wrap">{`Analysis `}</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[53px] text-[#2e2c34] text-[16px] top-[399px]">Logout</p>
      <div className="absolute left-[22px] size-[22px] top-[397px]" data-name="material-symbols:logout-rounded">
        <div className="absolute inset-[12.5%_14.17%_12.5%_12.5%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.1333 16.5">
            <path d={svgPaths.p25f94200} fill="var(--fill-0, #1E1E1E)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[21.28%_83.53%_76.67%_7.63%]" data-name="Iconly/Light-Outline/Profile">
        <Profile />
      </div>
      <IconsaxLinearTicketstar />
      <UimAnalytics />
      <div className="absolute inset-[26.86%_84.81%_71.96%_8.84%]" data-name="Vector">
        <div className="absolute inset-[-5.92%_-4.74%_-11.06%_-4.74%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.3333 14.8181">
            <path d={svgPaths.pcb33180} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function AlignLeft() {
  return (
    <div className="absolute left-[20px] size-[30px] top-[27px]" data-name="align-left">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="align-left">
          <path d="M22.5 14.5H5" id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 7.5H5" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 21.5H5" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <div className="relative shrink-0 size-[48px]">
        <img alt="" className="absolute block max-w-none size-full" height="48" src={imgEllipse73} width="48" />
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#1a202c] text-[16px] whitespace-nowrap">
        <p className="leading-[normal]">DR Bahlol</p>
      </div>
    </div>
  );
}

function User() {
  return (
    <div className="absolute bg-[#fafafa] content-stretch flex gap-[12px] h-[56px] items-center left-[1019px] pl-[5px] pr-[18px] py-[12px] rounded-[1000px] top-[14px]" data-name="user">
      <Frame />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[20px] top-[14px]">
      <AlignLeft />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[63px] text-[#2e2c34] text-[18px] top-[31px]">{`Welcome! `}</p>
      <User />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[calc(16.67%-3px)] top-0 w-[1263px]">
      <div className="h-[85px] relative shrink-0 w-full" data-name="Top Bar">
        <div className="absolute bg-white h-[85px] left-0 shadow-[0px_4px_40px_1px_rgba(0,0,0,0.03)] top-0 w-[1263px]" />
        <Group3 />
      </div>
    </div>
  );
}

export default function TicketResponse() {
  return (
    <div className="bg-[#f9f9fb] relative size-full" data-name="TicketResponse">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-[calc(16.67%+22px)] text-[#2e2a40] text-[24px] top-[125.5px] whitespace-nowrap">
        <p className="leading-[normal]">Course</p>
      </div>
      <ReplyDetailTicket />
      <Sidebar />
      <Frame1 />
    </div>
  );
}