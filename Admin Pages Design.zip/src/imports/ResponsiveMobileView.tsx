import svgPaths from "./svg-faft9rk4pe";

function Heading1() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-[87.375px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[32px] left-0 text-[#2e2c34] text-[24px] top-[-0.82px]">Tickets</p>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="h-[19.99px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/2 left-[20.83%] right-[20.83%] top-1/2" data-name="Vector">
        <div className="absolute inset-[-0.83px_-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.327 1.66587">
            <path d="M0.832935 0.832935H12.494" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-[20.83%] left-1/2 right-1/2 top-[20.83%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-0.83px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.66587 13.327">
            <path d="M0.832935 0.832935V12.494" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#7f56d8] relative rounded-[10px] shrink-0 size-[35.961px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[7.985px] px-[7.985px] relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="absolute content-stretch flex h-[35.961px] items-center justify-between left-[15.99px] top-[87.97px] w-[338.62px]" data-name="Container">
      <Heading1 />
      <Button />
    </div>
  );
}

function TextInput() {
  return (
    <div className="absolute h-[46.325px] left-0 rounded-[10px] top-0 w-[338.62px]" data-name="Text Input">
      <div className="content-stretch flex items-center overflow-clip pl-[40px] pr-[16px] py-[12px] relative rounded-[inherit] size-full">
        <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] relative shrink-0 text-[14px] text-[rgba(10,10,10,0.5)]">Search for ticket</p>
      </div>
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute left-[11.99px] size-[19.99px] top-[13.17px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g id="Icon">
          <path d={svgPaths.p170afb00} id="Vector" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p14d2c200} id="Vector_2" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
      </svg>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute h-[46.325px] left-[15.99px] top-[147.92px] w-[338.62px]" data-name="Container">
      <TextInput />
      <Icon1 />
    </div>
  );
}

function Container3() {
  return <div className="absolute bg-[#7f56d8] left-[15.99px] rounded-[39602500px] size-[7.985px] top-[15.16px]" data-name="Container" />;
}

function Button1() {
  return (
    <div className="bg-[#7f56d8] h-[38.321px] relative rounded-[10px] shrink-0 w-[117.84px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container3 />
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-[66.96px] text-[14px] text-center text-white top-[9.35px]">All Tickets</p>
      </div>
    </div>
  );
}

function Container4() {
  return <div className="absolute bg-[#3b8aff] left-[17.17px] rounded-[39602500px] size-[7.985px] top-[15.16px]" data-name="Container" />;
}

function Button2() {
  return (
    <div className="bg-white h-[38.321px] relative rounded-[10px] shrink-0 w-[82.322px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container4 />
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-[49.64px] text-[#2e2c34] text-[14px] text-center top-[9.35px]">New</p>
      </div>
    </div>
  );
}

function Container5() {
  return <div className="absolute bg-[#f8a534] left-[17.17px] rounded-[39602500px] size-[7.985px] top-[15.16px]" data-name="Container" />;
}

function Button3() {
  return (
    <div className="bg-white h-[38.321px] relative rounded-[10px] shrink-0 w-[119.389px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container5 />
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-[68.14px] text-[#2e2c34] text-[14px] text-center top-[9.35px]">On-Going</p>
      </div>
    </div>
  );
}

function Container6() {
  return <div className="absolute bg-[#2ecc71] left-[17.17px] rounded-[39602500px] size-[7.985px] top-[15.16px]" data-name="Container" />;
}

function Button4() {
  return (
    <div className="bg-white h-[38.321px] relative rounded-[10px] shrink-0 w-[113.58px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container6 />
        <p className="-translate-x-1/2 absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-[65.64px] text-[#2e2c34] text-[14px] text-center top-[9.35px]">Resolved</p>
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute content-stretch flex gap-[7.985px] h-[68.731px] items-start left-[15.99px] overflow-clip top-[210.23px] w-[338.62px]" data-name="Container">
      <Button1 />
      <Button2 />
      <Button3 />
      <Button4 />
    </div>
  );
}

function Container11() {
  return <div className="bg-[#f8a534] rounded-[39602500px] shrink-0 size-[7.985px]" data-name="Container" />;
}

function Paragraph() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-[137.333px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[#0a0a0a] text-[14px] top-[0.18px]">Ticket# 2023-CS123</p>
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-[153.303px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[7.985px] items-center relative size-full">
        <Container11 />
        <Paragraph />
      </div>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[16.007px] relative shrink-0 w-[51.562px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[16px] relative shrink-0 text-[#84818a] text-[12px]">12:45 AM</p>
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex items-start justify-between relative size-full">
        <Container10 />
        <Paragraph1 />
      </div>
    </div>
  );
}

function Heading3() {
  return (
    <div className="h-[24.011px] relative shrink-0 w-full" data-name="Heading 4">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[24px] left-0 text-[#0a0a0a] text-[16px] top-[0.36px]">How to deposit money to my portal?</p>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[39.981px] overflow-clip relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#84818a] text-[14px] top-[0.18px] w-[286px] whitespace-pre-wrap">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    </div>
  );
}

function Image() {
  return <div className="rounded-[39602500px] shrink-0 size-[23.992px]" data-name="Image" />;
}

function Paragraph3() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-[232.97px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#84818a] text-[14px] top-[0.18px]">From John Snow to Dr.Mohamed</p>
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex gap-[7.985px] h-[23.992px] items-center relative shrink-0 w-full" data-name="Container">
      <Image />
      <Paragraph3 />
    </div>
  );
}

function Container8() {
  return (
    <div className="bg-white h-[170.269px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)]" />
      <div className="content-stretch flex flex-col gap-[7.985px] items-start pb-[1.18px] pt-[17.169px] px-[17.169px] relative size-full">
        <Container9 />
        <Heading3 />
        <Paragraph2 />
        <Container12 />
      </div>
    </div>
  );
}

function Container16() {
  return <div className="bg-[#f8a534] rounded-[39602500px] shrink-0 size-[7.985px]" data-name="Container" />;
}

function Paragraph4() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-[137.333px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[#0a0a0a] text-[14px] top-[0.18px]">Ticket# 2023-CS123</p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-[153.303px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[7.985px] items-center relative size-full">
        <Container16 />
        <Paragraph4 />
      </div>
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="h-[16.007px] relative shrink-0 w-[51.562px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[16px] relative shrink-0 text-[#84818a] text-[12px]">12:45 AM</p>
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex items-start justify-between relative size-full">
        <Container15 />
        <Paragraph5 />
      </div>
    </div>
  );
}

function Heading4() {
  return (
    <div className="h-[24.011px] relative shrink-0 w-full" data-name="Heading 4">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[24px] left-0 text-[#0a0a0a] text-[16px] top-[0.36px]">How to deposit money to my portal?</p>
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="h-[39.981px] overflow-clip relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#84818a] text-[14px] top-[0.18px] w-[286px] whitespace-pre-wrap">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    </div>
  );
}

function Image1() {
  return <div className="rounded-[39602500px] shrink-0 size-[23.992px]" data-name="Image" />;
}

function Paragraph7() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-[232.97px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#84818a] text-[14px] top-[0.18px]">From John Snow to Dr.Mohamed</p>
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="content-stretch flex gap-[7.985px] h-[23.992px] items-center relative shrink-0 w-full" data-name="Container">
      <Image1 />
      <Paragraph7 />
    </div>
  );
}

function Container13() {
  return (
    <div className="bg-white h-[170.269px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)]" />
      <div className="content-stretch flex flex-col gap-[7.985px] items-start pb-[1.18px] pt-[17.169px] px-[17.169px] relative size-full">
        <Container14 />
        <Heading4 />
        <Paragraph6 />
        <Container17 />
      </div>
    </div>
  );
}

function Container21() {
  return <div className="bg-[#f8a534] rounded-[39602500px] shrink-0 size-[7.985px]" data-name="Container" />;
}

function Paragraph8() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-[137.333px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[#0a0a0a] text-[14px] top-[0.18px]">Ticket# 2023-CS123</p>
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-[153.303px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[7.985px] items-center relative size-full">
        <Container21 />
        <Paragraph8 />
      </div>
    </div>
  );
}

function Paragraph9() {
  return (
    <div className="h-[16.007px] relative shrink-0 w-[51.562px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[16px] relative shrink-0 text-[#84818a] text-[12px]">12:45 AM</p>
      </div>
    </div>
  );
}

function Container19() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex items-start justify-between relative size-full">
        <Container20 />
        <Paragraph9 />
      </div>
    </div>
  );
}

function Heading5() {
  return (
    <div className="h-[24.011px] relative shrink-0 w-full" data-name="Heading 4">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[24px] left-0 text-[#0a0a0a] text-[16px] top-[0.36px]">How to deposit money to my portal?</p>
    </div>
  );
}

function Paragraph10() {
  return (
    <div className="h-[39.981px] overflow-clip relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#84818a] text-[14px] top-[0.18px] w-[286px] whitespace-pre-wrap">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    </div>
  );
}

function Image2() {
  return <div className="rounded-[39602500px] shrink-0 size-[23.992px]" data-name="Image" />;
}

function Paragraph11() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-[232.97px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#84818a] text-[14px] top-[0.18px]">From John Snow to Dr.Mohamed</p>
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="content-stretch flex gap-[7.985px] h-[23.992px] items-center relative shrink-0 w-full" data-name="Container">
      <Image2 />
      <Paragraph11 />
    </div>
  );
}

function Container18() {
  return (
    <div className="bg-white h-[170.269px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)]" />
      <div className="content-stretch flex flex-col gap-[7.985px] items-start pb-[1.18px] pt-[17.169px] px-[17.169px] relative size-full">
        <Container19 />
        <Heading5 />
        <Paragraph10 />
        <Container22 />
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[15.989px] h-[542.784px] items-start left-[15.99px] top-[302.95px] w-[338.62px]" data-name="Container">
      <Container8 />
      <Container13 />
      <Container18 />
    </div>
  );
}

function TicketsScreen() {
  return (
    <div className="bg-[#f9f9fb] h-[869.731px] relative shrink-0 w-full" data-name="TicketsScreen">
      <Container />
      <Container1 />
      <Container2 />
      <Container7 />
    </div>
  );
}

function Body() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[853.319px] items-start left-0 top-0 w-[370.598px]" data-name="Body">
      <TicketsScreen />
    </div>
  );
}

function Icon2() {
  return (
    <div className="h-[23.992px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.83%_16.67%_79.17%_16.67%]" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-1/2 left-[16.67%] right-[16.67%] top-1/2" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[79.17%_16.67%_20.83%_16.67%]" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div className="relative rounded-[10px] shrink-0 size-[39.962px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[7.985px] px-[7.985px] relative size-full">
        <Icon2 />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[27.994px] relative shrink-0 w-[121.842px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[28px] left-0 text-[#2e2c34] text-[18px] top-[-0.64px]">TICKET LEAD</p>
      </div>
    </div>
  );
}

function ImageUser() {
  return <div className="rounded-[39602500px] shrink-0 size-[39.999px]" data-name="Image (User)" />;
}

function App() {
  return (
    <div className="absolute bg-white content-stretch flex h-[63.973px] items-center justify-between left-0 pl-[8.004px] pr-[15.989px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] top-[1.18px] w-[370.598px]" data-name="App">
      <Button5 />
      <Heading />
      <ImageUser />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[28.012px] relative shrink-0 w-full" data-name="Heading 2">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[28px] left-0 text-[#2e2c34] text-[20px] top-[-0.82px] uppercase">Ticket Lead</p>
    </div>
  );
}

function Icon3() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g id="Icon">
          <path d={svgPaths.p347b5000} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p2310bb80} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p33187040} id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p1add1340} id="Vector_4" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon3 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Dashboard</p>
    </div>
  );
}

function Icon4() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g clipPath="url(#clip0_1_3615)" id="Icon">
          <path d={svgPaths.p26db4f00} id="Vector" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 4.16467V5.83054" id="Vector_2" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 14.1599V15.8258" id="Vector_3" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 9.16228V10.8282" id="Vector_4" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
        <defs>
          <clipPath id="clip0_1_3615">
            <rect fill="white" height="19.9904" width="19.9904" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="bg-[rgba(127,86,216,0.2)] h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon4 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#7f56d8] text-[16px] top-[12.35px]">Tickets</p>
    </div>
  );
}

function Icon5() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g clipPath="url(#clip0_1_3581)" id="Icon">
          <path d={svgPaths.p242da100} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p31dd1980} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p19a3b080} id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p29dffb00} id="Vector_4" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
        <defs>
          <clipPath id="clip0_1_3581">
            <rect fill="white" height="19.9904" width="19.9904" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon5 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Users</p>
    </div>
  );
}

function Icon6() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g clipPath="url(#clip0_1_3570)" id="Icon">
          <path d="M9.99522 5.83054V17.4916" id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p1e385f00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
        <defs>
          <clipPath id="clip0_1_3570">
            <rect fill="white" height="19.9904" width="19.9904" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button9() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon6 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Courses</p>
    </div>
  );
}

function Icon7() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g id="Icon">
          <path d={svgPaths.p1f3f330} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M14.9928 14.1599V7.49641" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M10.8282 14.1599V4.16467" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M6.66348 14.1599V11.6611" id="Vector_4" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
      </svg>
    </div>
  );
}

function Button10() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon7 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Analysis</p>
    </div>
  );
}

function Icon8() {
  return (
    <div className="absolute left-[15.99px] size-[19.99px] top-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.9904 19.9904">
        <g id="Icon">
          <path d={svgPaths.p16840600} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d="M17.4916 9.99522H7.49641" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
          <path d={svgPaths.p543d000} id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66587" />
        </g>
      </svg>
    </div>
  );
}

function Button11() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon8 />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-[47.97px] text-[#2e2c34] text-[16px] top-[12.35px]">Logout</p>
    </div>
  );
}

function Navigation() {
  return (
    <div className="content-stretch flex flex-col gap-[7.985px] h-[327.832px] items-start relative shrink-0 w-full" data-name="Navigation">
      <Button6 />
      <Button7 />
      <Button8 />
      <Button9 />
      <Button10 />
      <Button11 />
    </div>
  );
}

function Container23() {
  return (
    <div className="h-[435.825px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col gap-[31.996px] items-start pt-[23.992px] px-[23.992px] relative size-full">
        <Heading2 />
        <Navigation />
      </div>
    </div>
  );
}

function App1() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[853.319px] items-start left-[-255.98px] pr-[1.18px] top-[1.18px] w-[255.984px]" data-name="App">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-r-[1.18px] border-solid inset-0 pointer-events-none" />
      <Container23 />
    </div>
  );
}

export default function ResponsiveMobileView() {
  return (
    <div className="bg-white relative size-full" data-name="Responsive Mobile View">
      <Body />
      <App />
      <App1 />
    </div>
  );
}