import { useState, useCallback } from 'react';
import type { Ticket, User, Course, DoctorAnalytics, TicketReply } from '../types';

// API Response Types
interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
}

interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
}

// API Base URL - Update this with your backend URL
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000/api';

interface UseApiOptions {
  onSuccess?: (data: any) => void;
  onError?: (error: Error) => void;
}

export function useApi<T = any>(options?: UseApiOptions) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const request = useCallback(
    async (endpoint: string, config?: RequestInit): Promise<ApiResponse<T>> => {
      setLoading(true);
      setError(null);

      try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
          ...config,
          headers: {
            'Content-Type': 'application/json',
            ...config?.headers,
          },
        });

        if (!response.ok) {
          throw new Error(`API Error: ${response.statusText}`);
        }

        const data: ApiResponse<T> = await response.json();
        
        if (options?.onSuccess) {
          options.onSuccess(data.data);
        }

        return data;
      } catch (err) {
        const error = err instanceof Error ? err : new Error('Unknown error');
        setError(error);
        
        if (options?.onError) {
          options.onError(error);
        }

        throw error;
      } finally {
        setLoading(false);
      }
    },
    [options]
  );

  return { request, loading, error };
}

// Specific API hooks for different resources
export function useTicketsApi() {
  const { request, loading, error } = useApi<Ticket[]>();

  const getTickets = useCallback(
    async (params?: { status?: string; page?: number; limit?: number }) => {
      const queryParams = new URLSearchParams();
      if (params?.status) queryParams.append('status', params.status);
      if (params?.page) queryParams.append('page', params.page.toString());
      if (params?.limit) queryParams.append('limit', params.limit.toString());

      return request(`/tickets?${queryParams.toString()}`);
    },
    [request]
  );

  const getTicketById = useCallback(
    async (id: string) => {
      return request(`/tickets/${id}`);
    },
    [request]
  );

  const createTicket = useCallback(
    async (ticketData: Partial<Ticket>) => {
      return request('/tickets', {
        method: 'POST',
        body: JSON.stringify(ticketData),
      });
    },
    [request]
  );

  const updateTicket = useCallback(
    async (id: string, ticketData: Partial<Ticket>) => {
      return request(`/tickets/${id}`, {
        method: 'PUT',
        body: JSON.stringify(ticketData),
      });
    },
    [request]
  );

  const deleteTicket = useCallback(
    async (id: string) => {
      return request(`/tickets/${id}`, {
        method: 'DELETE',
      });
    },
    [request]
  );

  const addResponse = useCallback(
    async (ticketId: string, responseData: Partial<TicketReply>) => {
      return request(`/tickets/${ticketId}/responses`, {
        method: 'POST',
        body: JSON.stringify(responseData),
      });
    },
    [request]
  );

  return {
    getTickets,
    getTicketById,
    createTicket,
    updateTicket,
    deleteTicket,
    addResponse,
    loading,
    error,
  };
}

export function useUsersApi() {
  const { request, loading, error } = useApi<User[]>();

  const getUsers = useCallback(
    async (params?: { role?: string; page?: number; limit?: number }) => {
      const queryParams = new URLSearchParams();
      if (params?.role) queryParams.append('role', params.role);
      if (params?.page) queryParams.append('page', params.page.toString());
      if (params?.limit) queryParams.append('limit', params.limit.toString());

      return request(`/users?${queryParams.toString()}`);
    },
    [request]
  );

  const getUserById = useCallback(
    async (id: string) => {
      return request(`/users/${id}`);
    },
    [request]
  );

  const createUser = useCallback(
    async (userData: Partial<User>) => {
      return request('/users', {
        method: 'POST',
        body: JSON.stringify(userData),
      });
    },
    [request]
  );

  const updateUser = useCallback(
    async (id: string, userData: Partial<User>) => {
      return request(`/users/${id}`, {
        method: 'PUT',
        body: JSON.stringify(userData),
      });
    },
    [request]
  );

  const deleteUser = useCallback(
    async (id: string) => {
      return request(`/users/${id}`, {
        method: 'DELETE',
      });
    },
    [request]
  );

  return {
    getUsers,
    getUserById,
    createUser,
    updateUser,
    deleteUser,
    loading,
    error,
  };
}

// Courses API
export function useCoursesApi() {
  const { request, loading, error } = useApi<Course[]>();

  const getCourses = useCallback(
    async (params?: { level?: string; semester?: string; page?: number; limit?: number }) => {
      const queryParams = new URLSearchParams();
      if (params?.level) queryParams.append('level', params.level);
      if (params?.semester) queryParams.append('semester', params.semester);
      if (params?.page) queryParams.append('page', params.page.toString());
      if (params?.limit) queryParams.append('limit', params.limit.toString());

      return request(`/courses?${queryParams.toString()}`);
    },
    [request]
  );

  const getCourseById = useCallback(
    async (id: string) => {
      return request(`/courses/${id}`);
    },
    [request]
  );

  const createCourse = useCallback(
    async (courseData: Partial<Course>) => {
      return request('/courses', {
        method: 'POST',
        body: JSON.stringify(courseData),
      });
    },
    [request]
  );

  const updateCourse = useCallback(
    async (id: string, courseData: Partial<Course>) => {
      return request(`/courses/${id}`, {
        method: 'PUT',
        body: JSON.stringify(courseData),
      });
    },
    [request]
  );

  const deleteCourse = useCallback(
    async (id: string) => {
      return request(`/courses/${id}`, {
        method: 'DELETE',
      });
    },
    [request]
  );

  const assignDoctor = useCallback(
    async (courseId: string, doctorId: string) => {
      return request(`/courses/${courseId}/doctors`, {
        method: 'POST',
        body: JSON.stringify({ doctorId }),
      });
    },
    [request]
  );

  const removeDoctor = useCallback(
    async (courseId: string, doctorId: string) => {
      return request(`/courses/${courseId}/doctors/${doctorId}`, {
        method: 'DELETE',
      });
    },
    [request]
  );

  return {
    getCourses,
    getCourseById,
    createCourse,
    updateCourse,
    deleteCourse,
    assignDoctor,
    removeDoctor,
    loading,
    error,
  };
}

// Analytics API
export function useAnalyticsApi() {
  const { request, loading, error } = useApi<DoctorAnalytics[]>();

  const getDoctorAnalytics = useCallback(
    async (params?: { level?: string }) => {
      const queryParams = new URLSearchParams();
      if (params?.level) queryParams.append('level', params.level);

      return request(`/analytics/doctors?${queryParams.toString()}`);
    },
    [request]
  );

  const getDashboardStats = useCallback(
    async () => {
      return request('/analytics/dashboard');
    },
    [request]
  );

  return {
    getDoctorAnalytics,
    getDashboardStats,
    loading,
    error,
  };
}