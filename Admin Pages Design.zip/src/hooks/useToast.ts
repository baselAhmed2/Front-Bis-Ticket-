import { useState, useCallback } from 'react';
import type { ToastMessage, ToastType } from '../components/common/ToastContainer';

export function useToast() {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((type: ToastType, title: string, message: string) => {
    const id = Date.now().toString();
    setToasts((prev) => [...prev, { id, type, title, message }]);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  }, []);

  const showSuccess = useCallback((title: string, message: string) => {
    addToast('success', title, message);
  }, [addToast]);

  const showError = useCallback((title: string, message: string) => {
    addToast('error', title, message);
  }, [addToast]);

  const showWarning = useCallback((title: string, message: string) => {
    addToast('warning', title, message);
  }, [addToast]);

  const showInfo = useCallback((title: string, message: string) => {
    addToast('info', title, message);
  }, [addToast]);

  return {
    toasts,
    removeToast,
    showSuccess,
    showError,
    showWarning,
    showInfo,
  };
}
