import { useState } from 'react';
import { TicketFilters } from '../components/tickets/TicketFilters';
import { TicketCard } from '../components/tickets/TicketCard';
import { Pagination } from '../components/common/Pagination';
import { mockTickets } from '../data/mockData';

interface TicketsPageProps {
  onNavigate: (page: string, data?: any) => void;
}

export function TicketsPage({ onNavigate }: TicketsPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // Filter tickets based on search and status
  const filteredTickets = mockTickets.filter((ticket) => {
    const matchesSearch =
      ticket.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.studentName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesFilter = activeFilter === 'all' || ticket.status === activeFilter;

    return matchesSearch && matchesFilter;
  });

  // Pagination
  const totalPages = Math.ceil(filteredTickets.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedTickets = filteredTickets.slice(startIndex, startIndex + itemsPerPage);

  return (
    <div className="space-y-6">
      <h2 className="font-['Montserrat'] font-semibold text-[20px] md:text-[24px] text-[#2e2c34]">
        Tickets
      </h2>

      <TicketFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        activeFilter={activeFilter}
        onFilterChange={(filter) => {
          setActiveFilter(filter);
          setCurrentPage(1);
        }}
        onNewTicket={() => onNavigate('new-ticket')}
      />

      {paginatedTickets.length === 0 ? (
        <div className="bg-white rounded-lg border border-[#e7e7e7] p-12 text-center">
          <p className="font-['Montserrat'] font-medium text-[16px] text-[#84818a]">
            No tickets found
          </p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4">
            {paginatedTickets.map((ticket) => (
              <TicketCard
                key={ticket.id}
                ticket={ticket}
                onClick={() => onNavigate('ticket-detail', ticket)}
              />
            ))}
          </div>

          {totalPages > 1 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          )}
        </>
      )}
    </div>
  );
}
