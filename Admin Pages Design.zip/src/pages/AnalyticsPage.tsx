import { useState } from 'react';
import { mockDoctorAnalytics } from '../data/mockData';

interface AnalyticsPageProps {
  onNavigate: (page: string) => void;
}

export function AnalyticsPage({ onNavigate }: AnalyticsPageProps) {
  const [activeTab, setActiveTab] = useState('Level 1');
  
  const tabs = ['Level 1', 'Level 2', 'Level 3', 'Level 4'];

  // Filter analytics by level
  const filteredAnalytics = mockDoctorAnalytics.filter(
    (doctor) => doctor.level === activeTab
  );

  return (
    <div className="space-y-6">
      <h2 className="font-['Montserrat'] font-semibold text-[20px] md:text-[24px] text-[#2e2c34]">
        Most Doctors Get Tickets
      </h2>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-6 py-2.5 rounded font-['Montserrat'] font-medium text-[14px] whitespace-nowrap transition-colors ${
              activeTab === tab
                ? 'bg-[#7f56d8] text-white'
                : 'bg-white text-[#2e2c34] border border-[#e7e7e7] hover:bg-gray-50'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Doctors List */}
      <div className="space-y-4">
        {filteredAnalytics.map((doctor) => (
          <div
            key={doctor.id}
            className="bg-white border border-[#e7e7e7] rounded-lg p-4 md:p-6"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-[#3B8AFF]" />
                <div>
                  <p className="font-['Montserrat'] font-semibold text-[14px] md:text-[16px] text-[#2e2c34]">
                    Doctor ID: {doctor.doctorId}
                  </p>
                  <p className="font-['Montserrat'] font-medium text-[14px] text-[#2e2c34]">
                    Name: {doctor.name}
                  </p>
                </div>
              </div>

              <div className="flex gap-8 md:gap-12">
                <div className="text-center">
                  <p className="font-['Montserrat'] font-medium text-[12px] text-[#84818a] mb-1">
                    Total Tickets
                  </p>
                  <p className="font-['Montserrat'] font-bold text-[20px] md:text-[24px] text-[#2e2c34]">
                    {doctor.totalTickets}
                  </p>
                </div>
                <div className="text-center">
                  <p className="font-['Montserrat'] font-medium text-[12px] text-[#84818a] mb-1">
                    Closed
                  </p>
                  <p className="font-['Montserrat'] font-bold text-[20px] md:text-[24px] text-[#2e2c34]">
                    {doctor.closedTickets}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
