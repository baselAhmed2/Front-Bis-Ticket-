import { StatsCard } from '../components/dashboard/StatsCard';
import { TicketCard } from '../components/tickets/TicketCard';
import { mockTickets } from '../data/mockData';

interface DashboardPageProps {
  onNavigate: (page: string, data?: any) => void;
}

export function DashboardPage({ onNavigate }: DashboardPageProps) {
  return (
    <div className="space-y-6">
      <h2 className="font-['Montserrat'] font-semibold text-[20px] md:text-[24px] text-[#2e2c34]">
        Dashboard
      </h2>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        <StatsCard
          title="New Tickets"
          count={20}
          gradient="from-[#00e5be] to-[#00c9a7]"
          onClick={() => onNavigate('tickets')}
        />
        <StatsCard
          title="In Progress"
          count={750}
          gradient="from-[#ffd666] to-[#ffcc4d]"
          onClick={() => onNavigate('tickets')}
        />
        <StatsCard
          title="Closed"
          count={150}
          gradient="from-[#e879f9] to-[#d946ef]"
          onClick={() => onNavigate('tickets')}
        />
      </div>

      {/* My Tickets Section */}
      <div>
        <h3 className="font-['Montserrat'] font-semibold text-[18px] md:text-[20px] text-[#2e2c34] mb-4">
          My Tickets
        </h3>

        <div className="space-y-4">
          {mockTickets.slice(0, 2).map((ticket) => (
            <TicketCard
              key={ticket.id}
              ticket={ticket}
              onClick={() => onNavigate('ticket-detail', ticket)}
            />
          ))}
        </div>

        <div className="mt-4 flex justify-center">
          <button
            onClick={() => onNavigate('analytics')}
            className="font-['Montserrat'] font-medium text-[14px] text-[#7f56d8] hover:underline"
          >
            View Most Doctors Get Tickets →
          </button>
        </div>
      </div>
    </div>
  );
}