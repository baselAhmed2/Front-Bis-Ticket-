import { useState } from 'react';
import { Search, Plus, Trash2 } from 'lucide-react';
import { mockUsers } from '../data/mockData';
import { Pagination } from '../components/common/Pagination';
import type { User } from '../types';

interface UsersPageProps {
  onNavigate: (page: string, data?: any) => void;
  onDeleteUser: (userId: string) => void;
}

export function UsersPage({ onNavigate, onDeleteUser }: UsersPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 4;

  const filters = [
    { id: 'all', label: 'All Users', icon: '👥' },
    { id: 'student', label: 'Students', color: '#F8A534' },
    { id: 'doctor', label: 'Doctors', color: '#3B8AFF' },
    { id: 'admin', label: 'Admins', color: '#00CC99' },
  ];

  // Filter users
  const filteredUsers = mockUsers.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (user.ssn && user.ssn.includes(searchQuery));

    const matchesFilter = activeFilter === 'all' || user.role === activeFilter;

    return matchesSearch && matchesFilter;
  });

  // Pagination
  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedUsers = filteredUsers.slice(startIndex, startIndex + itemsPerPage);

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'doctor':
        return 'bg-[#3B8AFF]';
      case 'student':
        return 'bg-[#F8A534]';
      case 'admin':
        return 'bg-[#00CC99]';
      default:
        return 'bg-gray-400';
    }
  };

  const getRoleLabel = (role: string) => {
    return role.charAt(0).toUpperCase() + role.slice(1);
  };

  return (
    <div className="space-y-6">
      <h2 className="font-['Montserrat'] font-semibold text-[20px] md:text-[24px] text-[#2e2c34]">
        Users
      </h2>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search By User ID"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 border border-[#e7e7e7] rounded-md font-['Montserrat'] text-[14px] focus:outline-none focus:border-[#7f56d8]"
            />
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-3 items-center">
            {filters.slice(1).map((filter) => (
              <div key={filter.id} className="flex items-center gap-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: filter.color }}
                />
                <span className="font-['Montserrat'] font-medium text-[13px] text-[#2e2c34]">
                  {filter.label}
                </span>
              </div>
            ))}
          </div>

          <button
            onClick={() => onNavigate('new-user')}
            className="bg-[#7f56d8] text-white px-4 py-2.5 rounded-md flex items-center justify-center gap-2 hover:bg-[#6b47c2] transition-colors font-['Montserrat'] font-semibold text-[14px] whitespace-nowrap"
          >
            <Plus className="w-5 h-5" />
            <span>New User</span>
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-2 md:gap-4">
          {filters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => {
                setActiveFilter(filter.id);
                setCurrentPage(1);
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-md font-['Montserrat'] font-medium text-[13px] md:text-[14px] transition-colors ${
                activeFilter === filter.id
                  ? 'bg-[#7f56d8] text-white'
                  : 'bg-white text-[#2e2c34] border border-[#e7e7e7] hover:border-[#7f56d8]'
              }`}
            >
              {filter.icon && <span>{filter.icon}</span>}
              <span>{filter.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Users List */}
      {paginatedUsers.length === 0 ? (
        <div className="bg-white rounded-lg border border-[#e7e7e7] p-12 text-center">
          <p className="font-['Montserrat'] font-medium text-[16px] text-[#84818a]">
            No users found
          </p>
        </div>
      ) : (
        <>
          <div className="space-y-4">
            {paginatedUsers.map((user) => (
              <div
                key={user.id}
                className="bg-white border border-[#e7e7e7] rounded-lg p-4 md:p-6"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-start gap-3 flex-1">
                    <div className={`w-4 h-4 rounded-full mt-1 ${getRoleColor(user.role)}`} />
                    
                    <div className="flex-1 space-y-2">
                      <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                        <p className="font-['Montserrat'] font-semibold text-[14px] md:text-[16px] text-[#2e2c34]">
                          User ID : {user.id}
                        </p>
                      </div>

                      <div className="space-y-1 text-[13px] md:text-[14px]">
                        <p className="font-['Montserrat'] font-medium text-[#2e2c34]">
                          {getRoleLabel(user.role)} : {user.name}
                        </p>
                        {user.ssn && (
                          <p className="font-['Montserrat'] font-medium text-[#2e2c34]">
                            SSN : {user.ssn}
                          </p>
                        )}
                        {user.courseId && (
                          <p className="font-['Montserrat'] font-medium text-[#2e2c34]">
                            Course ID : {user.courseId}
                          </p>
                        )}
                        {user.courseName && (
                          <p className="font-['Montserrat'] font-medium text-[#2e2c34]">
                            Name : {user.courseName}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 justify-between md:justify-end">
                    <span className="font-['Montserrat'] font-medium text-[12px] text-[#84818a]">
                      Created At {new Date(user.createdAt).toLocaleDateString()}
                    </span>

                    <div className="flex gap-2">
                      <button
                        onClick={() => onNavigate('user-detail', user)}
                        className="bg-[#7f56d8] text-white px-4 py-2 rounded font-['Montserrat'] font-semibold text-[13px] md:text-[14px] hover:bg-[#6b47c2] transition-colors"
                      >
                        View Details
                      </button>
                      <button
                        onClick={() => onDeleteUser(user.id)}
                        className="bg-[#e7000b] text-white px-4 py-2 rounded font-['Montserrat'] font-semibold text-[13px] md:text-[14px] hover:bg-[#c50009] transition-colors flex items-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span className="hidden sm:inline">Delete User</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {totalPages > 1 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          )}
        </>
      )}
    </div>
  );
}
