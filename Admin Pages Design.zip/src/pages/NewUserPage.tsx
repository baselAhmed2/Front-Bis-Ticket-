import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface NewUserPageProps {
  onSubmit: (userData: any) => void;
  onBack: () => void;
}

export function NewUserPage({ onSubmit, onBack }: NewUserPageProps) {
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    ssn: '',
    role: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.id || !formData.name || !formData.ssn || !formData.role) {
      return;
    }
    onSubmit(formData);
  };

  return (
    <div className="w-full">
      {/* Header */}
      <div className="mb-6">
        <h1 className="font-['Montserrat'] font-semibold text-[24px] leading-[36px] text-[#2e2c34]">
          New User
        </h1>
      </div>

      {/* Form Card */}
      <div className="bg-white border border-[#e7e7e7] rounded-[10px] p-6">
        {/* Card Header */}
        <div className="mb-6">
          <h2 className="font-['Montserrat'] font-semibold text-[18px] leading-[27px] text-[#2e2a40] mb-2">
            Create User Account
          </h2>
          <p className="font-['Montserrat'] font-medium text-[16px] leading-[24px] text-[#84818a]">
            Fill in the user information below
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Two Fields Row - User ID and Name */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* User ID */}
            <div className="flex flex-col gap-2">
              <label className="font-['Montserrat'] font-medium text-[14px] leading-[21px] text-[#2e2a40]">
                User ID <span className="text-[#e7000b]">*</span>
              </label>
              <input
                type="text"
                placeholder="Enter User ID"
                value={formData.id}
                onChange={(e) => setFormData({ ...formData, id: e.target.value })}
                className="w-full h-[48px] bg-white border border-[#e7e7e7] rounded-[4px] px-4 font-['Montserrat'] font-medium text-[14px] text-[#2e2a40] placeholder:text-[#757575] focus:outline-none focus:border-[#7f56d8]"
                required
              />
            </div>

            {/* Name */}
            <div className="flex flex-col gap-2">
              <label className="font-['Montserrat'] font-medium text-[14px] leading-[21px] text-[#2e2a40]">
                Full Name <span className="text-[#e7000b]">*</span>
              </label>
              <input
                type="text"
                placeholder="Enter Full Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full h-[48px] bg-white border border-[#e7e7e7] rounded-[4px] px-4 font-['Montserrat'] font-medium text-[14px] text-[#2e2a40] placeholder:text-[#757575] focus:outline-none focus:border-[#7f56d8]"
                required
              />
            </div>
          </div>

          {/* Two Fields Row - SSN and Role */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* SSN */}
            <div className="flex flex-col gap-2">
              <label className="font-['Montserrat'] font-medium text-[14px] leading-[21px] text-[#2e2a40]">
                SSN <span className="text-[#e7000b]">*</span>
              </label>
              <input
                type="text"
                placeholder="Enter SSN Number"
                value={formData.ssn}
                onChange={(e) => setFormData({ ...formData, ssn: e.target.value })}
                className="w-full h-[48px] bg-white border border-[#e7e7e7] rounded-[4px] px-4 font-['Montserrat'] font-medium text-[14px] text-[#2e2a40] placeholder:text-[#757575] focus:outline-none focus:border-[#7f56d8]"
                required
              />
            </div>

            {/* Role */}
            <div className="flex flex-col gap-2">
              <label className="font-['Montserrat'] font-medium text-[14px] leading-[21px] text-[#2e2a40]">
                User Role <span className="text-[#e7000b]">*</span>
              </label>
              <div className="relative">
                <select
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  className="w-full h-[48px] bg-white border border-[#e7e7e7] rounded-[4px] px-4 font-['Montserrat'] font-medium text-[14px] text-[#2e2a40] appearance-none focus:outline-none focus:border-[#7f56d8] cursor-pointer"
                  required
                >
                  <option value="" disabled>Select User Role</option>
                  <option value="student">Student</option>
                  <option value="doctor">Doctor</option>
                  <option value="admin">Admin</option>
                </select>
                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#bababa] pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              className="bg-[#7f56d8] hover:bg-[#6b47c2] text-white h-[40px] px-8 rounded-[4px] font-['Montserrat'] font-semibold text-[14px] leading-[21px] transition-colors"
            >
              Create User
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
