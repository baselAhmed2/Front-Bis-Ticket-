import { useState } from 'react';
import { ArrowLeft, ChevronDown } from 'lucide-react';

interface NewCoursePageProps {
  onSubmit: (courseData: any) => void;
  onBack: () => void;
}

export function NewCoursePage({ onSubmit, onBack }: NewCoursePageProps) {
  const [formData, setFormData] = useState({
    level: 'Level 4',
    semester: 'Semester 1',
    subjectId: '',
    courseName: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="space-y-6">
      {/* Back Button - Mobile */}
      <button
        onClick={onBack}
        className="md:hidden flex items-center gap-2 text-[#7f56d8] font-['Montserrat'] font-medium"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Courses</span>
      </button>

      <h2 className="font-['Montserrat'] font-semibold text-[20px] md:text-[24px] text-[#2e2c34]">
        New Course
      </h2>

      <form onSubmit={handleSubmit}>
        <div className="bg-white rounded-lg border border-[#e7e7e7] p-4 md:p-6">
          <div className="mb-6">
            <h3 className="font-['Montserrat'] font-semibold text-[16px] md:text-[18px] text-[#2e2a40] mb-1">
              Create Course
            </h3>
            <p className="font-['Montserrat'] font-medium text-[14px] md:text-[16px] text-[#84818a]">
              Write and address new Course
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-6">
            {/* Level */}
            <div className="space-y-2">
              <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
                Choose Level <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <select
                  value={formData.level}
                  onChange={(e) => setFormData({ ...formData, level: e.target.value })}
                  className="w-full bg-white border border-[#e7e7e7] rounded px-4 py-3 font-['Montserrat'] font-medium text-[14px] text-[#757575] appearance-none focus:outline-none focus:border-[#7f56d8]"
                  required
                >
                  <option>Level 1</option>
                  <option>Level 2</option>
                  <option>Level 3</option>
                  <option>Level 4</option>
                </select>
                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#bababa] pointer-events-none" />
              </div>
            </div>

            {/* Semester */}
            <div className="space-y-2">
              <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
                Choose Semester <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <select
                  value={formData.semester}
                  onChange={(e) => setFormData({ ...formData, semester: e.target.value })}
                  className="w-full bg-white border border-[#e7e7e7] rounded px-4 py-3 font-['Montserrat'] font-medium text-[14px] text-[#2e2a40] appearance-none focus:outline-none focus:border-[#7f56d8]"
                  required
                >
                  <option>Semester 1</option>
                  <option>Semester 2</option>
                </select>
                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#bababa] pointer-events-none" />
              </div>
            </div>

            {/* Subject ID */}
            <div className="space-y-2">
              <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
                Subject ID <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="Enter Subject ID"
                value={formData.subjectId}
                onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                className="w-full bg-white border border-[#e7e7e7] rounded px-4 py-3 font-['Montserrat'] font-medium text-[14px] text-[#757575] focus:outline-none focus:border-[#7f56d8]"
                required
              />
            </div>
          </div>

          {/* Course Name */}
          <div className="space-y-2 mb-6">
            <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
              Course Name <span className="text-[#e7000b]">*</span>
            </label>
            <input
              type="text"
              placeholder="Enter Course Name"
              value={formData.courseName}
              onChange={(e) => setFormData({ ...formData, courseName: e.target.value })}
              className="w-full bg-white border border-[#e7e7e7] rounded px-4 py-3 font-['Montserrat'] font-medium text-[14px] text-[#757575] focus:outline-none focus:border-[#7f56d8]"
              required
            />
          </div>

          {/* Submit Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              className="bg-[#7f56d8] text-white px-8 py-2.5 rounded font-['Montserrat'] font-semibold text-[14px] hover:bg-[#6b47c2] transition-colors"
            >
              Save
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
