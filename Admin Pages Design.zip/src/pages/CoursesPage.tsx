import { useState } from 'react';
import { Plus } from 'lucide-react';
import { mockCourses } from '../data/mockData';

interface CoursesPageProps {
  onNavigate: (page: string, data?: any) => void;
}

export function CoursesPage({ onNavigate }: CoursesPageProps) {
  const [searchQuery, setSearchQuery] = useState('');

  // Filter courses based on search
  const filteredCourses = mockCourses.filter((course) =>
    course.courseName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.courseId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-['Montserrat'] font-semibold text-[20px] md:text-[24px] text-[#2e2c34]">
          Courses
        </h2>
        <button
          onClick={() => onNavigate('new-course')}
          className="bg-[#7f56d8] text-white px-4 py-2 rounded-lg flex items-center gap-2 font-['Montserrat'] font-semibold text-[14px] hover:bg-[#6b47c2] transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Add Course</span>
        </button>
      </div>

      {/* Search */}
      <div className="flex gap-4">
        <input
          type="text"
          placeholder="Search courses..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1 bg-[#fbfbfb] border border-[#e7e7e7] rounded px-4 py-2.5 font-['Montserrat'] font-medium text-[14px] focus:outline-none focus:border-[#7f56d8]"
        />
      </div>

      {/* Courses List */}
      {filteredCourses.length === 0 ? (
        <div className="bg-white rounded-lg border border-[#e7e7e7] p-12 text-center">
          <p className="font-['Montserrat'] font-medium text-[16px] text-[#84818a]">
            No courses found
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredCourses.map((course) => (
            <div
              key={course.id}
              onClick={() => onNavigate('course-detail', course)}
              className="bg-white border border-[#e7e7e7] rounded-lg p-4 md:p-6 cursor-pointer hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-['Montserrat'] font-semibold text-[16px] md:text-[18px] text-[#2e2c34] mb-2">
                    {course.courseName}
                  </h3>
                  <p className="font-['Montserrat'] font-medium text-[14px] text-[#84818a]">
                    Course ID: {course.courseId}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-[#F8A534] bg-opacity-60" />
                  <span className="font-['Montserrat'] font-medium text-[14px] text-[#757575]">
                    {course.level}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <p className="font-['Montserrat'] font-medium text-[12px] md:text-[13px] text-[#84818a]">
                  {course.assignedDoctors.length} Doctor(s) Assigned • {course.semester}
                </p>
                <button className="font-['Montserrat'] font-medium text-[13px] md:text-[14px] text-[#7f56d8] hover:underline">
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
