import { useState, useEffect } from 'react';
import { Trash2, AlertCircle } from 'lucide-react';

interface SiteSettingsPageProps {
  onNavigate: (page: string) => void;
}

export function SiteSettingsPage({ onNavigate }: SiteSettingsPageProps) {
  const [countdown, setCountdown] = useState<number | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    if (countdown === null || countdown <= 0) return;

    const timer = setTimeout(() => {
      setCountdown(countdown - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [countdown]);

  const handleDeleteClick = () => {
    if (countdown === null) {
      // Start countdown
      setCountdown(10);
    } else if (countdown === 0) {
      // Execute delete
      setIsDeleting(true);
      // TODO: Integrate with API to delete all tickets data
      console.log('Deleting all tickets data...');
      
      // Reset after execution
      setTimeout(() => {
        setCountdown(null);
        setIsDeleting(false);
      }, 2000);
    }
  };

  const canDelete = countdown === 0;

  return (
    <div className="w-full">
      {/* Header */}
      <div className="mb-6">
        <h1 className="font-['Montserrat'] font-semibold text-[24px] leading-[36px] text-[#2e2c34]">
          Site Settings
        </h1>
      </div>

      {/* Warning Card */}
      <div className="bg-white border border-[#e7e7e7] rounded-[10px] overflow-hidden">
        {/* Card Content */}
        <div className="p-6">
          {/* Header with Icon */}
          <div className="flex items-start gap-3 mb-4">
            <div className="flex-shrink-0 w-[22px] h-[22px]">
              <svg className="w-full h-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
                <circle cx="11" cy="11" fill="#3B8AFF" r="11" />
              </svg>
            </div>
            <div>
              <h2 className="font-['Montserrat'] font-semibold text-[16px] leading-[14px] text-[#2e2c34] mb-3">
                Delete all Tickets Data
              </h2>
              <p className="font-['Montserrat'] font-medium text-[12px] leading-[14px] text-[#84818a]">
                Created At 22-11-2024
              </p>
            </div>
          </div>

          {/* Warning Message */}
          <div className="mb-6">
            <p className="font-['Montserrat'] font-medium text-[14px] leading-[14px] text-[#2e2c34]">
              <span>Insure : </span>
              <span>Delete Include All Data </span>
              <span className="text-[#e7000b]">Except Users</span>
            </p>
          </div>

          {/* Countdown Warning */}
          {countdown !== null && countdown > 0 && (
            <div className="bg-[#fff3cd] border border-[#ffc107] rounded-md p-4 mb-6 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-[#856404] flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-['Montserrat'] font-semibold text-[14px] text-[#856404] mb-1">
                  Warning: Destructive Action
                </p>
                <p className="font-['Montserrat'] font-medium text-[13px] text-[#856404]">
                  You can delete the data in <span className="font-bold">{countdown}</span> seconds. 
                  This action cannot be undone and will permanently delete all tickets data.
                </p>
              </div>
            </div>
          )}

          {/* Success Message */}
          {countdown === 0 && !isDeleting && (
            <div className="bg-[#d4edda] border border-[#28a745] rounded-md p-4 mb-6 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-[#155724] flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-['Montserrat'] font-semibold text-[14px] text-[#155724]">
                  You can now delete the data. Click the button below to confirm.
                </p>
              </div>
            </div>
          )}

          {/* Delete Button */}
          <div className="flex justify-end">
            <button
              onClick={handleDeleteClick}
              disabled={countdown !== null && countdown > 0}
              className={`flex items-center justify-center gap-[10px] h-[44px] px-6 rounded-[4px] font-['Montserrat'] font-semibold text-[14px] transition-all ${
                countdown !== null && countdown > 0
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-[#e7000b] text-white hover:bg-[#c50009] cursor-pointer'
              }`}
            >
              <Trash2 className="w-[20px] h-[20px]" />
              <span>
                {countdown === null
                  ? 'Delete Data'
                  : countdown > 0
                  ? `Wait ${countdown}s`
                  : 'Confirm Delete'}
              </span>
            </button>
          </div>
        </div>

        {/* Divider */}
        <div className="h-[1px] bg-[#e7e7e7] mx-6" />

        {/* Additional Info */}
        <div className="p-6">
          <div className="bg-[#f8f9fa] rounded-md p-4">
            <h3 className="font-['Montserrat'] font-semibold text-[14px] text-[#2e2c34] mb-2">
              What will be deleted:
            </h3>
            <ul className="space-y-2">
              <li className="font-['Montserrat'] font-medium text-[13px] text-[#84818a] flex items-start gap-2">
                <span className="text-[#e7000b] mt-1">•</span>
                <span>All tickets and their responses</span>
              </li>
              <li className="font-['Montserrat'] font-medium text-[13px] text-[#84818a] flex items-start gap-2">
                <span className="text-[#e7000b] mt-1">•</span>
                <span>Ticket attachments and files</span>
              </li>
              <li className="font-['Montserrat'] font-medium text-[13px] text-[#84818a] flex items-start gap-2">
                <span className="text-[#e7000b] mt-1">•</span>
                <span>Ticket history and logs</span>
              </li>
            </ul>
            <div className="mt-4 pt-3 border-t border-[#e7e7e7]">
              <p className="font-['Montserrat'] font-semibold text-[13px] text-[#28a745] flex items-start gap-2">
                <span className="mt-1">✓</span>
                <span>User data will be preserved</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}