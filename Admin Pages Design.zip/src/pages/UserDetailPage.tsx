import { ArrowLeft, User as UserIcon } from 'lucide-react';
import type { User } from '../types';

interface UserDetailPageProps {
  user: User;
  onBack: () => void;
}

export function UserDetailPage({ user, onBack }: UserDetailPageProps) {
  const getRoleColor = (role: string) => {
    switch (role) {
      case 'doctor':
        return 'bg-[#3B8AFF]';
      case 'student':
        return 'bg-[#F8A534]';
      case 'admin':
        return 'bg-[#00CC99]';
      default:
        return 'bg-gray-400';
    }
  };

  const getRoleLabel = (role: string) => {
    return role.charAt(0).toUpperCase() + role.slice(1);
  };

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-[#7f56d8] font-['Montserrat'] font-medium text-[14px] hover:underline"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Users</span>
      </button>

      {/* Header */}
      <div>
        <h1 className="font-['Montserrat'] font-semibold text-[24px] leading-[36px] text-[#2e2c34]">
          User Details
        </h1>
      </div>

      {/* User Card */}
      <div className="bg-white border border-[#e7e7e7] rounded-[10px] p-6 md:p-8">
        <div className="flex flex-col items-center gap-6">
          {/* User Avatar */}
          <div className="relative">
            <div className={`w-32 h-32 rounded-full ${getRoleColor(user.role)} flex items-center justify-center`}>
              <UserIcon className="w-16 h-16 text-white" strokeWidth={1.5} />
            </div>
            <div className={`absolute bottom-0 right-0 w-8 h-8 rounded-full ${getRoleColor(user.role)} border-4 border-white flex items-center justify-center`}>
              <span className="text-white text-xs font-bold">
                {user.role === 'doctor' ? 'D' : user.role === 'student' ? 'S' : 'A'}
              </span>
            </div>
          </div>

          {/* User Info */}
          <div className="w-full max-w-2xl space-y-4">
            {/* Name */}
            <div className="flex flex-col md:flex-row md:items-center gap-2 p-4 bg-[#f9f9fb] rounded-lg">
              <span className="font-['Montserrat'] font-semibold text-[14px] text-[#84818a] w-32">
                Name:
              </span>
              <span className="font-['Montserrat'] font-semibold text-[16px] md:text-[18px] text-[#2e2c34]">
                {user.name}
              </span>
            </div>

            {/* User ID */}
            <div className="flex flex-col md:flex-row md:items-center gap-2 p-4 bg-[#f9f9fb] rounded-lg">
              <span className="font-['Montserrat'] font-semibold text-[14px] text-[#84818a] w-32">
                User ID:
              </span>
              <span className="font-['Montserrat'] font-medium text-[16px] text-[#2e2c34]">
                {user.id}
              </span>
            </div>

            {/* Role */}
            <div className="flex flex-col md:flex-row md:items-center gap-2 p-4 bg-[#f9f9fb] rounded-lg">
              <span className="font-['Montserrat'] font-semibold text-[14px] text-[#84818a] w-32">
                Role:
              </span>
              <div className="flex items-center gap-2">
                <div className={`w-4 h-4 rounded-full ${getRoleColor(user.role)}`} />
                <span className="font-['Montserrat'] font-medium text-[16px] text-[#2e2c34]">
                  {getRoleLabel(user.role)}
                </span>
              </div>
            </div>

            {/* SSN (if available) */}
            {user.ssn && (
              <div className="flex flex-col md:flex-row md:items-center gap-2 p-4 bg-[#f9f9fb] rounded-lg">
                <span className="font-['Montserrat'] font-semibold text-[14px] text-[#84818a] w-32">
                  SSN:
                </span>
                <span className="font-['Montserrat'] font-medium text-[16px] text-[#2e2c34]">
                  {user.ssn}
                </span>
              </div>
            )}

            {/* Course ID (if available) */}
            {user.courseId && (
              <div className="flex flex-col md:flex-row md:items-center gap-2 p-4 bg-[#f9f9fb] rounded-lg">
                <span className="font-['Montserrat'] font-semibold text-[14px] text-[#84818a] w-32">
                  Course ID:
                </span>
                <span className="font-['Montserrat'] font-medium text-[16px] text-[#2e2c34]">
                  {user.courseId}
                </span>
              </div>
            )}

            {/* Course Name (if available) */}
            {user.courseName && (
              <div className="flex flex-col md:flex-row md:items-center gap-2 p-4 bg-[#f9f9fb] rounded-lg">
                <span className="font-['Montserrat'] font-semibold text-[14px] text-[#84818a] w-32">
                  Course Name:
                </span>
                <span className="font-['Montserrat'] font-medium text-[16px] text-[#2e2c34]">
                  {user.courseName}
                </span>
              </div>
            )}

            {/* Created At */}
            <div className="flex flex-col md:flex-row md:items-center gap-2 p-4 bg-[#f9f9fb] rounded-lg">
              <span className="font-['Montserrat'] font-semibold text-[14px] text-[#84818a] w-32">
                Created At:
              </span>
              <span className="font-['Montserrat'] font-medium text-[16px] text-[#2e2c34]">
                {new Date(user.createdAt).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
