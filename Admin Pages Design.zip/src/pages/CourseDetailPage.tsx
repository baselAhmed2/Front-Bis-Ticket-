import { useState } from 'react';
import { ArrowLeft, Trash2 } from 'lucide-react';
import type { Course } from '../types';

interface CourseDetailPageProps {
  course: Course;
  onBack: () => void;
  onDeleteDoctor: (doctorId: string) => void;
  onAddDoctor: (doctorId: string) => void;
}

export function CourseDetailPage({ course, onBack, onDeleteDoctor, onAddDoctor }: CourseDetailPageProps) {
  const [doctorId, setDoctorId] = useState('');

  const handleAddDoctor = () => {
    if (doctorId.trim()) {
      onAddDoctor(doctorId);
      setDoctorId('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Back Button - Mobile */}
      <button
        onClick={onBack}
        className="md:hidden flex items-center gap-2 text-[#7f56d8] font-['Montserrat'] font-medium"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Courses</span>
      </button>

      <h2 className="font-['Montserrat'] font-semibold text-[20px] md:text-[24px] text-[#2e2a40]">
        Course
      </h2>

      {/* Course Information */}
      <div className="bg-white rounded-lg border border-[#e7e7e7] p-4 md:p-6">
        <h3 className="font-['Montserrat'] font-semibold text-[16px] md:text-[18px] text-[#2e2a40] mb-6">
          Course Information
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
          <div className="space-y-2">
            <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
              Course ID
            </label>
            <div className="bg-white border border-[#e7e7e7] rounded px-4 py-3">
              <p className="font-['Montserrat'] font-medium text-[14px] text-[#757575]">
                {course.courseId}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
              Student Name
            </label>
            <div className="bg-white border border-[#e7e7e7] rounded px-4 py-3">
              <p className="font-['Montserrat'] font-medium text-[14px] text-[#757575]">
                {course.courseName}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
              Course
            </label>
            <div className="bg-white border border-[#e7e7e7] rounded px-4 py-3 flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#F8A534] bg-opacity-60" />
              <p className="font-['Montserrat'] font-medium text-[14px] text-[#757575]">
                {course.level}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Assigned Doctors */}
      <div className="bg-white rounded-lg border border-[#e7e7e7] p-4 md:p-6">
        <h3 className="font-['Montserrat'] font-semibold text-[16px] md:text-[18px] text-[#2e2a40] mb-6">
          Assigned Doctors
        </h3>

        {/* Add Doctor Form */}
        <div className="bg-[#fcfcfc] border border-[#e7e7e7] rounded-lg p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 space-y-2">
              <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
                Doctor ID
              </label>
              <input
                type="text"
                placeholder="Enter Doctor ID"
                value={doctorId}
                onChange={(e) => setDoctorId(e.target.value)}
                className="w-full bg-white border border-[#e7e7e7] rounded px-4 py-3 font-['Montserrat'] font-medium text-[14px] text-[#757575] focus:outline-none focus:border-[#7f56d8]"
              />
            </div>
            <div className="flex items-end">
              <button
                onClick={handleAddDoctor}
                className="bg-[#7f56d8] text-white px-6 py-3 rounded font-['Montserrat'] font-semibold text-[14px] hover:bg-[#6b47c2] transition-colors w-full md:w-auto"
              >
                Save
              </button>
            </div>
          </div>
        </div>

        {/* Doctors List */}
        <div className="space-y-4">
          {course.assignedDoctors.map((doctor) => (
            <div
              key={doctor.id}
              className="bg-[#fefefe] border border-[#e7e7e7] rounded-lg p-4 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-[#3B8AFF]" />
                <div>
                  <p className="font-['Montserrat'] font-semibold text-[14px] md:text-[16px] text-[#2e2c34]">
                    Doctor ID: {doctor.doctorId}
                  </p>
                  <p className="font-['Montserrat'] font-medium text-[14px] text-[#2e2c34]">
                    Name: {doctor.name}
                  </p>
                </div>
              </div>
              <button
                onClick={() => onDeleteDoctor(doctor.id)}
                className="bg-[#e7000b] text-white px-4 py-2 rounded flex items-center gap-2 font-['Montserrat'] font-semibold text-[14px] hover:bg-[#c70009] transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span className="hidden md:inline">Delete User</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
