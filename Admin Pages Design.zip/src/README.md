# نظام إدارة التذاكر للطلاب - Ticket Lead

نظام متكامل لإدارة تذاكر الطلاب مبني بـ React و Tailwind CSS، جاهز للتكامل مع Backend API.

## 🚀 المميزات الرئيسية

- ✅ **Responsive Design**: يعمل بشكل ممتاز على جميع الأجهزة (Desktop, Tablet, Mobile)
- ✅ **API Ready**: جاهز للتكامل مع Backend API
- ✅ **State Management**: إدارة حالة محترفة
- ✅ **TypeScript Support**: دعم كامل للـ TypeScript
- ✅ **Mock Data**: بيانات تجريبية للتطوير
- ✅ **Toast Notifications**: إشعارات للمستخدم
- ✅ **Pagination**: تقسيم صفحات للبيانات
- ✅ **Search & Filters**: بحث وفلترة متقدمة

## 📱 الصفحات المتاحة

1. **Dashboard**: لوحة تحكم رئيسية مع إحصائيات
2. **Tickets**: عرض وإدارة جميع التذاكر
3. **Ticket Detail**: تفاصيل التذكرة والرد عليها
4. **New Ticket**: إنشاء تذكرة جديدة
5. **Users**: إدارة المستخدمين (طلاب، دكاترة، إداريين)
6. **Courses**: إدارة المواد الدراسية (قريباً)
7. **Analysis**: لوحة تحليلات (قريباً)

## 🔌 التكامل مع API

### تعديل URL الخاص بـ Backend:

في ملف `/hooks/useApi.ts`، قم بتحديث:

```typescript
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000/api';
```

### API Endpoints المطلوبة:

#### Tickets:
- `GET /api/tickets` - جلب جميع التذاكر
- `GET /api/tickets/:id` - جلب تذكرة معينة
- `POST /api/tickets` - إنشاء تذكرة جديدة
- `PUT /api/tickets/:id` - تحديث تذكرة
- `DELETE /api/tickets/:id` - حذف تذكرة
- `POST /api/tickets/:id/responses` - إضافة رد على تذكرة

#### Users:
- `GET /api/users` - جلب جميع المستخدمين
- `GET /api/users/:id` - جلب مستخدم معين
- `POST /api/users` - إنشاء مستخدم جديد
- `PUT /api/users/:id` - تحديث مستخدم
- `DELETE /api/users/:id` - حذف مستخدم

### مثال استخدام API Hooks:

```typescript
import { useTicketsApi } from './hooks/useApi';

function MyComponent() {
  const { getTickets, loading, error } = useTicketsApi();

  useEffect(() => {
    async function loadTickets() {
      try {
        const response = await getTickets({ status: 'new', page: 1, limit: 10 });
        console.log(response.data);
      } catch (err) {
        console.error('Error loading tickets:', err);
      }
    }
    loadTickets();
  }, []);

  return <div>...</div>;
}
```

## 📊 Data Types

جميع الأنواع موجودة في `/types/index.ts`:

```typescript
- User: معلومات المستخدم
- Ticket: معلومات التذكرة
- TicketResponse: رد على تذكرة
- Course: معلومات المادة الدراسية
- TicketStatus: حالة التذكرة (new | ongoing | resolved)
- UserRole: دور المستخدم (student | doctor | admin)
```

## 🎨 التصميم Responsive

التطبيق يستخدم Tailwind CSS مع breakpoints:
- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

### أمثلة:

```tsx
// يظهر على الموبايل فقط
<div className="block md:hidden">Mobile Menu</div>

// يظهر على Desktop فقط
<div className="hidden md:block">Desktop Sidebar</div>

// Responsive sizes
<h1 className="text-[20px] md:text-[24px]">Title</h1>
```

## 🔔 Toast Notifications

استخدام الإشعارات:

```typescript
import { useToast } from './hooks/useToast';

function MyComponent() {
  const { showSuccess, showError, showWarning, showInfo } = useToast();

  const handleSubmit = () => {
    showSuccess('Success', 'Operation completed successfully!');
  };

  return <button onClick={handleSubmit}>Submit</button>;
}
```

## 📁 هيكل المشروع

```
/
├── components/
│   ├── layout/         # Sidebar, TopBar, MobileNav
│   ├── tickets/        # مكونات التذاكر
│   ├── dashboard/      # مكونات Dashboard
│   └── common/         # مكونات مشتركة
├── pages/              # الصفحات الرئيسية
├── hooks/              # Custom Hooks (API, Toast)
├── types/              # TypeScript Types
├── data/               # Mock Data
└── App.tsx             # المكون الرئيسي
```

## 🚀 كيفية الاستخدام

1. التطبيق يعمل مباشرة مع Mock Data
2. لتفعيل API Integration:
   - حدث `API_BASE_URL` في `/hooks/useApi.ts`
   - استخدم hooks مثل `useTicketsApi()` و `useUsersApi()`
   - استبدل Mock Data بـ API Calls

## 📱 Mobile Optimization

- ✅ Touch-friendly buttons (min 44x44px)
- ✅ Responsive navigation (Hamburger menu)
- ✅ Optimized layouts for small screens
- ✅ Readable fonts (min 14px)
- ✅ Proper spacing and padding
- ✅ Mobile-first approach

## 🔐 Security Notes

عند التكامل مع Backend:
1. استخدم HTTPS
2. أضف Authentication headers
3. تحقق من الصلاحيات (Authorization)
4. Sanitize user inputs
5. استخدم Environment Variables للـ API keys

## 📝 ملاحظات هامة

- جميع المكونات جاهزة للاستخدام
- البيانات التجريبية في `/data/mockData.ts`
- يمكن تخصيص الألوان من Tailwind config
- Font: Montserrat (مضمن في التصميم)

## 🎯 الخطوات التالية

1. ربط Backend API
2. إضافة Authentication
3. إضافة File Upload للتذاكر
4. تحسين Analytics Dashboard
5. إضافة Real-time Notifications

---

**تم التطوير بواسطة Claude - جاهز للإنتاج! 🚀**
