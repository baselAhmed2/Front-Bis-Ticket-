import { useState } from 'react';
import { Sidebar } from './components/layout/Sidebar';
import { TopBar } from './components/layout/TopBar';
import { MobileNav } from './components/layout/MobileNav';
import { DashboardPage } from './pages/DashboardPage';
import { TicketsPage } from './pages/TicketsPage';
import { UsersPage } from './pages/UsersPage';
import { UserDetailPage } from './pages/UserDetailPage';
import { NewUserPage } from './pages/NewUserPage';
import { CoursesPage } from './pages/CoursesPage';
import { CourseDetailPage } from './pages/CourseDetailPage';
import { NewCoursePage } from './pages/NewCoursePage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { SiteSettingsPage } from './pages/SiteSettingsPage';
import { TicketDetail } from './components/tickets/TicketDetail';
import { NewTicketForm } from './components/tickets/NewTicketForm';
import { ToastContainer } from './components/common/ToastContainer';
import { DeleteConfirmModal } from './components/common/DeleteConfirmModal';
import { useToast } from './hooks/useToast';
import type { Ticket, User, Course } from './types';

export default function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; userId?: string }>({ isOpen: false });
  const { toasts, removeToast, showSuccess, showError, showWarning } = useToast();

  const handleNavigate = (page: string, data?: any) => {
    setCurrentPage(page);
    
    if (page === 'ticket-detail' && data) {
      setSelectedTicket(data);
    } else if (page === 'user-detail' && data) {
      setSelectedUser(data);
    } else if (page === 'course-detail' && data) {
      setSelectedCourse(data);
    } else if (page === 'logout') {
      showWarning('Logout', 'You have been logged out successfully.');
      setTimeout(() => {
        setCurrentPage('dashboard');
      }, 1500);
    } else {
      setSelectedTicket(null);
      setSelectedUser(null);
      setSelectedCourse(null);
    }

    setIsMobileMenuOpen(false);
  };

  const handleTicketSubmit = (response: string) => {
    console.log('Ticket response submitted:', response);
    // TODO: Integrate with API
    // await ticketsApi.addResponse(selectedTicket.id, { body: response, ... });
    
    showSuccess(
      'Success',
      'Your response has been submitted successfully.'
    );
  };

  const handleNewTicketSubmit = (ticketData: any) => {
    console.log('New ticket submitted:', ticketData);
    // TODO: Integrate with API
    // await ticketsApi.createTicket(ticketData);
    
    showSuccess(
      'Success',
      'Ticket created successfully. Thank you for your submission.'
    );
    
    setTimeout(() => {
      handleNavigate('tickets');
    }, 1500);
  };

  const handleNewCourseSubmit = (courseData: any) => {
    console.log('New course submitted:', courseData);
    // TODO: Integrate with API
    // await coursesApi.createCourse(courseData);
    
    showSuccess(
      'Success',
      'Course created successfully.'
    );
    
    setTimeout(() => {
      handleNavigate('courses');
    }, 1500);
  };

  const handleDeleteUser = (userId: string) => {
    console.log('Delete user:', userId);
    setDeleteModal({ isOpen: true, userId });
  };

  const handleConfirmDelete = () => {
    // TODO: Integrate with API to delete user
    console.log('User deleted:', deleteModal.userId);
    setDeleteModal({ isOpen: false });
    showSuccess('Success', 'User deleted successfully.');
  };

  const handleNewUserSubmit = (userData: any) => {
    console.log('New user submitted:', userData);
    // TODO: Integrate with API
    // await usersApi.createUser(userData);
    
    showSuccess(
      'Success',
      'User created successfully.'
    );
    
    setTimeout(() => {
      handleNavigate('users');
    }, 1500);
  };

  const handleDeleteDoctor = (doctorId: string) => {
    console.log('Delete doctor:', doctorId);
    // TODO: Show confirmation dialog and integrate with API
    
    showWarning(
      'Warning',
      'Doctor removed from course.'
    );
  };

  const handleAddDoctor = (doctorId: string) => {
    console.log('Add doctor:', doctorId);
    // TODO: Integrate with API
    
    showSuccess(
      'Success',
      'Doctor assigned successfully.'
    );
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage onNavigate={handleNavigate} />;
      
      case 'tickets':
        return <TicketsPage onNavigate={handleNavigate} />;
      
      case 'ticket-detail':
        return selectedTicket ? (
          <TicketDetail
            ticket={selectedTicket}
            onBack={() => handleNavigate('tickets')}
            onSubmit={handleTicketSubmit}
          />
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-500">Ticket not found</p>
          </div>
        );
      
      case 'new-ticket':
        return (
          <NewTicketForm
            onSubmit={handleNewTicketSubmit}
            onBack={() => handleNavigate('tickets')}
          />
        );
      
      case 'users':
        return (
          <UsersPage
            onNavigate={handleNavigate}
            onDeleteUser={handleDeleteUser}
          />
        );
      
      case 'user-detail':
        return selectedUser ? (
          <UserDetailPage
            user={selectedUser}
            onBack={() => handleNavigate('users')}
          />
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-500">User not found</p>
          </div>
        );
      
      case 'new-user':
        return (
          <NewUserPage
            onSubmit={handleNewUserSubmit}
            onBack={() => handleNavigate('users')}
          />
        );
      
      case 'courses':
        return <CoursesPage onNavigate={handleNavigate} />;
      
      case 'course-detail':
        return selectedCourse ? (
          <CourseDetailPage
            course={selectedCourse}
            onBack={() => handleNavigate('courses')}
            onDeleteDoctor={handleDeleteDoctor}
            onAddDoctor={handleAddDoctor}
          />
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-500">Course not found</p>
          </div>
        );
      
      case 'new-course':
        return (
          <NewCoursePage
            onSubmit={handleNewCourseSubmit}
            onBack={() => handleNavigate('courses')}
          />
        );
      
      case 'analytics':
        return <AnalyticsPage onNavigate={handleNavigate} />;
      
      case 'site-settings':
        return <SiteSettingsPage onNavigate={handleNavigate} />;
      
      default:
        return <DashboardPage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#f9f9fb]">
      {/* Sidebar - Desktop */}
      <Sidebar activePage={currentPage} onNavigate={handleNavigate} />

      {/* Mobile Navigation */}
      <MobileNav
        isOpen={isMobileMenuOpen}
        activePage={currentPage}
        onClose={() => setIsMobileMenuOpen(false)}
        onNavigate={handleNavigate}
      />

      {/* Main Content */}
      <div className="md:ml-[249px] min-h-screen">
        {/* Top Bar */}
        <TopBar onMenuClick={() => setIsMobileMenuOpen(true)} />

        {/* Page Content */}
        <main className="pt-[85px] px-4 md:px-8 py-6 md:py-8">
          {renderPage()}
        </main>
      </div>

      {/* Toast Notifications */}
      <ToastContainer toasts={toasts} onRemove={removeToast} />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteModal.isOpen}
        onClose={() => setDeleteModal({ isOpen: false })}
        onConfirm={handleConfirmDelete}
        message="Are you sure you want to delete this user? This action cannot be undone."
      />
    </div>
  );
}