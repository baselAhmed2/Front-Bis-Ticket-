// Ticket Types
export interface Ticket {
  id: string;
  ticketNumber: string;
  subject: string;
  body: string;
  status: 'new' | 'ongoing' | 'resolved';
  type: string;
  studentId: string;
  studentName: string;
  doctorName: string;
  courseName?: string;
  groupNumber?: string;
  postedAt: string;
  replies?: TicketReply[];
}

export interface TicketReply {
  id: string;
  ticketId: string;
  authorName: string;
  authorRole: 'doctor' | 'student';
  body: string;
  createdAt: string;
}

// User Types
export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'student' | 'doctor';
  studentId?: string;
  doctorId?: string;
}

// Course Types
export interface Course {
  id: string;
  courseId: string;
  courseName: string;
  level: string;
  semester: string;
  subjectId: string;
  assignedDoctors: AssignedDoctor[];
}

export interface AssignedDoctor {
  id: string;
  doctorId: string;
  name: string;
  courseId: string;
}

// Doctor Analytics Types
export interface DoctorAnalytics {
  id: string;
  doctorId: string;
  name: string;
  level: string;
  totalTickets: number;
  closedTickets: number;
}

// Dashboard Stats
export interface DashboardStats {
  newTickets: number;
  inProgress: number;
  closed: number;
}
