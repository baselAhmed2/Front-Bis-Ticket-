# دليل تكامل API للباك إند

## نظرة عامة

هذا النظام جاهز **100%** لاستقبال API من الباك إند. تم تجهيز جميع الـ Hooks والـ Types اللازمة.

---

## ⚙️ إعدادات البيئة

قم بتعيين متغير البيئة لعنوان API الخاص بالباك إند:

```bash
NEXT_PUBLIC_API_URL=https://your-backend-api.com/api
```

---

## 📚 API Hooks المتاحة

### 1. Tickets API (`useTicketsApi`)

```typescript
import { useTicketsApi } from '@/hooks/useApi';

const TicketsComponent = () => {
  const { 
    getTickets, 
    getTicketById, 
    createTicket, 
    updateTicket, 
    deleteTicket,
    addResponse,
    loading, 
    error 
  } = useTicketsApi();

  // مثال: جلب جميع التذاكر
  const fetchTickets = async () => {
    const response = await getTickets({ 
      status: 'ongoing', 
      page: 1, 
      limit: 10 
    });
    console.log(response.data);
  };

  // مثال: إنشاء تذكرة جديدة
  const handleCreateTicket = async (ticketData) => {
    const response = await createTicket(ticketData);
    console.log('Ticket created:', response.data);
  };

  // مثال: إضافة رد على تذكرة
  const handleAddResponse = async (ticketId, responseBody) => {
    const response = await addResponse(ticketId, {
      body: responseBody,
      authorName: 'Dr. Mohamed',
      authorRole: 'doctor'
    });
    console.log('Response added:', response.data);
  };
};
```

**Endpoints المطلوبة:**
- `GET /api/tickets?status=&page=&limit=` - جلب قائمة التذاكر
- `GET /api/tickets/:id` - جلب تذكرة محددة
- `POST /api/tickets` - إنشاء تذكرة جديدة
- `PUT /api/tickets/:id` - تحديث تذكرة
- `DELETE /api/tickets/:id` - حذف تذكرة
- `POST /api/tickets/:id/responses` - إضافة رد على تذكرة

---

### 2. Users API (`useUsersApi`)

```typescript
import { useUsersApi } from '@/hooks/useApi';

const UsersComponent = () => {
  const { 
    getUsers, 
    getUserById, 
    createUser, 
    updateUser, 
    deleteUser,
    loading, 
    error 
  } = useUsersApi();

  // مثال: جلب جميع المستخدمين
  const fetchUsers = async () => {
    const response = await getUsers({ 
      role: 'student', 
      page: 1, 
      limit: 20 
    });
    console.log(response.data);
  };

  // مثال: حذف مستخدم
  const handleDeleteUser = async (userId) => {
    const response = await deleteUser(userId);
    console.log('User deleted:', response);
  };
};
```

**Endpoints المطلوبة:**
- `GET /api/users?role=&page=&limit=` - جلب قائمة المستخدمين
- `GET /api/users/:id` - جلب مستخدم محدد
- `POST /api/users` - إنشاء مستخدم جديد
- `PUT /api/users/:id` - تحديث مستخدم
- `DELETE /api/users/:id` - حذف مستخدم

---

### 3. Courses API (`useCoursesApi`)

```typescript
import { useCoursesApi } from '@/hooks/useApi';

const CoursesComponent = () => {
  const { 
    getCourses, 
    getCourseById, 
    createCourse, 
    updateCourse, 
    deleteCourse,
    assignDoctor,
    removeDoctor,
    loading, 
    error 
  } = useCoursesApi();

  // مثال: جلب جميع الكورسات
  const fetchCourses = async () => {
    const response = await getCourses({ 
      level: 'Level 4', 
      semester: 'Semester 1' 
    });
    console.log(response.data);
  };

  // مثال: تعيين دكتور لكورس
  const handleAssignDoctor = async (courseId, doctorId) => {
    const response = await assignDoctor(courseId, doctorId);
    console.log('Doctor assigned:', response);
  };

  // مثال: إزالة دكتور من كورس
  const handleRemoveDoctor = async (courseId, doctorId) => {
    const response = await removeDoctor(courseId, doctorId);
    console.log('Doctor removed:', response);
  };
};
```

**Endpoints المطلوبة:**
- `GET /api/courses?level=&semester=&page=&limit=` - جلب قائمة الكورسات
- `GET /api/courses/:id` - جلب كورس محدد
- `POST /api/courses` - إنشاء كورس جديد
- `PUT /api/courses/:id` - تحديث كورس
- `DELETE /api/courses/:id` - حذف كورس
- `POST /api/courses/:id/doctors` - تعيين دكتور لكورس
- `DELETE /api/courses/:id/doctors/:doctorId` - إزالة دكتور من كورس

---

### 4. Analytics API (`useAnalyticsApi`)

```typescript
import { useAnalyticsApi } from '@/hooks/useApi';

const AnalyticsComponent = () => {
  const { 
    getDoctorAnalytics, 
    getDashboardStats,
    loading, 
    error 
  } = useAnalyticsApi();

  // مثال: جلب إحصائيات الدكاترة
  const fetchDoctorStats = async () => {
    const response = await getDoctorAnalytics({ level: 'Level 1' });
    console.log(response.data);
  };

  // مثال: جلب إحصائيات Dashboard
  const fetchDashboardStats = async () => {
    const response = await getDashboardStats();
    console.log(response.data);
  };
};
```

**Endpoints المطلوبة:**
- `GET /api/analytics/doctors?level=` - جلب إحصائيات الدكاترة
- `GET /api/analytics/dashboard` - جلب إحصائيات Dashboard

---

## 📝 API Response Format

جميع الـ APIs يجب أن ترجع البيانات بهذا الشكل:

```typescript
{
  "success": true,
  "data": { /* البيانات المطلوبة */ },
  "message": "عملية ناجحة" // اختياري
}
```

**مثال - Get Tickets:**
```json
{
  "success": true,
  "data": [
    {
      "id": "1",
      "ticketNumber": "2026-IE123",
      "subject": "How to deposit money?",
      "body": "Lorem ipsum...",
      "status": "ongoing",
      "type": "Deposit Issue",
      "studentId": "512393207",
      "studentName": "Ahmed Mohamed",
      "doctorName": "DR Bahlol",
      "courseName": "Information Economy",
      "groupNumber": "9",
      "postedAt": "Posted at 12:45 -3-2026",
      "replies": [
        {
          "id": "1",
          "ticketId": "1",
          "authorName": "Dr.Mohmed",
          "authorRole": "doctor",
          "body": "Response message...",
          "createdAt": "12-11-2024"
        }
      ]
    }
  ]
}
```

---

## 🔐 Authentication (اختياري)

إذا كان الـ API يحتاج authentication، قم بتعديل الـ headers في `useApi`:

```typescript
// في /hooks/useApi.ts
const response = await fetch(`${API_BASE_URL}${endpoint}`, {
  ...config,
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`, // أضف التوكن هنا
    ...config?.headers,
  },
});
```

---

## 🧪 مثال تكامل كامل

### في Component:

```typescript
import { useEffect, useState } from 'react';
import { useTicketsApi } from '@/hooks/useApi';
import { useToast } from '@/hooks/useToast';

const TicketsPage = () => {
  const [tickets, setTickets] = useState([]);
  const { getTickets, loading } = useTicketsApi();
  const { showSuccess, showError } = useToast();

  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = async () => {
    try {
      const response = await getTickets({ status: 'all', page: 1, limit: 10 });
      setTickets(response.data);
      showSuccess('Success', 'Tickets loaded successfully');
    } catch (error) {
      showError('Error', 'Failed to load tickets');
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      {tickets.map(ticket => (
        <TicketCard key={ticket.id} ticket={ticket} />
      ))}
    </div>
  );
};
```

---

## ✅ Checklist للباك إند

- [ ] تجهيز جميع الـ Endpoints المطلوبة
- [ ] التأكد من Response Format
- [ ] إضافة CORS headers للسماح بالـ Frontend
- [ ] إضافة Authentication إذا لزم الأمر
- [ ] اختبار جميع الـ APIs مع Postman/Insomnia
- [ ] توثيق الـ API Endpoints

---

## 📞 دعم فني

في حالة وجود أي استفسارات حول التكامل، يرجى الرجوع لهذا الدليل أو التواصل مع فريق التطوير.
