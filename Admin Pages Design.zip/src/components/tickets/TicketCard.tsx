import { User } from 'lucide-react';
import type { Ticket } from '../../types';

interface TicketCardProps {
  ticket: Ticket;
  onClick: () => void;
}

export function TicketCard({ ticket, onClick }: TicketCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new':
        return '#3B8AFF';
      case 'ongoing':
        return '#F8A534';
      case 'resolved':
        return '#00CC99';
      default:
        return '#84818a';
    }
  };

  return (
    <div className="bg-[#fefefe] border border-[#e7e7e7] rounded p-4 md:p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          {/* Status Circle */}
          <div 
            className="w-[22px] h-[22px] rounded-full flex-shrink-0" 
            style={{ backgroundColor: getStatusColor(ticket.status) }}
          />
          
          {/* Ticket Number */}
          <h3 className="font-['Montserrat'] font-semibold text-[14px] md:text-[16px] text-[#2e2c34]">
            Ticket# {ticket.ticketNumber}
          </h3>
        </div>

        {/* Posted Time */}
        <span className="font-['Montserrat'] font-medium text-[12px] text-[#84818a]">
          {ticket.postedAt}
        </span>
      </div>

      {/* Subject */}
      <h4 className="font-['Montserrat'] font-medium text-[14px] text-[#2e2c34] mb-2">
        {ticket.subject}
      </h4>

      {/* Body */}
      <p className="font-['Montserrat'] font-medium text-[12px] text-[#84818a] line-clamp-2 mb-4">
        {ticket.body}
      </p>

      {/* Divider */}
      <div className="border-t border-[#e7e7e7] mb-4" />

      {/* Footer */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {/* User Avatar */}
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#7f56d8] to-[#6b47c2] flex items-center justify-center flex-shrink-0">
            <User className="w-4 h-4 text-white" />
          </div>
          
          {/* User Name */}
          <span className="font-['Montserrat'] font-medium text-[14px] text-[#84818a]">
            {ticket.studentName}
          </span>
        </div>

        {/* Open Ticket Button */}
        <button
          onClick={onClick}
          className="font-['Montserrat'] font-medium text-[14px] text-[#7f56d8] underline hover:no-underline decoration-skip-ink-none"
        >
          Open Ticket
        </button>
      </div>
    </div>
  );
}
