import { Search, Plus } from 'lucide-react';

interface TicketFiltersProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  activeFilter: string;
  onFilterChange: (filter: string) => void;
  onNewTicket: () => void;
}

export function TicketFilters({
  searchQuery,
  onSearchChange,
  activeFilter,
  onFilterChange,
  onNewTicket,
}: TicketFiltersProps) {
  const filters = [
    { id: 'all', label: 'All Tickets', color: '#7F56D8' },
    { id: 'new', label: 'New', color: '#3B8AFF' },
    { id: 'ongoing', label: 'On-Going', color: '#F8A534' },
    { id: 'resolved', label: 'Resolved', color: '#00CC99' },
  ];

  return (
    <div className="space-y-4">
      {/* Search and New Ticket Button */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search for ticket"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 border border-[#e7e7e7] rounded-md font-['Montserrat'] text-[14px] focus:outline-none focus:border-[#7f56d8]"
          />
        </div>

        <button
          onClick={onNewTicket}
          className="bg-[#7f56d8] text-white px-4 py-2.5 rounded-md flex items-center justify-center gap-2 hover:bg-[#6b47c2] transition-colors font-['Montserrat'] font-semibold text-[14px]"
        >
          <Plus className="w-5 h-5" />
          <span>New Ticket</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2 md:gap-4">
        {filters.map((filter) => (
          <button
            key={filter.id}
            onClick={() => onFilterChange(filter.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-md font-['Montserrat'] font-medium text-[13px] md:text-[14px] transition-colors ${
              activeFilter === filter.id
                ? 'bg-[#7f56d8] text-white'
                : 'bg-white text-[#2e2c34] border border-[#e7e7e7] hover:border-[#7f56d8]'
            }`}
          >
            {filter.id !== 'all' && (
              <div
                className="w-2.5 h-2.5 rounded-full"
                style={{ backgroundColor: filter.color }}
              />
            )}
            <span>{filter.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
