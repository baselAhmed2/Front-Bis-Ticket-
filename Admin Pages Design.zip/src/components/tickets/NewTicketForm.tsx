import { useState } from 'react';
import { ChevronDown, ArrowLeft, Paperclip } from 'lucide-react';

interface NewTicketFormProps {
  onSubmit: (data: any) => void;
  onBack: () => void;
}

export function NewTicketForm({ onSubmit, onBack }: NewTicketFormProps) {
  const [formData, setFormData] = useState({
    doctor: '',
    subject: '',
    body: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="space-y-6">
      {/* Back Button - Mobile */}
      <button
        onClick={onBack}
        className="md:hidden flex items-center gap-2 text-[#7f56d8] font-['Montserrat'] font-medium"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Tickets</span>
      </button>

      <div className="bg-white rounded-lg border border-[#e7e7e7] p-4 md:p-6">
        <div className="mb-6">
          <h2 className="font-['Montserrat'] font-semibold text-[18px] text-[#2e2a40] mb-1">
            Create Quick Ticket
          </h2>
          <p className="font-['Montserrat'] font-medium text-[14px] md:text-[16px] text-[#84818a]">
            Write and address new queries and issues
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            <div className="space-y-2">
              <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
                Select Doctor <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <select
                  value={formData.doctor}
                  onChange={(e) => setFormData({ ...formData, doctor: e.target.value })}
                  className="w-full bg-white border border-[#e7e7e7] rounded px-4 py-3 font-['Montserrat'] font-medium text-[14px] text-[#757575] appearance-none focus:outline-none focus:border-[#7f56d8]"
                  required
                >
                  <option value="">Choose Level</option>
                  <option value="dr-mohamed">Dr. Mohamed</option>
                  <option value="dr-bahlol">Dr. Bahlol</option>
                </select>
                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#bababa] pointer-events-none" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
                Request Ticket Subject
              </label>
              <input
                type="text"
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                placeholder="Enter Ticket Subject"
                className="w-full bg-white border border-[#e7e7e7] rounded px-4 py-3 font-['Montserrat'] font-medium text-[14px] text-[#757575] focus:outline-none focus:border-[#7f56d8]"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
              Ticket Body
            </label>
            <div className="relative">
              <textarea
                value={formData.body}
                onChange={(e) => setFormData({ ...formData, body: e.target.value })}
                placeholder="Type ticket issue here.."
                className="w-full bg-white border border-[#e7e7e7] rounded px-4 py-3 font-['Montserrat'] font-medium text-[14px] text-[#757575] min-h-[150px] md:min-h-[182px] focus:outline-none focus:border-[#7f56d8] resize-none"
              />
              <button
                type="button"
                className="absolute right-4 top-4 text-gray-400 hover:text-gray-600"
              >
                <Paperclip className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="bg-[#7f56d8] text-white px-6 py-2.5 rounded font-['Montserrat'] font-semibold text-[14px] hover:bg-[#6b47c2] transition-colors"
            >
              Send Ticket
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
