import { useState } from 'react';
import { ChevronDown, ArrowLeft } from 'lucide-react';
import type { Ticket } from '../../types';

interface TicketDetailProps {
  ticket: Ticket;
  onBack: () => void;
  onSubmit: (response: string) => void;
}

export function TicketDetail({ ticket, onBack, onSubmit }: TicketDetailProps) {
  const [responseBody, setResponseBody] = useState('');
  const [selectedStatus, setSelectedStatus] = useState(ticket.status);

  const handleSubmit = () => {
    if (responseBody.trim()) {
      onSubmit(responseBody);
      setResponseBody('');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new':
        return 'bg-[#3B8AFF]';
      case 'ongoing':
        return 'bg-[#F8A534] bg-opacity-60';
      case 'resolved':
        return 'bg-[#00CC99]';
      default:
        return 'bg-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Back Button - Mobile */}
      <button
        onClick={onBack}
        className="md:hidden flex items-center gap-2 text-[#7f56d8] font-['Montserrat'] font-medium"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Tickets</span>
      </button>

      {/* Ticket Header */}
      <div className="bg-white rounded-lg border border-[#e7e7e7] p-4 md:p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-4 h-4 rounded-full ${getStatusColor(ticket.status)}`} />
            <h3 className="font-['Montserrat'] font-semibold text-[14px] md:text-[16px] text-[#2e2c34]">
              Ticket# {ticket.ticketNumber}
            </h3>
          </div>
          <span className="font-['Montserrat'] font-medium text-[12px] text-[#84818a]">
            {ticket.postedAt}
          </span>
        </div>

        <h2 className="font-['Montserrat'] font-semibold text-[18px] md:text-[22px] text-[#2e2c34] mb-4">
          {ticket.subject}
        </h2>

        <p className="font-['Montserrat'] font-medium text-[14px] text-[#84818a] whitespace-pre-wrap mb-6">
          {ticket.body}
        </p>

        {/* Ticket Type Badge */}
        {ticket.type && (
          <div className="inline-block">
            <span className="font-['Montserrat'] font-medium text-[14px] text-[#757575] bg-gray-100 px-3 py-1.5 rounded">
              {ticket.type}
            </span>
          </div>
        )}
      </div>

      {/* Sender Information */}
      <div className="bg-white rounded-lg border border-[#e7e7e7] p-4 md:p-6">
        <h3 className="font-['Montserrat'] font-semibold text-[16px] md:text-[18px] text-[#2e2a40] mb-6">
          Ticket Sender Information
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
          <div className="space-y-2">
            <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
              Student ID
            </label>
            <div className="bg-white border border-[#e7e7e7] rounded px-4 py-3">
              <p className="font-['Montserrat'] font-medium text-[14px] text-[#757575]">
                {ticket.studentId}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
              Student Name
            </label>
            <div className="bg-white border border-[#e7e7e7] rounded px-4 py-3">
              <p className="font-['Montserrat'] font-medium text-[14px] text-[#757575]">
                {ticket.studentName}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
              Course
            </label>
            <div className="bg-white border border-[#e7e7e7] rounded px-4 py-3 flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#F8A534] bg-opacity-60" />
              <p className="font-['Montserrat'] font-medium text-[14px] text-[#757575]">
                {ticket.courseName || 'N/A'}
              </p>
            </div>
          </div>

          {ticket.groupNumber && (
            <div className="space-y-2">
              <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
                Group Number
              </label>
              <div className="bg-white border border-[#e7e7e7] rounded px-4 py-3 text-center">
                <p className="font-['Montserrat'] font-medium text-[14px] text-black">
                  {ticket.groupNumber}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Last Replays Section */}
      {ticket.replies && ticket.replies.length > 0 && (
        <div className="bg-white rounded-lg border border-[#e7e7e7] p-4 md:p-6">
          <h3 className="font-['Montserrat'] font-semibold text-[16px] md:text-[18px] text-[#2e2a40] mb-6">
            Last Replays On Ticket
          </h3>
          
          <div className="space-y-4">
            {ticket.replies.map((reply) => (
              <div
                key={reply.id}
                className="bg-white border border-[#e7e7e7] rounded p-4"
              >
                <p className="font-['Montserrat'] font-light text-[10px] text-black mb-2">
                  {reply.authorRole === 'doctor' ? 'Dr.' : ''}{reply.authorName} on {reply.createdAt}
                </p>
                <p className={`font-['Montserrat'] text-[14px] text-black ${
                  reply.authorRole === 'student' ? 'font-semibold' : 'font-medium'
                }`}>
                  {reply.body}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Reply Section */}
      <div className="bg-[#fcfcfc] border border-[#e7e7e7] rounded-lg p-4 md:p-6">
        <h3 className="font-['Montserrat'] font-semibold text-[16px] md:text-[18px] text-[#2e2a40] mb-6">
          Reply to Ticket
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="space-y-2">
            <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
              Token ID
            </label>
            <div className="bg-white border border-[#e7e7e7] rounded px-4 py-3">
              <p className="font-['Montserrat'] font-medium text-[14px] text-[#757575]">
                {ticket.studentId}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
              Request Ticket Type
            </label>
            <div className="bg-white border border-[#e7e7e7] rounded px-4 py-3 flex items-center justify-between">
              <p className="font-['Montserrat'] font-medium text-[14px] text-[#757575]">
                {ticket.type}
              </p>
              <ChevronDown className="w-4 h-4 text-[#bababa]" />
            </div>
          </div>

          <div className="space-y-2">
            <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
              Status
            </label>
            <div className="bg-white border border-[#e7e7e7] rounded px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${getStatusColor(selectedStatus)}`} />
                <p className="font-['Montserrat'] font-medium text-[14px] text-[#757575] capitalize">
                  {selectedStatus === 'ongoing' ? 'On-Going' : selectedStatus}
                </p>
              </div>
              <ChevronDown className="w-4 h-4 text-[#bababa]" />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <label className="font-['Montserrat'] font-medium text-[14px] text-[#2e2a40]">
            Ticket Body
          </label>
          <textarea
            value={responseBody}
            onChange={(e) => setResponseBody(e.target.value)}
            placeholder="Type ticket issue here.."
            className="w-full bg-white border border-[#e7e7e7] rounded px-4 py-3 font-['Montserrat'] font-medium text-[14px] text-[#757575] min-h-[110px] focus:outline-none focus:border-[#7f56d8] resize-none"
          />
        </div>

        <div className="flex justify-end mt-6">
          <button
            onClick={handleSubmit}
            className="bg-[#7f56d8] text-white px-6 py-2.5 rounded font-['Montserrat'] font-semibold text-[14px] hover:bg-[#6b47c2] transition-colors"
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
}