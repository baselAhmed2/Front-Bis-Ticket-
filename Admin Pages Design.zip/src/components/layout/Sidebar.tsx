import svgPaths from '../../imports/svg-6am2xkkp4v';
import svgPathsNew from '../../imports/svg-x8fykqtpoi';
import { Plus } from 'lucide-react';

interface SidebarProps {
  activePage: string;
  onNavigate: (page: string) => void;
}

// SVG Icons Components
function CategoryIcon() {
  return (
    <svg className="w-[22px] h-[22px]" fill="none" preserveAspectRatio="none" viewBox="0 0 17.875 17.875">
      <g>
        <path clipRule="evenodd" d={svgPaths.p1b0dd80} fill="currentColor" fillRule="evenodd" />
        <path clipRule="evenodd" d={svgPaths.p1d036400} fill="currentColor" fillRule="evenodd" />
        <path clipRule="evenodd" d={svgPaths.pdd4a200} fill="currentColor" fillRule="evenodd" />
        <path clipRule="evenodd" d={svgPaths.p20c71180} fill="currentColor" fillRule="evenodd" />
      </g>
    </svg>
  );
}

function TicketIcon() {
  return (
    <svg className="w-[22px] h-[22px]" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
      <path d={svgPathsNew.p1ff1d2f0} stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
    </svg>
  );
}

function ProfileIcon() {
  return (
    <svg className="w-[16px] h-[20px]" fill="none" preserveAspectRatio="none" viewBox="0 0 16 20">
      <g>
        <path clipRule="evenodd" d={svgPathsNew.p1dfa98f0} fill="currentColor" fillRule="evenodd" />
        <path clipRule="evenodd" d={svgPathsNew.p3094ef0} fill="currentColor" fillRule="evenodd" />
      </g>
    </svg>
  );
}

function BookIcon() {
  return (
    <svg className="w-[20px] h-[20px]" fill="none" preserveAspectRatio="none" viewBox="0 0 20 17.1429">
      <path d={svgPathsNew.p17b07800} stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function AnalyticsIcon() {
  return (
    <svg className="w-[20px] h-[20px]" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
      <path d={svgPathsNew.p5d04380} fill="currentColor" />
    </svg>
  );
}

function LogoutIcon() {
  return (
    <svg className="w-[18px] h-[19px]" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18.7046">
      <path d={svgPathsNew.p24e18e30} fill="currentColor" />
    </svg>
  );
}

function SettingsIcon() {
  return (
    <svg className="w-[20px] h-[20px]" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
      <path d={svgPathsNew.p26b9fc90} stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
      <path d={svgPathsNew.p7630580} stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
    </svg>
  );
}

export function Sidebar({ activePage, onNavigate }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: CategoryIcon },
    { id: 'tickets', label: 'Tickets', icon: TicketIcon },
    { id: 'users', label: 'Users', icon: ProfileIcon },
    { id: 'courses', label: 'View Courses', icon: BookIcon },
    { id: 'new-course', label: 'Add Course', icon: () => <Plus className="w-[22px] h-[22px]" strokeWidth={2} /> },
    { id: 'analytics', label: 'Analysis', icon: AnalyticsIcon },
    { id: 'logout', label: 'Logout', icon: LogoutIcon },
  ];

  return (
    <aside className="hidden md:flex md:flex-col w-[249px] h-screen bg-white border-r border-[#e7e7e7] fixed left-0 top-0">
      {/* Logo */}
      <div className="h-[104px] flex items-center px-[35px]">
        <h1 className="font-['Montserrat'] font-semibold text-[24px] text-[#2e2c34] uppercase">
          Ticket Lead
        </h1>
      </div>

      {/* Navigation */}
      <nav className="flex-1 pt-3">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-[12px] px-[19px] h-[45px] transition-colors ${
                isActive
                  ? 'bg-[rgba(127,86,216,0.1)] text-[#7f56d8]'
                  : 'text-[#2e2c34] hover:bg-gray-50'
              }`}
            >
              <div className={`flex items-center justify-center ${isActive ? 'text-[#7f56d8]' : 'text-[#2e2c34]'}`}>
                <Icon />
              </div>
              <span className="font-['Montserrat'] font-medium text-[16px]">
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Site Settings at Bottom */}
      <div className="pb-6">
        <button
          onClick={() => onNavigate('site-settings')}
          className={`w-full flex items-center gap-[12px] px-[36px] h-[45px] transition-colors ${
            activePage === 'site-settings'
              ? 'bg-[rgba(127,86,216,0.1)] text-[#7f56d8]'
              : 'text-[#2e2c34] hover:bg-gray-50'
          }`}
        >
          <div className={`flex items-center justify-center ${activePage === 'site-settings' ? 'text-[#7f56d8]' : 'text-[#2e2c34]'}`}>
            <SettingsIcon />
          </div>
          <span className="font-['Montserrat'] font-medium text-[16px]">
            Site Settings
          </span>
        </button>
      </div>
    </aside>
  );
}