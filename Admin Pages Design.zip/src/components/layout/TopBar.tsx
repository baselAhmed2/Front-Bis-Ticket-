import { Menu, User } from 'lucide-react';

interface TopBarProps {
  userName?: string;
  onMenuClick?: () => void;
}

export function TopBar({ userName = 'DR Bahlol', onMenuClick }: TopBarProps) {
  return (
    <header className="h-[85px] bg-white shadow-[0px_4px_40px_1px_rgba(0,0,0,0.03)] flex items-center justify-between px-5 md:px-8 fixed top-0 left-0 md:left-[249px] right-0 z-40">
      <div className="flex items-center gap-4">
        <button
          onClick={onMenuClick}
          className="md:hidden p-2 hover:bg-gray-100 rounded-lg"
          aria-label="Open menu"
        >
          <Menu className="w-6 h-6 text-[#2e2c34]" />
        </button>
        
        <p className="font-['Montserrat'] font-medium text-[16px] md:text-[18px] text-[#2e2c34]">
          Welcome!
        </p>
      </div>

      <div className="flex items-center gap-3 bg-[#fafafa] rounded-full px-2 py-2">
        <div className="w-10 h-10 md:w-12 md:h-12 rounded-full overflow-hidden bg-gradient-to-br from-[#7f56d8] to-[#6b47c2] flex items-center justify-center">
          <User className="w-6 h-6 text-white" />
        </div>
        <span className="hidden md:block font-['Montserrat'] font-semibold text-[16px] text-[#1a202c] pr-3">
          {userName}
        </span>
      </div>
    </header>
  );
}