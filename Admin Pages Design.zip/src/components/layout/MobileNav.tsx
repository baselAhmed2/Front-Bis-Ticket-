import { X, Plus } from 'lucide-react';
import svgPaths from '../../imports/svg-6am2xkkp4v';
import svgPathsNew from '../../imports/svg-x8fykqtpoi';

interface MobileNavProps {
  isOpen: boolean;
  activePage: string;
  onClose: () => void;
  onNavigate: (page: string) => void;
}

// SVG Icons Components
function CategoryIcon() {
  return (
    <svg className="w-[22px] h-[22px]" fill="none" preserveAspectRatio="none" viewBox="0 0 17.875 17.875">
      <g>
        <path clipRule="evenodd" d={svgPaths.p1b0dd80} fill="currentColor" fillRule="evenodd" />
        <path clipRule="evenodd" d={svgPaths.p1d036400} fill="currentColor" fillRule="evenodd" />
        <path clipRule="evenodd" d={svgPaths.pdd4a200} fill="currentColor" fillRule="evenodd" />
        <path clipRule="evenodd" d={svgPaths.p20c71180} fill="currentColor" fillRule="evenodd" />
      </g>
    </svg>
  );
}

function TicketIcon() {
  return (
    <svg className="w-[22px] h-[22px]" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
      <path d={svgPathsNew.p1ff1d2f0} stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
    </svg>
  );
}

function ProfileIcon() {
  return (
    <svg className="w-[16px] h-[20px]" fill="none" preserveAspectRatio="none" viewBox="0 0 16 20">
      <g>
        <path clipRule="evenodd" d={svgPathsNew.p1dfa98f0} fill="currentColor" fillRule="evenodd" />
        <path clipRule="evenodd" d={svgPathsNew.p3094ef0} fill="currentColor" fillRule="evenodd" />
      </g>
    </svg>
  );
}

function BookIcon() {
  return (
    <svg className="w-[20px] h-[20px]" fill="none" preserveAspectRatio="none" viewBox="0 0 20 17.1429">
      <path d={svgPathsNew.p17b07800} stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function AnalyticsIcon() {
  return (
    <svg className="w-[20px] h-[20px]" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
      <path d={svgPathsNew.p5d04380} fill="currentColor" />
    </svg>
  );
}

function LogoutIcon() {
  return (
    <svg className="w-[18px] h-[19px]" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18.7046">
      <path d={svgPathsNew.p24e18e30} fill="currentColor" />
    </svg>
  );
}

function SettingsIcon() {
  return (
    <svg className="w-[20px] h-[20px]" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
      <path d={svgPathsNew.p26b9fc90} stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
      <path d={svgPathsNew.p7630580} stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
    </svg>
  );
}

export function MobileNav({ isOpen, activePage, onClose, onNavigate }: MobileNavProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: CategoryIcon },
    { id: 'tickets', label: 'Tickets', icon: TicketIcon },
    { id: 'users', label: 'Users', icon: ProfileIcon },
    { id: 'courses', label: 'View Courses', icon: BookIcon },
    { id: 'new-course', label: 'Add Course', icon: () => <Plus className="w-[22px] h-[22px]" strokeWidth={2} /> },
    { id: 'analytics', label: 'Analysis', icon: AnalyticsIcon },
    { id: 'logout', label: 'Logout', icon: LogoutIcon },
  ];

  const handleNavigate = (page: string) => {
    onNavigate(page);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/50 z-40 md:hidden"
        onClick={onClose}
      />

      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-screen w-[280px] bg-white z-50 md:hidden shadow-xl flex flex-col">
        {/* Header */}
        <div className="h-[85px] flex items-center justify-between px-6 border-b border-[#e7e7e7]">
          <h1 className="font-['Montserrat'] font-semibold text-[24px] text-[#2e2c34] uppercase">
            Ticket Lead
          </h1>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-[#2e2c34]" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 pt-3 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                className={`w-full flex items-center gap-[12px] px-[19px] h-[45px] transition-colors ${
                  isActive
                    ? 'bg-[rgba(127,86,216,0.1)] text-[#7f56d8]'
                    : 'text-[#2e2c34] hover:bg-gray-50'
                }`}
              >
                <div className={`flex items-center justify-center ${isActive ? 'text-[#7f56d8]' : 'text-[#2e2c34]'}`}>
                  <Icon />
                </div>
                <span className="font-['Montserrat'] font-medium text-[16px]">
                  {item.label}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Site Settings at Bottom */}
        <div className="pb-6 border-t border-[#e7e7e7]">
          <button
            onClick={() => handleNavigate('site-settings')}
            className={`w-full flex items-center gap-[12px] px-[36px] h-[45px] transition-colors ${
              activePage === 'site-settings'
                ? 'bg-[rgba(127,86,216,0.1)] text-[#7f56d8]'
                : 'text-[#2e2c34] hover:bg-gray-50'
            }`}
          >
            <div className={`flex items-center justify-center ${activePage === 'site-settings' ? 'text-[#7f56d8]' : 'text-[#2e2c34]'}`}>
              <SettingsIcon />
            </div>
            <span className="font-['Montserrat'] font-medium text-[16px]">
              Site Settings
            </span>
          </button>
        </div>
      </aside>
    </>
  );
}