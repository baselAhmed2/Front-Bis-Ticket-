import svgPaths from '../../imports/svg-stats-cards';
import imgNewTicket from 'figma:asset/4a48e9ef3542f6dfa5c2b4006a3bd35174343b86.png';
import imgInProgress from 'figma:asset/9167c8be93d950c9eebb94ae4a66f19fa94485fa.png';
import imgClosed from 'figma:asset/8222eca410c3d1ecebf8045ae4e6e773ae14b8a5.png';

interface StatsCardProps {
  title: string;
  count: number;
  gradient: string;
  onClick: () => void;
}

export function StatsCard({ title, count, gradient, onClick }: StatsCardProps) {
  // Map title to background color, svg path, and image
  const getCardData = () => {
    if (title === 'New Tickets') {
      return {
        bgColor: '#0BF4C8',
        svgPath: svgPaths.newTicket,
        imageSrc: imgNewTicket,
        imageStyle: {
          left: '150px',
          top: '43px',
          width: '136px',
          height: '110px',
          imgWidth: '138.17%',
          imgHeight: '121.17%',
          imgLeft: '-22.5%',
          imgTop: '-13.81%',
        },
        shadowColor: '#34dabb',
        opacity: 0.24,
      };
    } else if (title === 'In Progress') {
      return {
        bgColor: '#FAD85D',
        svgPath: svgPaths.inProgress,
        imageSrc: imgInProgress,
        imageStyle: {
          left: '126px',
          top: '18px',
          width: '169px',
          height: '135px',
          imgWidth: '125.64%',
          imgHeight: '118.18%',
          imgLeft: '-12.79%',
          imgTop: '-9.52%',
        },
        shadowColor: '#f1cb41',
        opacity: 0.1,
      };
    } else if (title === 'Closed') {
      return {
        bgColor: '#F2A0FF',
        svgPath: svgPaths.closed,
        imageSrc: imgClosed,
        imageStyle: {
          left: '173px',
          top: '-14px',
          width: '127px',
          height: '173px',
          imgWidth: '103.34%',
          imgHeight: '107.35%',
          imgLeft: '0',
          imgTop: '-2.52%',
        },
        shadowColor: '#e879f9',
        opacity: 0.1,
      };
    }
    // Default
    return {
      bgColor: '#7f56d8',
      svgPath: svgPaths.newTicket,
      imageSrc: imgNewTicket,
      imageStyle: {
        left: '150px',
        top: '43px',
        width: '136px',
        height: '110px',
        imgWidth: '138.17%',
        imgHeight: '121.17%',
        imgLeft: '-22.5%',
        imgTop: '-13.81%',
      },
      shadowColor: '#7f56d8',
      opacity: 0.24,
    };
  };

  const cardData = getCardData();

  return (
    <div
      onClick={onClick}
      className="relative h-[159px] w-full cursor-pointer group transition-transform hover:scale-105"
    >
      {/* Background SVG Shape */}
      <div className="absolute h-[159px] left-0 top-0 w-full">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 300 159">
          <path d={cardData.svgPath} fill={cardData.bgColor} />
        </svg>
      </div>

      {/* Decorative Background Elements */}
      <div className="absolute inset-0">
        {/* Top left diagonal lines */}
        <div className="absolute left-[27px] top-[8px]">
          <div className="absolute flex h-[31.072px] items-center justify-center left-0 top-0 w-[79.155px]">
            <div className="-rotate-15 flex-none">
              <div 
                className="h-[11px] rounded-[100px] w-[79px]" 
                style={{ backgroundColor: `rgba(255,255,255,${cardData.opacity})` }}
              />
            </div>
          </div>
          <div className="absolute flex h-[31.072px] items-center justify-center left-[96px] top-[3px] w-[79.155px]">
            <div className="-rotate-15 flex-none">
              <div 
                className="h-[11px] rounded-[100px] w-[79px]" 
                style={{ backgroundColor: `rgba(255,255,255,${cardData.opacity})` }}
              />
            </div>
          </div>
          <div className="absolute flex h-[31.072px] items-center justify-center left-[8px] top-[28px] w-[79.155px]">
            <div className="-rotate-15 flex-none">
              <div 
                className="h-[11px] rounded-[100px] w-[79px]" 
                style={{ backgroundColor: `rgba(255,255,255,${cardData.opacity})` }}
              />
            </div>
          </div>
        </div>

        {/* Bottom right diagonal lines */}
        <div className="absolute right-0 bottom-0">
          <div className="absolute flex h-[31.072px] items-center justify-center right-[105px] bottom-[59px] w-[79.155px]">
            <div className="flex-none rotate-165">
              <div 
                className="h-[11px] rounded-[100px] w-[79px]" 
                style={{ backgroundColor: `rgba(255,255,255,${cardData.opacity})` }}
              />
            </div>
          </div>
          <div className="absolute flex h-[31.072px] items-center justify-center right-[9px] bottom-[56px] w-[79.155px]">
            <div className="flex-none rotate-165">
              <div 
                className="h-[11px] rounded-[100px] w-[79px]" 
                style={{ backgroundColor: `rgba(255,255,255,${cardData.opacity})` }}
              />
            </div>
          </div>
          <div className="absolute flex h-[31.072px] items-center justify-center right-[17px] bottom-[84px] w-[79.155px]">
            <div className="flex-none rotate-165">
              <div 
                className="h-[11px] rounded-[100px] w-[79px]" 
                style={{ backgroundColor: `rgba(255,255,255,${cardData.opacity})` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Image */}
      <div 
        className="absolute overflow-hidden pointer-events-none"
        style={{
          left: cardData.imageStyle.left,
          top: cardData.imageStyle.top,
          width: cardData.imageStyle.width,
          height: cardData.imageStyle.height,
          filter: `drop-shadow(0px 4px 4px ${cardData.shadowColor})`,
        }}
      >
        <img 
          alt="" 
          className="absolute max-w-none" 
          src={cardData.imageSrc}
          style={{
            width: cardData.imageStyle.imgWidth,
            height: cardData.imageStyle.imgHeight,
            left: cardData.imageStyle.imgLeft,
            top: cardData.imageStyle.imgTop,
          }}
        />
      </div>

      {/* Text Content */}
      <div className="absolute left-[24px] top-[22px]">
        <p className="font-['Poppins'] font-medium text-[16px] text-[#131215] tracking-[0.48px] mb-4">
          {title}
        </p>
        <p className="font-['Poppins'] font-medium text-[32px] text-[#131215] tracking-[0.96px]">
          {count}
        </p>
      </div>

      {/* View entire list link */}
      <p className="absolute left-[27px] top-[119px] font-['Poppins'] font-normal text-[12px] text-[#131215] tracking-[0.36px] underline decoration-solid decoration-skip-ink-none cursor-pointer hover:no-underline w-[94px]">
        View entire list
      </p>
    </div>
  );
}
