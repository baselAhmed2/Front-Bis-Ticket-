import { CheckCircle, XCircle, AlertTriangle, Info, X } from 'lucide-react';
import { useEffect } from 'react';

export type ToastType = 'success' | 'error' | 'warning' | 'info';

interface ToastProps {
  type: ToastType;
  title: string;
  message: string;
  onClose: () => void;
  duration?: number;
}

export function Toast({ type, title, message, onClose, duration = 5000 }: ToastProps) {
  useEffect(() => {
    if (duration > 0) {
      const timer = setTimeout(onClose, duration);
      return () => clearTimeout(timer);
    }
  }, [duration, onClose]);

  const config = {
    success: {
      bg: 'bg-[#e6faf5]',
      border: 'border-[#00CC99]',
      accent: 'bg-[#00CC99]',
      icon: CheckCircle,
      iconColor: 'text-[#00CC99]',
    },
    error: {
      bg: 'bg-[#fdeeee]',
      border: 'border-[#eb5757]',
      accent: 'bg-[#eb5757]',
      icon: XCircle,
      iconColor: 'text-[#eb5757]',
    },
    warning: {
      bg: 'bg-[#fdf8e8]',
      border: 'border-[#f2c94c]',
      accent: 'bg-[#f2c94c]',
      icon: AlertTriangle,
      iconColor: 'text-[#f2c94c]',
    },
    info: {
      bg: 'bg-[#eeeefe]',
      border: 'border-[#5458f7]',
      accent: 'bg-[#5458f7]',
      icon: Info,
      iconColor: 'text-[#5458f7]',
    },
  };

  const { bg, border, accent, icon: Icon, iconColor } = config[type];

  return (
    <div
      className={`${bg} ${border} border rounded-xl flex items-start gap-4 p-4 shadow-lg max-w-md relative animate-in slide-in-from-right`}
    >
      <div className={`${accent} w-1.5 absolute left-0 top-0 bottom-0 rounded-l-xl`} />
      
      <div className="ml-2">
        <Icon className={`w-6 h-6 ${iconColor}`} />
      </div>

      <div className="flex-1">
        <h4 className="font-['Poppins'] font-medium text-[18px] md:text-[20px] text-[#2f3032] mb-1">
          {title}
        </h4>
        <p className="font-['Poppins'] font-normal text-[14px] md:text-[16px] text-[#2f3032]">
          {message}
        </p>
      </div>

      <button
        onClick={onClose}
        className="text-gray-400 hover:text-gray-600"
      >
        <X className="w-5 h-5" />
      </button>
    </div>
  );
}
