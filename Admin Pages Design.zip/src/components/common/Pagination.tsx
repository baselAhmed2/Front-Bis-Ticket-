interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export function Pagination({ currentPage, totalPages, onPageChange }: PaginationProps) {
  return (
    <div className="flex items-center justify-center gap-2 mt-6">
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className="px-3 py-1.5 font-['Montserrat'] font-medium text-[14px] text-[#84818a] disabled:opacity-50 disabled:cursor-not-allowed hover:text-[#7f56d8]"
      >
        Previous
      </button>

      {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
        <button
          key={page}
          onClick={() => onPageChange(page)}
          className={`w-8 h-8 rounded font-['Montserrat'] font-medium text-[14px] ${
            currentPage === page
              ? 'bg-[#7f56d8] text-white'
              : 'bg-white text-[#2e2c34] border border-[#e7e7e7] hover:border-[#7f56d8]'
          }`}
        >
          {page}
        </button>
      ))}

      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className="px-3 py-1.5 font-['Montserrat'] font-medium text-[14px] text-[#84818a] disabled:opacity-50 disabled:cursor-not-allowed hover:text-[#7f56d8]"
      >
        Next
      </button>
    </div>
  );
}
