import { AlertTriangle } from 'lucide-react';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  title?: string;
  message: string;
  onConfirm: () => void;
  onClose: () => void;
}

export function DeleteConfirmModal({
  isOpen,
  title = 'Delete User',
  message,
  onConfirm,
  onClose,
}: DeleteConfirmModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Overlay */}
      <div
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-white rounded-lg shadow-xl max-w-md w-full p-6 animate-in fade-in zoom-in duration-200">
        {/* Icon */}
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center">
            <AlertTriangle className="w-8 h-8 text-[#e7000b]" />
          </div>
        </div>

        {/* Title */}
        <h2 className="font-['Montserrat'] font-semibold text-[20px] text-[#2e2c34] text-center mb-2">
          {title}
        </h2>

        {/* Message */}
        <p className="font-['Montserrat'] font-medium text-[14px] text-[#84818a] text-center mb-6">
          {message}
        </p>

        {/* Buttons */}
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 bg-white border border-[#e7e7e7] text-[#2e2c34] h-[44px] rounded-md font-['Montserrat'] font-semibold text-[14px] hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="flex-1 bg-[#e7000b] text-white h-[44px] rounded-md font-['Montserrat'] font-semibold text-[14px] hover:bg-[#c50009] transition-colors"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}