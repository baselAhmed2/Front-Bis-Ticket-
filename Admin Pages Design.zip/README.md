
  # Admin Pages Design

  This is a code bundle for Admin Pages Design. The original project is available at https://www.figma.com/design/GF7wy5dCUuM01ZC8QsFwyT/Admin-Pages-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  