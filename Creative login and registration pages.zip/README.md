
  # Creative login and registration pages

  This is a code bundle for Creative login and registration pages. The original project is available at https://www.figma.com/design/ZWOWiQg0CeEykPQdy83LrQ/Creative-login-and-registration-pages.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  