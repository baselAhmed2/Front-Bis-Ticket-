import { Outlet } from "react-router";
import campusImage from "figma:asset/dee865f9bb3923e52c37011b66fee73003706bed.png";
import { motion } from "motion/react";

export function Layout() {
  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-gray-900 font-sans text-gray-100">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={campusImage}
          alt="Capital University Campus"
          className="h-full w-full object-cover opacity-60 filter blur-[2px] transition-all duration-1000 hover:blur-0"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900/90 via-gray-900/50 to-transparent" />
        <div className="absolute inset-0 bg-blue-900/20 mix-blend-overlay" />
      </div>

      {/* Floating Shapes for Creativity */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{
            y: [0, -20, 0],
            rotate: [0, 5, 0],
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-10 left-10 h-64 w-64 rounded-full bg-yellow-500/10 blur-3xl"
        />
        <motion.div
          animate={{
            y: [0, 30, 0],
            rotate: [0, -5, 0],
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute bottom-20 right-20 h-80 w-80 rounded-full bg-blue-500/10 blur-3xl"
        />
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 flex min-h-screen flex-col items-center justify-center p-4">
        <Outlet />
      </div>
      
      {/* Footer */}
      <footer className="absolute bottom-4 w-full text-center text-xs text-gray-400 z-10">
        <p>&copy; {new Date().getFullYear()} Capital University. All rights reserved.</p>
      </footer>
    </div>
  );
}
