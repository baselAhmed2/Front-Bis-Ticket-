import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { Check, ChevronLeft, ArrowRight, User, Mail, ShieldCheck } from "lucide-react";

import sbsLogo from "figma:asset/df8a8eb1f1f0c3d3cb8216c5b12e893923ca8177.png";
import fmiLogo from "figma:asset/5b63589bd61bc1de03b2030091922d2439eb80be.png";
import bisLogo from "figma:asset/e6bd72cf1db1862b34aec9f91c12effeb0218d91.png";

const programs = [
  {
    id: "sbs",
    title: "Specialized Banking Science",
    code: "SBS",
    logo: sbsLogo,
    color: "from-blue-600 to-blue-800",
    description: "Advanced banking operations and financial strategies."
  },
  {
    id: "fmi",
    title: "Financial Markets & Institutions",
    code: "FMI",
    logo: fmiLogo,
    color: "from-green-600 to-emerald-800",
    description: "Global financial markets analysis and investment banking."
  },
  {
    id: "bis",
    title: "Business Information Systems",
    code: "BIS",
    logo: bisLogo,
    color: "from-indigo-600 to-purple-800",
    description: "Technology-driven business solutions and analytics."
  },
];

export function RegisterPage() {
  const [selectedProgram, setSelectedProgram] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    fullName: "",
    studentId: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProgram) return;
    
    setLoading(true);
    // Simulate registration
    await new Promise((resolve) => setTimeout(resolve, 2000));
    setLoading(false);
    navigate("/dashboard"); // Redirect to dashboard after registration
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="w-full max-w-5xl"
    >
      <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-white/5 backdrop-blur-xl shadow-2xl p-8 md:p-12">
        
        {/* Header */}
        <div className="mb-10 text-center">
          <Link to="/" className="absolute top-8 left-8 flex items-center text-sm text-gray-400 hover:text-white transition-colors">
            <ChevronLeft className="mr-1 h-4 w-4" />
            Back to Login
          </Link>
          <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">
            Program Registration
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Select your academic program to begin the registration process for the Capital University student ticketing system.
          </p>
        </div>

        {/* Program Selection Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {programs.map((program) => (
            <motion.div
              key={program.id}
              onClick={() => setSelectedProgram(program.id)}
              whileHover={{ scale: 1.02, translateY: -5 }}
              whileTap={{ scale: 0.98 }}
              className={`relative cursor-pointer overflow-hidden rounded-2xl border-2 transition-all duration-300 ${
                selectedProgram === program.id 
                  ? "border-blue-500 bg-white/10 shadow-lg shadow-blue-500/20" 
                  : "border-white/5 bg-white/5 hover:bg-white/10 hover:border-white/20"
              }`}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${program.color} opacity-0 transition-opacity duration-300 ${selectedProgram === program.id ? "opacity-10" : "group-hover:opacity-5"}`} />
              
              <div className="p-6 flex flex-col items-center text-center h-full">
                <div className="relative mb-4 h-24 w-24 rounded-full bg-white p-3 shadow-lg">
                  <img src={program.logo} alt={program.title} className="h-full w-full object-contain" />
                  {selectedProgram === program.id && (
                    <motion.div 
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-blue-500 text-white shadow-md"
                    >
                      <Check className="h-4 w-4" />
                    </motion.div>
                  )}
                </div>
                
                <h3 className="text-lg font-bold text-white mb-2">{program.title}</h3>
                <span className="inline-block rounded-full bg-white/10 px-3 py-1 text-xs font-medium text-blue-200 mb-3">
                  {program.code}
                </span>
                <p className="text-xs text-gray-400 leading-relaxed">
                  {program.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Registration Form */}
        <AnimatePresence mode="wait">
          {selectedProgram && (
            <motion.div
              key={selectedProgram}
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <div className="border-t border-white/10 pt-8 mt-4">
                <h2 className="text-xl font-semibold text-white mb-6 flex items-center">
                  <span className="bg-blue-500 h-6 w-1 rounded-full mr-3" />
                  Complete Your Profile
                </h2>
                
                <form onSubmit={handleRegister} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4 md:col-span-2">
                    <div className="group relative">
                      <label className="block text-xs font-medium text-gray-400 mb-1 ml-1">Full Name</label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-500" />
                        <input
                          type="text"
                          required
                          className="w-full rounded-xl border border-white/10 bg-black/20 px-10 py-3 text-white placeholder-gray-500 outline-none focus:border-blue-500/50 focus:bg-black/40 transition-all"
                          placeholder="John Doe"
                          value={formData.fullName}
                          onChange={e => setFormData({...formData, fullName: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="group relative">
                        <label className="block text-xs font-medium text-gray-400 mb-1 ml-1">Student ID</label>
                        <div className="relative">
                          <ShieldCheck className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-500" />
                          <input
                            type="text"
                            required
                            className="w-full rounded-xl border border-white/10 bg-black/20 px-10 py-3 text-white placeholder-gray-500 outline-none focus:border-blue-500/50 focus:bg-black/40 transition-all"
                            placeholder="2024xxxx"
                            value={formData.studentId}
                            onChange={e => setFormData({...formData, studentId: e.target.value})}
                          />
                        </div>
                      </div>
                      
                      <div className="group relative">
                        <label className="block text-xs font-medium text-gray-400 mb-1 ml-1">Set Password</label>
                        <div className="relative">
                          <ShieldCheck className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-500" />
                          <input
                            type="password"
                            required
                            className="w-full rounded-xl border border-white/10 bg-black/20 px-10 py-3 text-white placeholder-gray-500 outline-none focus:border-blue-500/50 focus:bg-black/40 transition-all"
                            placeholder="••••••••"
                            value={formData.password}
                            onChange={e => setFormData({...formData, password: e.target.value})}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="md:col-span-2 pt-4">
                    <motion.button
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      type="submit"
                      disabled={loading}
                      className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 py-4 font-bold text-white shadow-lg shadow-blue-500/25 transition-all hover:shadow-blue-500/40"
                    >
                      {loading ? "Creating Account..." : "Complete Registration"}
                    </motion.button>
                    <p className="mt-4 text-center text-xs text-gray-500">
                      By registering, you agree to the university's academic integrity policy and terms of service.
                    </p>
                  </div>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        {!selectedProgram && (
           <div className="text-center mt-8 text-sm text-gray-500 italic">
             Please select your program above to proceed.
           </div>
        )}
      </div>
    </motion.div>
  );
}
