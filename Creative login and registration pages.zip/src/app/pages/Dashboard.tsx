import { Link } from "react-router";
import { motion } from "motion/react";
import { LayoutDashboard, FileText, Settings, LogOut, PlusCircle } from "lucide-react";

export function Dashboard() {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="w-full max-w-6xl"
    >
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        
        {/* Sidebar / Navigation Card */}
        <div className="col-span-1 rounded-2xl border border-white/10 bg-white/5 backdrop-blur-xl p-6 shadow-xl h-fit">
          <div className="flex items-center space-x-3 mb-8">
            <div className="h-10 w-10 rounded-full bg-blue-500/20 flex items-center justify-center">
              <span className="font-bold text-blue-400">CU</span>
            </div>
            <div>
              <h3 className="font-bold text-white">Student Portal</h3>
              <p className="text-xs text-gray-400">Spring 2026</p>
            </div>
          </div>
          
          <nav className="space-y-2">
            <NavItem icon={LayoutDashboard} label="Overview" active />
            <NavItem icon={FileText} label="My Tickets" />
            <NavItem icon={PlusCircle} label="New Complaint" />
            <NavItem icon={Settings} label="Settings" />
            
            <div className="pt-8 mt-8 border-t border-white/10">
              <Link to="/" className="flex items-center space-x-3 rounded-xl px-4 py-3 text-sm font-medium text-red-400 hover:bg-red-500/10 transition-colors">
                <LogOut className="h-5 w-5" />
                <span>Sign Out</span>
              </Link>
            </div>
          </nav>
        </div>

        {/* Main Content */}
        <div className="col-span-1 md:col-span-3 space-y-6">
          
          {/* Welcome Banner */}
          <div className="rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 p-8 shadow-lg text-white relative overflow-hidden">
            <div className="relative z-10">
              <h1 className="text-2xl font-bold mb-2">Welcome back, Student!</h1>
              <p className="text-blue-100 max-w-lg">
                You have 0 active tickets. Submit a new complaint or track the status of your existing coursework issues here.
              </p>
            </div>
            <div className="absolute right-0 top-0 h-full w-1/3 bg-white/10 skew-x-12 transform translate-x-10" />
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard label="Total Tickets" value="0" color="bg-blue-500/10 text-blue-400 border-blue-500/20" />
            <StatCard label="Pending" value="0" color="bg-yellow-500/10 text-yellow-400 border-yellow-500/20" />
            <StatCard label="Resolved" value="0" color="bg-green-500/10 text-green-400 border-green-500/20" />
          </div>

          {/* Recent Activity Placeholder */}
          <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-md p-6">
            <h3 className="font-bold text-white mb-4">Recent Activity</h3>
            <div className="flex flex-col items-center justify-center py-12 text-gray-500 space-y-3">
              <FileText className="h-12 w-12 opacity-20" />
              <p>No recent complaints found.</p>
              <button className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm transition-colors">
                Create First Ticket
              </button>
            </div>
          </div>
        </div>

      </div>
    </motion.div>
  );
}

function NavItem({ icon: Icon, label, active = false }: { icon: any, label: string, active?: boolean }) {
  return (
    <button className={`w-full flex items-center space-x-3 rounded-xl px-4 py-3 text-sm font-medium transition-all ${
      active 
        ? "bg-blue-500 text-white shadow-lg shadow-blue-500/20" 
        : "text-gray-400 hover:bg-white/5 hover:text-white"
    }`}>
      <Icon className="h-5 w-5" />
      <span>{label}</span>
    </button>
  );
}

function StatCard({ label, value, color }: { label: string, value: string, color: string }) {
  return (
    <div className={`rounded-xl border p-6 ${color}`}>
      <h4 className="text-sm font-medium opacity-80">{label}</h4>
      <p className="text-3xl font-bold mt-2">{value}</p>
    </div>
  );
}
