
  # Student Pages Design Setup

  This is a code bundle for Student Pages Design Setup. The original project is available at https://www.figma.com/design/jwyeh374Edxjqv9OWNKDYz/Student-Pages-Design-Setup.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  