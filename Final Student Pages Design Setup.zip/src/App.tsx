import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { TicketList, Ticket } from './components/TicketList';
import { NewTicketForm, TicketFormData } from './components/NewTicketForm';
import { TicketDetails, TicketDetailsData } from './components/TicketDetails';
import { Alert } from './components/Alert';

// Mock data - Replace with actual API calls
const mockTickets: Ticket[] = [
  {
    id: '1',
    ticketNumber: '2023-CS123',
    subject: 'How to Join to my portal?',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    status: 'not-replayed',
    assignedTo: {
      name: 'Dr.John Snow',
    },
    createdAt: '12:45 AM',
    isReply: false,
  },
  {
    id: '2',
    ticketNumber: '2023-CS123',
    subject: 'How to Join to my portal?',
    description:
      'The answer is Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur.',
    status: 'resolved',
    assignedTo: {
      name: 'Dr Mohamed Ahmed',
    },
    createdAt: '12:45 AM',
    isReply: true,
  },
  {
    id: '3',
    ticketNumber: '2023-CS123',
    subject: 'How to Join to my portal?',
    description: 'Hello mohamed you can do 1 2 3 4 5',
    status: 'on-going',
    assignedTo: {
      name: 'Dr Snow',
    },
    createdAt: '12:45 AM',
    isReply: true,
  },
];

type AlertData = {
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
} | null;

type PageType = 'dashboard' | 'new-ticket' | 'ticket-details';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [tickets, setTickets] = useState<Ticket[]>(mockTickets);
  const [selectedTicket, setSelectedTicket] = useState<TicketDetailsData | null>(null);
  const [isLoadingTickets, setIsLoadingTickets] = useState(false);
  const [isSubmittingTicket, setIsSubmittingTicket] = useState(false);
  const [isSubmittingReply, setIsSubmittingReply] = useState(false);
  const [alert, setAlert] = useState<AlertData>(null);

  // User data - Replace with actual user data from authentication
  // TODO: Fetch from API: GET /api/user/profile
  const userData = {
    name: 'John Smith',
    image: undefined,
  };

  // Handle ticket submission
  const handleSubmitTicket = async (data: TicketFormData) => {
    setIsSubmittingTicket(true);

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // TODO: Replace with actual API call
      // const response = await fetch('/api/tickets', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(data),
      // });
      // const result = await response.json();

      // Show success alert
      setAlert({
        type: 'success',
        title: 'Success',
        message: 'Ticket created successfully. You will receive a response soon.',
      });

      // Navigate to dashboard after 2 seconds
      setTimeout(() => {
        setCurrentPage('dashboard');
        setAlert(null);
      }, 2000);
    } catch (error) {
      console.error('Error submitting ticket:', error);
      setAlert({
        type: 'error',
        title: 'Error',
        message: 'Failed to create ticket. Please try again.',
      });
    } finally {
      setIsSubmittingTicket(false);
    }
  };

  // Handle ticket click (navigate to ticket details)
  const handleTicketClick = async (ticket: Ticket) => {
    // TODO: Fetch full ticket details from API
    // const response = await fetch(`/api/tickets/${ticket.id}`);
    // const ticketDetails = await response.json();

    // Mock ticket details
    const ticketDetails: TicketDetailsData = {
      ...ticket,
      category: 'Classwork Issue',
      groupNumber: '9',
      replies: [
        {
          id: 'r1',
          message: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. We are looking into your issue.',
          sender: { name: 'You', type: 'student' },
          createdAt: '12-11-2024',
        },
        {
          id: 'r2',
          message: 'Your issue has been resolved. Please check your portal and let us know if you need further assistance.',
          sender: { name: 'Dr. Ahmed Mohamed', type: 'admin' },
          createdAt: '13-11-2024',
        },
      ],
      student: {
        id: '512393207',
        name: 'Basel Ahmed',
        semester: 'Semester 2',
        subject: '02 - Internet Application',
      },
    };

    setSelectedTicket(ticketDetails);
    setCurrentPage('ticket-details');
  };

  // Handle reply submission
  const handleReply = async (message: string) => {
    setIsSubmittingReply(true);

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // TODO: Replace with actual API call
      // await fetch(`/api/tickets/${selectedTicket?.id}/replies`, {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ message }),
      // });

      setAlert({
        type: 'success',
        title: 'Success',
        message: 'Reply sent successfully!',
      });

      // Update local ticket with new reply
      if (selectedTicket) {
        const newReply = {
          id: `r${selectedTicket.replies.length + 1}`,
          message,
          sender: { name: 'You', type: 'student' as const },
          createdAt: new Date().toLocaleDateString(),
        };
        setSelectedTicket({
          ...selectedTicket,
          replies: [...selectedTicket.replies, newReply],
        });
      }

      setTimeout(() => setAlert(null), 3000);
    } catch (error) {
      console.error('Error sending reply:', error);
      setAlert({
        type: 'error',
        title: 'Error',
        message: 'Failed to send reply. Please try again.',
      });
    } finally {
      setIsSubmittingReply(false);
    }
  };

  // Handle logout
  const handleLogout = () => {
    // TODO: Implement actual logout logic
    console.log('Logging out...');
    setAlert({
      type: 'warning',
      title: 'Warning',
      message: 'You are about to be logged out.',
    });
  };

  // Get page title
  const getPageTitle = () => {
    switch (currentPage) {
      case 'dashboard':
        return 'Tickets';
      case 'new-ticket':
        return 'New Ticket';
      case 'ticket-details':
        return 'Ticket Details';
      default:
        return 'Tickets';
    }
  };

  return (
    <div className="flex h-screen bg-[#f9f9fb] overflow-hidden">
      {/* Sidebar */}
      <Sidebar
        currentPage={currentPage === 'ticket-details' ? 'dashboard' : currentPage}
        onNavigate={(page) => {
          setCurrentPage(page);
          setSelectedTicket(null);
        }}
        onLogout={handleLogout}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <TopBar
          userName={userData.name}
          userImage={userData.image}
          onMenuClick={() => setIsSidebarOpen(true)}
        />

        {/* Page Title */}
        <div className="bg-white border-b border-gray-200 px-4 lg:px-6 py-4">
          <h1 className="font-['Montserrat'] font-semibold text-xl lg:text-2xl text-[#2e2c34]">
            {getPageTitle()}
          </h1>
        </div>

        {/* Alert */}
        {alert && (
          <div className="px-4 lg:px-6 pt-4">
            <Alert
              type={alert.type}
              title={alert.title}
              message={alert.message}
              onClose={() => setAlert(null)}
            />
          </div>
        )}

        {/* Content Area */}
        <div className="flex-1 overflow-hidden">
          {currentPage === 'dashboard' ? (
            <TicketList
              tickets={tickets}
              isLoading={isLoadingTickets}
              onTicketClick={handleTicketClick}
              onNewTicket={() => setCurrentPage('new-ticket')}
            />
          ) : currentPage === 'new-ticket' ? (
            <div className="h-full overflow-auto p-4 lg:p-6">
              <NewTicketForm onSubmit={handleSubmitTicket} isSubmitting={isSubmittingTicket} />
            </div>
          ) : currentPage === 'ticket-details' && selectedTicket ? (
            <TicketDetails
              ticket={selectedTicket}
              onBack={() => setCurrentPage('dashboard')}
              onReply={handleReply}
              isSubmittingReply={isSubmittingReply}
            />
          ) : null}
        </div>
      </div>
    </div>
  );
}