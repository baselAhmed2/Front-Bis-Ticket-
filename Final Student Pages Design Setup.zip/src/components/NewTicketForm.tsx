import { useState } from 'react';
import { ChevronDown, Paperclip } from 'lucide-react';

export interface TicketFormData {
  level: string;
  semester: string;
  subject: string;
  doctor: string;
  ticketSubject: string;
  description: string;
}

interface NewTicketFormProps {
  onSubmit: (data: TicketFormData) => void;
  isSubmitting?: boolean;
}

// Mock data structure - Replace with API calls
// TODO: Fetch this from API: GET /api/levels
const levelsData = [
  { id: '1', name: 'Level 1' },
  { id: '2', name: 'Level 2' },
  { id: '3', name: 'Level 3' },
  { id: '4', name: 'Level 4' },
];

// TODO: Fetch this from API: GET /api/semesters
const semestersData = [
  { id: '1', name: 'Semester 1' },
  { id: '2', name: 'Semester 2' },
];

// Mock subjects per level - Replace with API call
// TODO: Fetch based on level: GET /api/subjects?levelId={levelId}&semesterId={semesterId}
const subjectsData: Record<string, { id: string; name: string }[]> = {
  '1': [
    { id: 's1', name: '01 - Introduction to Programming' },
    { id: 's2', name: '02 - Mathematics I' },
    { id: 's3', name: '03 - Physics I' },
  ],
  '2': [
    { id: 's4', name: '01 - Data Structures' },
    { id: 's5', name: '02 - Database Systems' },
    { id: 's6', name: '03 - Web Development' },
  ],
  '3': [
    { id: 's7', name: '01 - Section Internet Application' },
    { id: 's8', name: '02 - Internet Application' },
    { id: 's9', name: '05 - Section Information System' },
  ],
  '4': [
    { id: 's10', name: '01 - Machine Learning' },
    { id: 's11', name: '02 - Cloud Computing' },
    { id: 's12', name: '03 - Cyber Security' },
  ],
};

// Mock doctors per subject - Replace with API call
// TODO: Fetch based on subject: GET /api/doctors?subjectId={subjectId}
const doctorsData: Record<string, { id: string; name: string }[]> = {
  's1': [
    { id: 'd1', name: 'Dr. Ahmed Mohamed' },
    { id: 'd2', name: 'Dr. Sarah Ali' },
  ],
  's2': [
    { id: 'd3', name: 'Dr. John Snow' },
    { id: 'd4', name: 'Dr. Mohamed Ahmed' },
  ],
  's3': [
    { id: 'd5', name: 'Dr. Fatima Hassan' },
  ],
  's4': [
    { id: 'd6', name: 'Dr. Omar Khalil' },
    { id: 'd7', name: 'Dr. Layla Ibrahim' },
  ],
  's5': [
    { id: 'd8', name: 'Dr. Youssef Mahmoud' },
  ],
  's6': [
    { id: 'd9', name: 'Dr. Mona Saeed' },
    { id: 'd10', name: 'Dr. Khaled Nasser' },
  ],
  's7': [
    { id: 'd11', name: 'Dr. Amira Fouad' },
    { id: 'd12', name: 'Dr. Hani Salem' },
  ],
  's8': [
    { id: 'd13', name: 'Dr. Dina Kamal' },
  ],
  's9': [
    { id: 'd14', name: 'Dr. Tarek Zaki' },
    { id: 'd15', name: 'Dr. Nour El-Din' },
  ],
  's10': [
    { id: 'd16', name: 'Dr. Aya Mostafa' },
  ],
  's11': [
    { id: 'd17', name: 'Dr. Hassan Ali' },
    { id: 'd18', name: 'Dr. Rana Adel' },
  ],
  's12': [
    { id: 'd19', name: 'Dr. Karim Youssef' },
  ],
};

export function NewTicketForm({ onSubmit, isSubmitting }: NewTicketFormProps) {
  const [formData, setFormData] = useState<TicketFormData>({
    level: '',
    semester: '',
    subject: '',
    doctor: '',
    ticketSubject: '',
    description: '',
  });

  const [errors, setErrors] = useState<Partial<Record<keyof TicketFormData, string>>>({});

  // Get available subjects based on selected level
  const availableSubjects = formData.level ? subjectsData[formData.level] || [] : [];

  // Get available doctors based on selected subject
  const availableDoctors = formData.subject ? doctorsData[formData.subject] || [] : [];

  const handleChange = (field: keyof TicketFormData, value: string) => {
    setFormData((prev) => {
      const newData = { ...prev, [field]: value };

      // Reset dependent fields when parent changes
      if (field === 'level') {
        newData.subject = '';
        newData.doctor = '';
      } else if (field === 'subject') {
        newData.doctor = '';
      }

      return newData;
    });

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  const validate = () => {
    const newErrors: Partial<Record<keyof TicketFormData, string>> = {};

    if (!formData.level) newErrors.level = 'Level is required';
    if (!formData.semester) newErrors.semester = 'Semester is required';
    if (!formData.subject) newErrors.subject = 'Subject is required';
    if (!formData.doctor) newErrors.doctor = 'Doctor is required';
    if (!formData.ticketSubject) newErrors.ticketSubject = 'Ticket subject is required';
    if (!formData.description) newErrors.description = 'Description is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(formData);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 lg:p-6">
      {/* Header */}
      <div className="mb-6 lg:mb-8">
        <h2 className="font-['Montserrat'] font-semibold text-lg lg:text-xl text-[#2e2a40] mb-1">
          Create Quick Ticket
        </h2>
        <p className="font-['Montserrat'] font-medium text-sm lg:text-base text-[#84818a]">
          Write and address new queries and issues
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5 lg:space-y-6">
        {/* Row 1: Level, Semester, Subject */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
          {/* Level */}
          <div>
            <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
              Choose Level <span className="text-red-600">*</span>
            </label>
            <div className="relative">
              <select
                value={formData.level}
                onChange={(e) => handleChange('level', e.target.value)}
                className={`w-full px-4 py-3 border rounded-lg font-['Montserrat'] text-sm appearance-none bg-white pr-10 ${
                  errors.level ? 'border-red-500' : 'border-[#e7e7e7]'
                } focus:outline-none focus:border-[#7f56d8]`}
              >
                <option value="">Select Level</option>
                {levelsData.map((level) => (
                  <option key={level.id} value={level.id}>
                    {level.name}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#bababa] pointer-events-none" />
            </div>
            {errors.level && <p className="text-red-500 text-xs mt-1">{errors.level}</p>}
          </div>

          {/* Semester */}
          <div>
            <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
              Choose Semester <span className="text-red-600">*</span>
            </label>
            <div className="relative">
              <select
                value={formData.semester}
                onChange={(e) => handleChange('semester', e.target.value)}
                className={`w-full px-4 py-3 border rounded-lg font-['Montserrat'] text-sm appearance-none bg-white pr-10 ${
                  errors.semester ? 'border-red-500' : 'border-[#e7e7e7]'
                } focus:outline-none focus:border-[#7f56d8]`}
              >
                <option value="">Select Semester</option>
                {semestersData.map((semester) => (
                  <option key={semester.id} value={semester.id}>
                    {semester.name}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#bababa] pointer-events-none" />
            </div>
            {errors.semester && <p className="text-red-500 text-xs mt-1">{errors.semester}</p>}
          </div>

          {/* Subject */}
          <div className="md:col-span-2 lg:col-span-1">
            <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
              Choose Subject <span className="text-red-600">*</span>
            </label>
            <div className="relative">
              <select
                value={formData.subject}
                onChange={(e) => handleChange('subject', e.target.value)}
                disabled={!formData.level}
                className={`w-full px-4 py-3 border rounded-lg font-['Montserrat'] text-sm appearance-none bg-white pr-10 ${
                  errors.subject ? 'border-red-500' : 'border-[#e7e7e7]'
                } focus:outline-none focus:border-[#7f56d8] disabled:bg-gray-50 disabled:cursor-not-allowed`}
              >
                <option value="">
                  {formData.level ? 'Select Subject' : 'Select Level first'}
                </option>
                {availableSubjects.map((subject) => (
                  <option key={subject.id} value={subject.id}>
                    {subject.name}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#bababa] pointer-events-none" />
            </div>
            {errors.subject && <p className="text-red-500 text-xs mt-1">{errors.subject}</p>}
            {formData.level && availableSubjects.length === 0 && (
              <p className="text-amber-600 text-xs mt-1">No subjects available for this level</p>
            )}
          </div>
        </div>

        {/* Row 2: Doctor and Ticket Subject */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:gap-6">
          {/* Doctor */}
          <div>
            <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
              Select Doctor <span className="text-red-600">*</span>
            </label>
            <div className="relative">
              <select
                value={formData.doctor}
                onChange={(e) => handleChange('doctor', e.target.value)}
                disabled={!formData.subject}
                className={`w-full px-4 py-3 border rounded-lg font-['Montserrat'] text-sm appearance-none bg-white pr-10 ${
                  errors.doctor ? 'border-red-500' : 'border-[#e7e7e7]'
                } focus:outline-none focus:border-[#7f56d8] disabled:bg-gray-50 disabled:cursor-not-allowed`}
              >
                <option value="">
                  {formData.subject ? 'Choose Doctor' : 'Select Subject first'}
                </option>
                {availableDoctors.map((doctor) => (
                  <option key={doctor.id} value={doctor.id}>
                    {doctor.name}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#bababa] pointer-events-none" />
            </div>
            {errors.doctor && <p className="text-red-500 text-xs mt-1">{errors.doctor}</p>}
            {formData.subject && availableDoctors.length === 0 && (
              <p className="text-amber-600 text-xs mt-1">No doctors available for this subject</p>
            )}
          </div>

          {/* Ticket Subject */}
          <div>
            <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
              Request Ticket Subject
            </label>
            <input
              type="text"
              value={formData.ticketSubject}
              onChange={(e) => handleChange('ticketSubject', e.target.value)}
              placeholder="Enter Ticket Subject"
              className={`w-full px-4 py-3 border rounded-lg font-['Montserrat'] text-sm ${
                errors.ticketSubject ? 'border-red-500' : 'border-[#e7e7e7]'
              } focus:outline-none focus:border-[#7f56d8]`}
            />
            {errors.ticketSubject && (
              <p className="text-red-500 text-xs mt-1">{errors.ticketSubject}</p>
            )}
          </div>
        </div>

        {/* Ticket Body */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40]">
              Ticket Body
            </label>
            <button
              type="button"
              className="text-gray-400 hover:text-gray-600 transition-colors"
              title="Attach file"
            >
              <Paperclip className="w-5 h-5" />
            </button>
          </div>
          <textarea
            value={formData.description}
            onChange={(e) => handleChange('description', e.target.value)}
            placeholder="Type ticket issue here.."
            rows={6}
            className={`w-full px-4 py-3 border rounded-lg font-['Montserrat'] text-sm resize-none ${
              errors.description ? 'border-red-500' : 'border-[#e7e7e7]'
            } focus:outline-none focus:border-[#7f56d8]`}
          />
          {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description}</p>}
        </div>

        {/* Submit Button */}
        <div className="flex justify-end pt-4">
          <button
            type="submit"
            disabled={isSubmitting}
            className="bg-[#7f56d8] text-white px-8 py-3 rounded-lg font-['Montserrat'] font-semibold text-sm hover:bg-[#6d47c4] transition-colors disabled:opacity-50 disabled:cursor-not-allowed min-w-[160px]"
          >
            {isSubmitting ? (
              <span className="flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Sending...
              </span>
            ) : (
              'Send Ticket'
            )}
          </button>
        </div>
      </form>
    </div>
  );
}