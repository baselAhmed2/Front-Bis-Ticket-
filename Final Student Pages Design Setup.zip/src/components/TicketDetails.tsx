import { useState } from 'react';
import { ArrowLeft, ChevronDown, Send } from 'lucide-react';
import { Ticket } from './TicketList';

export interface TicketReply {
  id: string;
  message: string;
  sender: {
    name: string;
    type: 'student' | 'admin';
  };
  createdAt: string;
}

export interface StudentBasicData {
  id: string;
  name: string;
  semester: string;
  subject?: string;
}

export interface TicketDetailsData extends Ticket {
  category: string;
  groupNumber?: string;
  replies: TicketReply[];
  student: StudentBasicData;
}

interface TicketDetailsProps {
  ticket: TicketDetailsData;
  onBack: () => void;
  onReply: (message: string) => void;
  isSubmittingReply?: boolean;
}

const statusConfig = {
  'not-replayed': { label: 'Not Replayed', color: 'bg-blue-500' },
  'on-going': { label: 'On-Going', color: 'bg-orange-500' },
  resolved: { label: 'Resolved', color: 'bg-green-500' },
};

export function TicketDetails({ ticket, onBack, onReply, isSubmittingReply }: TicketDetailsProps) {
  const [replyMessage, setReplyMessage] = useState('');

  const handleSubmitReply = () => {
    if (replyMessage.trim()) {
      onReply(replyMessage);
      setReplyMessage('');
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#f9f9fb]">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4 lg:p-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-[#7f56d8] hover:text-[#6d47c4] font-['Montserrat'] font-medium mb-4 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Tickets</span>
        </button>

        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className={`w-4 h-4 rounded-full ${statusConfig[ticket.status].color} flex-shrink-0`} />
            <h1 className="font-['Montserrat'] font-semibold text-xl lg:text-2xl text-[#2e2c34]">
              Ticket# {ticket.ticketNumber}
            </h1>
          </div>
          <span className="text-xs lg:text-sm text-gray-500 font-['Montserrat'] whitespace-nowrap">
            Posted at {ticket.createdAt}
          </span>
        </div>

        {ticket.category && (
          <p className="text-sm text-gray-600 font-['Montserrat'] mt-2">{ticket.category}</p>
        )}
      </div>

      {/* Content - Scrollable */}
      <div className="flex-1 overflow-auto p-4 lg:p-6 space-y-6">
        {/* Ticket Content */}
        <div className="bg-white rounded-lg p-4 lg:p-6 border border-gray-200">
          <h2 className="font-['Montserrat'] font-semibold text-lg text-[#2e2c34] mb-4">
            {ticket.subject}
          </h2>
          <p className="text-sm lg:text-base text-gray-700 font-['Montserrat'] whitespace-pre-wrap leading-relaxed">
            {ticket.description}
          </p>
        </div>

        {/* Ticket Sender Information */}
        <div className="bg-white rounded-lg p-4 lg:p-6 border border-gray-200">
          <h3 className="font-['Montserrat'] font-semibold text-lg text-[#2e2a40] mb-4">
            Ticket Sender Information
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Student ID */}
            <div>
              <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
                Student ID
              </label>
              <div className="bg-gray-50 border border-gray-200 rounded px-4 py-3 font-['Montserrat'] text-sm text-gray-700">
                {ticket.student.id}
              </div>
            </div>

            {/* Student Name */}
            <div>
              <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
                Student Name
              </label>
              <div className="bg-gray-50 border border-gray-200 rounded px-4 py-3 font-['Montserrat'] text-sm text-gray-700">
                {ticket.student.name}
              </div>
            </div>

            {/* Course */}
            <div>
              <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
                Course
              </label>
              <div className="bg-gray-50 border border-gray-200 rounded px-4 py-3 font-['Montserrat'] text-sm text-gray-700 flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-orange-500 opacity-60" />
                <span>{ticket.student.subject || 'N/A'}</span>
              </div>
            </div>

            {/* Group Number */}
            {ticket.groupNumber && (
              <div>
                <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
                  Group Number
                </label>
                <div className="bg-gray-50 border border-gray-200 rounded px-4 py-3 font-['Montserrat'] text-sm text-gray-700 text-center">
                  {ticket.groupNumber}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Replies */}
        {ticket.replies.length > 0 && (
          <div className="bg-white rounded-lg p-4 lg:p-6 border border-gray-200">
            <h3 className="font-['Montserrat'] font-semibold text-lg text-[#2e2a40] mb-4">
              Last Replays On Ticket
            </h3>

            <div className="space-y-4">
              {ticket.replies.map((reply) => (
                <div
                  key={reply.id}
                  className={`border border-gray-200 rounded-lg p-4 ${
                    reply.sender.type === 'admin' ? 'bg-[#f3f0fb]' : 'bg-white'
                  }`}
                >
                  <p className="text-xs text-gray-500 font-['Montserrat'] font-light mb-2">
                    {reply.sender.name} on {reply.createdAt}
                  </p>
                  <p className={`text-sm lg:text-base font-['Montserrat'] ${
                    reply.sender.type === 'admin' ? 'font-semibold text-[#2e2c34]' : 'font-medium text-gray-700'
                  }`}>
                    {reply.message}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Reply Form */}
        <div className="bg-white rounded-lg p-4 lg:p-6 border border-gray-200">
          <h3 className="font-['Montserrat'] font-semibold text-lg text-[#2e2a40] mb-4">
            Reply to Ticket
          </h3>

          <div className="space-y-4">
            {/* Token ID (read-only) */}
            <div>
              <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
                Token ID
              </label>
              <div className="bg-gray-50 border border-gray-200 rounded px-4 py-3 font-['Montserrat'] text-sm text-gray-500">
                {ticket.id}
              </div>
            </div>

            {/* Status (for admin - would be editable) */}
            <div>
              <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
                Status
              </label>
              <div className="relative">
                <div className="bg-gray-50 border border-gray-200 rounded px-4 py-3 font-['Montserrat'] text-sm text-gray-700 flex items-center gap-2">
                  <span className={`w-3 h-3 rounded-full ${statusConfig[ticket.status].color}`} />
                  <span>{statusConfig[ticket.status].label}</span>
                </div>
              </div>
            </div>

            {/* Reply Message */}
            <div>
              <label className="block font-['Montserrat'] font-medium text-sm text-[#2e2a40] mb-2">
                Ticket Body
              </label>
              <textarea
                value={replyMessage}
                onChange={(e) => setReplyMessage(e.target.value)}
                placeholder="Type your reply here.."
                rows={5}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg font-['Montserrat'] text-sm resize-none focus:outline-none focus:border-[#7f56d8]"
              />
            </div>

            {/* Submit Button */}
            <div className="flex justify-end">
              <button
                onClick={handleSubmitReply}
                disabled={!replyMessage.trim() || isSubmittingReply}
                className="bg-[#7f56d8] text-white px-8 py-3 rounded-lg font-['Montserrat'] font-semibold text-sm hover:bg-[#6d47c4] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {isSubmittingReply ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Submit Reply
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}