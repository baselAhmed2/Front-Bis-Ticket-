import { LayoutDashboard, Ticket, LogOut, X } from 'lucide-react';
import { useState } from 'react';

interface SidebarProps {
  currentPage: 'dashboard' | 'new-ticket';
  onNavigate: (page: 'dashboard' | 'new-ticket') => void;
  onLogout: () => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export function Sidebar({ currentPage, onNavigate, onLogout, isOpen = true, onClose }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'new-ticket' as const, label: 'New Ticket', icon: Ticket },
  ];

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed lg:sticky top-0 left-0 h-screen bg-white border-r border-[#e7e7e7] z-50
          w-[280px] lg:w-[249px] transition-transform duration-300
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        <div className="flex flex-col h-full p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <h1 className="font-['Montserrat'] font-semibold text-2xl text-[#2e2c34] uppercase">
              TICKET LEAD
            </h1>
            {onClose && (
              <button
                onClick={onClose}
                className="lg:hidden text-gray-500 hover:text-gray-700"
              >
                <X className="w-6 h-6" />
              </button>
            )}
          </div>

          {/* Navigation */}
          <nav className="flex-1 space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.id);
                    onClose?.();
                  }}
                  className={`
                    w-full flex items-center gap-3 px-4 py-3 rounded-lg
                    font-['Montserrat'] font-medium text-base
                    transition-colors
                    ${
                      isActive
                        ? 'bg-[rgba(127,86,216,0.1)] text-[#7f56d8]'
                        : 'text-[#2e2c34] hover:bg-gray-50'
                    }
                  `}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Logout */}
          <button
            onClick={onLogout}
            className="flex items-center gap-3 px-4 py-3 rounded-lg text-[#2e2c34] hover:bg-gray-50 font-['Montserrat'] font-medium text-base transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
}
