import { CheckCircle2, XCircle, AlertTriangle, Info, X } from 'lucide-react';

type AlertType = 'success' | 'error' | 'warning' | 'info';

interface AlertProps {
  type: AlertType;
  title: string;
  message: string;
  onClose?: () => void;
}

const alertStyles = {
  success: {
    container: 'bg-[#e6faf5] border-[#00CC99]',
    accent: 'bg-[#00CC99]',
    icon: CheckCircle2,
    iconColor: 'text-[#00CC99]',
  },
  error: {
    container: 'bg-[#fdeeee] border-[#EB5757]',
    accent: 'bg-[#EB5757]',
    icon: XCircle,
    iconColor: 'text-[#EB5757]',
  },
  warning: {
    container: 'bg-[#fdf8e8] border-[#F2C94C]',
    accent: 'bg-[#F2C94C]',
    icon: AlertTriangle,
    iconColor: 'text-[#F2C94C]',
  },
  info: {
    container: 'bg-[#eeeefe] border-[#5458F7]',
    accent: 'bg-[#5458F7]',
    icon: Info,
    iconColor: 'text-[#5458F7]',
  },
};

export function Alert({ type, title, message, onClose }: AlertProps) {
  const style = alertStyles[type];
  const Icon = style.icon;

  return (
    <div className={`relative w-full rounded-lg border ${style.container} overflow-hidden`}>
      {/* Accent bar */}
      <div className={`absolute left-0 top-0 bottom-0 w-2 ${style.accent}`} />
      
      {/* Content */}
      <div className="flex items-start gap-4 p-4 pl-6">
        <Icon className={`w-6 h-6 flex-shrink-0 ${style.iconColor}`} />
        
        <div className="flex-1 min-w-0">
          <h4 className="font-['Poppins'] font-semibold text-lg md:text-xl text-[#2f3032] mb-1">
            {title}
          </h4>
          <p className="font-['Poppins'] text-sm md:text-base text-[#2f3032]">
            {message}
          </p>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="flex-shrink-0 text-gray-400 hover:text-gray-600 transition-colors"
            aria-label="Close alert"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
}
