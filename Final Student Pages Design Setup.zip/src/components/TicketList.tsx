import { Search, Plus, Inbox } from 'lucide-react';
import { useState } from 'react';

export interface Ticket {
  id: string;
  ticketNumber: string;
  subject: string;
  description: string;
  status: 'not-replayed' | 'on-going' | 'resolved';
  assignedTo: {
    name: string;
    avatar?: string;
  };
  createdAt: string;
  isReply?: boolean;
}

interface TicketListProps {
  tickets: Ticket[];
  isLoading?: boolean;
  onTicketClick: (ticket: Ticket) => void;
  onNewTicket: () => void;
}

const statusConfig = {
  'not-replayed': {
    label: 'Not Replayed',
    color: 'bg-blue-500',
    textColor: 'text-blue-600',
  },
  'on-going': {
    label: 'On-Going Tickets',
    color: 'bg-orange-500',
    textColor: 'text-orange-600',
  },
  resolved: {
    label: 'Resolved Tickets',
    color: 'bg-green-500',
    textColor: 'text-green-600',
  },
};

export function TicketList({ tickets, isLoading, onTicketClick, onNewTicket }: TicketListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<'all' | Ticket['status']>('all');
  const [timeFilter, setTimeFilter] = useState('This Week');

  // Filter tickets
  const filteredTickets = tickets.filter((ticket) => {
    const matchesSearch = ticket.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || ticket.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="flex flex-col h-full">
      {/* Header Section */}
      <div className="bg-white border-b border-gray-200 p-4 lg:p-6">
        <h1 className="font-['Montserrat'] font-semibold text-2xl lg:text-3xl text-[#2e2c34] mb-4 lg:mb-6">
          Tickets
        </h1>

        {/* Filters and Actions */}
        <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
          {/* Search */}
          <div className="relative w-full lg:w-auto lg:min-w-[320px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search for ticket"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg font-['Montserrat'] text-sm focus:outline-none focus:border-[#7f56d8]"
            />
          </div>

          {/* Right side filters */}
          <div className="flex items-center gap-3 w-full lg:w-auto">
            {/* Status filter */}
            <div className="flex items-center gap-2 flex-wrap flex-1 lg:flex-none">
              {Object.entries(statusConfig).map(([status, config]) => (
                <button
                  key={status}
                  onClick={() => setSelectedStatus(selectedStatus === status ? 'all' : status as Ticket['status'])}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs lg:text-sm font-['Montserrat'] transition-colors ${
                    selectedStatus === status
                      ? 'bg-gray-100'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${config.color}`} />
                  <span>{config.label}</span>
                </button>
              ))}
            </div>

            {/* Time filter (desktop) */}
            <select
              value={timeFilter}
              onChange={(e) => setTimeFilter(e.target.value)}
              className="hidden lg:block px-4 py-2 border border-gray-200 rounded-lg font-['Montserrat'] text-sm focus:outline-none focus:border-[#7f56d8]"
            >
              <option>This Week</option>
              <option>This Month</option>
              <option>All Time</option>
            </select>

            {/* New Ticket Button */}
            <button
              onClick={onNewTicket}
              className="bg-[#7f56d8] text-white px-4 py-2.5 rounded-lg font-['Montserrat'] font-semibold text-sm flex items-center gap-2 hover:bg-[#6d47c4] transition-colors whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">New Ticket</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tickets List */}
      <div className="flex-1 overflow-auto bg-[#f9f9fb] p-4 lg:p-6">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-64">
            <div className="w-12 h-12 border-4 border-[#7f56d8] border-t-transparent rounded-full animate-spin" />
            <p className="mt-4 text-gray-500 font-['Montserrat']">Loading tickets...</p>
          </div>
        ) : filteredTickets.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-gray-400">
            <Inbox className="w-16 h-16 mb-4" />
            <p className="font-['Montserrat'] text-lg">
              {searchQuery ? 'No tickets found' : 'No tickets yet'}
            </p>
            <p className="font-['Montserrat'] text-sm mt-2">
              {searchQuery ? 'Try adjusting your search' : 'Create a new ticket to get started'}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredTickets.map((ticket) => (
              <button
                key={ticket.id}
                onClick={() => onTicketClick(ticket)}
                className="w-full bg-white rounded-lg p-4 lg:p-6 border border-gray-200 hover:border-[#7f56d8] hover:shadow-md transition-all text-left"
              >
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div className="flex items-center gap-3">
                    <span className={`w-3 h-3 rounded-full ${statusConfig[ticket.status].color} flex-shrink-0`} />
                    <h3 className="font-['Montserrat'] font-semibold text-base lg:text-lg text-[#2e2c34]">
                      {ticket.isReply ? 'Replay-' : ''}Ticket# {ticket.ticketNumber}
                    </h3>
                  </div>
                  <span className="text-xs lg:text-sm text-gray-500 font-['Montserrat'] whitespace-nowrap">
                    Posted at {ticket.createdAt}
                  </span>
                </div>

                <h4 className="font-['Montserrat'] font-medium text-sm lg:text-base text-[#2e2c34] mb-2">
                  {ticket.subject}
                </h4>

                <p className="text-xs lg:text-sm text-gray-600 font-['Montserrat'] mb-4 line-clamp-2">
                  {ticket.description}
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 lg:w-8 lg:h-8 rounded-full bg-gray-200 flex items-center justify-center">
                      {ticket.assignedTo.avatar ? (
                        <img
                          src={ticket.assignedTo.avatar}
                          alt={ticket.assignedTo.name}
                          className="w-full h-full rounded-full object-cover"
                        />
                      ) : (
                        <span className="text-xs lg:text-sm font-semibold text-gray-600">
                          {ticket.assignedTo.name.charAt(0)}
                        </span>
                      )}
                    </div>
                    <span className="text-xs lg:text-sm text-gray-700 font-['Montserrat']">
                      {ticket.assignedTo.name}
                    </span>
                  </div>

                  <span className="text-[#7f56d8] text-xs lg:text-sm font-['Montserrat'] font-semibold">
                    Open Ticket →
                  </span>
                </div>
              </button>
            ))}
          </div>
        )}

        {/* Pagination (if needed) */}
        {!isLoading && filteredTickets.length > 0 && (
          <div className="flex items-center justify-center gap-2 mt-6">
            <button className="px-3 py-1.5 border border-gray-200 rounded text-sm font-['Montserrat'] hover:bg-gray-50">
              Previous
            </button>
            <button className="px-3 py-1.5 bg-[#7f56d8] text-white rounded text-sm font-['Montserrat']">
              1
            </button>
            <button className="px-3 py-1.5 border border-gray-200 rounded text-sm font-['Montserrat'] hover:bg-gray-50">
              2
            </button>
            <button className="px-3 py-1.5 border border-gray-200 rounded text-sm font-['Montserrat'] hover:bg-gray-50">
              Next
            </button>
          </div>
        )}
      </div>
    </div>
  );
}