import { Menu, ChevronDown } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface TopBarProps {
  userName: string;
  userImage?: string;
  onMenuClick?: () => void;
}

export function TopBar({ userName, userImage, onMenuClick }: TopBarProps) {
  return (
    <header className="sticky top-0 z-30 bg-white border-b border-[#e7e7e7] shadow-sm">
      <div className="flex items-center justify-between h-16 lg:h-[85px] px-4 lg:px-6">
        {/* Left side - Menu and Welcome */}
        <div className="flex items-center gap-4">
          <button
            onClick={onMenuClick}
            className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
            aria-label="Toggle menu"
          >
            <Menu className="w-6 h-6 text-[#2e2c34]" />
          </button>

          <p className="font-['Montserrat'] text-base lg:text-lg text-[#2e2c34]">
            <span className="font-medium">Welcome! </span>
            <span className="font-semibold">{userName}</span>
          </p>
        </div>

        {/* Right side - User profile */}
        <div className="flex items-center gap-3 bg-[#fafafa] rounded-full px-3 py-2">
          <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-full overflow-hidden bg-gray-200">
            {userImage ? (
              <ImageWithFallback
                src={userImage}
                alt={userName}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-[#7f56d8] text-white font-semibold text-lg">
                {userName.charAt(0).toUpperCase()}
              </div>
            )}
          </div>
          <span className="hidden md:block font-['Montserrat'] font-semibold text-sm lg:text-base text-[#1a202c]">
            {userName}
          </span>
          <ChevronDown className="w-4 h-4 text-[#0c0407]" />
        </div>
      </div>
    </header>
  );
}