import svgPaths from "./svg-mngts7bxyi";
import imgImageAlexRobert from "figma:asset/de594936ad0a19f927b491e86d6ede3a55fdfe1d.png";

function Heading1() {
  return (
    <div className="h-[31.977px] relative shrink-0 w-full" data-name="Heading 2">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[32px] left-0 text-[#2e2c34] text-[24px] top-[-0.82px]">New Ticket</p>
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[27.994px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[28px] left-0 text-[#2e2a40] text-[18px] top-[-0.64px]">Create Quick Ticket</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[39.981px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#84818a] text-[14px] top-[0.18px] w-[248px] whitespace-pre-wrap">Write and address new queries and issues</p>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex flex-col gap-[3.983px] h-[71.958px] items-start relative shrink-0 w-full" data-name="Container">
      <Heading2 />
      <Paragraph />
    </div>
  );
}

function Label() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[0] left-0 text-[#2e2a40] text-[14px] top-[0.18px] w-[103px] whitespace-pre-wrap">
        <span className="leading-[20px]">{`Choose Level `}</span>
        <span className="leading-[20px] text-[#e7000b]">*</span>
      </p>
    </div>
  );
}

function Option() {
  return <div className="absolute left-[-41.16px] size-0 top-[-127.76px]" data-name="Option" />;
}

function Option1() {
  return <div className="absolute left-[-41.16px] size-0 top-[-127.76px]" data-name="Option" />;
}

function Option2() {
  return <div className="absolute left-[-41.16px] size-0 top-[-127.76px]" data-name="Option" />;
}

function Option3() {
  return <div className="absolute left-[-41.16px] size-0 top-[-127.76px]" data-name="Option" />;
}

function Dropdown() {
  return (
    <div className="absolute bg-white border-[#e7e7e7] border-[1.18px] border-solid h-[46.325px] left-0 rounded-[4px] top-0 w-[290.636px]" data-name="Dropdown">
      <Option />
      <Option1 />
      <Option2 />
      <Option3 />
    </div>
  );
}

function Icon() {
  return (
    <div className="relative size-[15.989px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9887 15.9887">
        <g id="Icon">
          <path d={svgPaths.p2f805800} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.49894" />
        </g>
      </svg>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[46.325px] relative shrink-0 w-full" data-name="Container">
      <Dropdown />
      <div className="absolute flex items-center justify-center left-[252.02px] size-[15.989px] top-[15.18px]">
        <div className="flex-none rotate-180">
          <Icon />
        </div>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex flex-col gap-[7.985px] h-[74.3px] items-start relative shrink-0 w-full" data-name="Container">
      <Label />
      <Container4 />
    </div>
  );
}

function Label1() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[0] left-0 text-[#2e2a40] text-[14px] top-[0.18px] w-[134px] whitespace-pre-wrap">
        <span className="leading-[20px]">{`Choose Semester `}</span>
        <span className="leading-[20px] text-[#e7000b]">*</span>
      </p>
    </div>
  );
}

function Option4() {
  return <div className="absolute left-[-41.16px] size-0 top-[-222.05px]" data-name="Option" />;
}

function Option5() {
  return <div className="absolute left-[-41.16px] size-0 top-[-222.05px]" data-name="Option" />;
}

function Option6() {
  return <div className="absolute left-[-41.16px] size-0 top-[-222.05px]" data-name="Option" />;
}

function Dropdown1() {
  return (
    <div className="absolute bg-white border-[#e7e7e7] border-[1.18px] border-solid h-[46.325px] left-0 rounded-[4px] top-0 w-[290.636px]" data-name="Dropdown">
      <Option4 />
      <Option5 />
      <Option6 />
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative size-[15.989px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9887 15.9887">
        <g id="Icon">
          <path d={svgPaths.p2f805800} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.49894" />
        </g>
      </svg>
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[46.325px] relative shrink-0 w-full" data-name="Container">
      <Dropdown1 />
      <div className="absolute flex items-center justify-center left-[252.02px] size-[15.989px] top-[14.89px]">
        <div className="flex-none rotate-180">
          <Icon1 />
        </div>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="content-stretch flex flex-col gap-[7.985px] h-[74.3px] items-start relative shrink-0 w-full" data-name="Container">
      <Label1 />
      <Container6 />
    </div>
  );
}

function Label2() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[0] left-0 text-[#2e2a40] text-[14px] top-[0.18px] w-[121px] whitespace-pre-wrap">
        <span className="leading-[20px]">{`Choose Course `}</span>
        <span className="leading-[20px] text-[#e7000b]">*</span>
      </p>
    </div>
  );
}

function Option7() {
  return <div className="absolute left-[-41.16px] size-0 top-[-316.34px]" data-name="Option" />;
}

function Option8() {
  return <div className="absolute left-[-41.16px] size-0 top-[-316.34px]" data-name="Option" />;
}

function Option9() {
  return <div className="absolute left-[-41.16px] size-0 top-[-316.34px]" data-name="Option" />;
}

function Option10() {
  return <div className="absolute left-[-41.16px] size-0 top-[-316.34px]" data-name="Option" />;
}

function Dropdown2() {
  return (
    <div className="absolute bg-white border-[#e7e7e7] border-[1.18px] border-solid h-[46.325px] left-0 rounded-[4px] top-0 w-[290.636px]" data-name="Dropdown">
      <Option7 />
      <Option8 />
      <Option9 />
      <Option10 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative size-[15.989px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9887 15.9887">
        <g id="Icon">
          <path d={svgPaths.p2f805800} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.49894" />
        </g>
      </svg>
    </div>
  );
}

function Container8() {
  return (
    <div className="h-[46.325px] relative shrink-0 w-full" data-name="Container">
      <Dropdown2 />
      <div className="absolute flex items-center justify-center left-[249.02px] size-[15.989px] top-[15.6px]">
        <div className="flex-none rotate-180">
          <Icon2 />
        </div>
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="content-stretch flex flex-col gap-[7.985px] h-[74.3px] items-start relative shrink-0 w-full" data-name="Container">
      <Label2 />
      <Container8 />
    </div>
  );
}

function Label3() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[0] left-0 text-[#2e2a40] text-[14px] top-[0.18px] w-[106px] whitespace-pre-wrap">
        <span className="leading-[20px]">{`Select Doctor `}</span>
        <span className="leading-[20px] text-[#e7000b]">*</span>
      </p>
    </div>
  );
}

function Dropdown3() {
  return (
    <div className="absolute h-[46.325px] left-0 top-0 w-[290.636px]" data-name="Dropdown">
      <div className="absolute inset-[-883.88%_0_0_-13.76%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 330.617 455.778">
          <g id="Dropdown">
            <mask fill="white" id="path-1-inside-1_1_1838">
              <path d={svgPaths.pead6200} />
            </mask>
            <path d={svgPaths.pead6200} fill="var(--fill-0, white)" />
            <path d={svgPaths.p35c8b500} fill="var(--stroke-0, #E7E7E7)" mask="url(#path-1-inside-1_1_1838)" />
            <g id="Option" />
            <g id="Option_2" />
            <g id="Option_3" />
            <g id="Option_4" />
            <path d={svgPaths.p1c825500} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.49894" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Icon3() {
  return <div className="size-[15.989px]" data-name="Icon" />;
}

function Container10() {
  return (
    <div className="h-[46.325px] relative shrink-0 w-full" data-name="Container">
      <Dropdown3 />
      <div className="absolute flex items-center justify-center left-[238.67px] size-[15.989px] top-[-0.82px]">
        <div className="flex-none rotate-180">
          <Icon3 />
        </div>
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="content-stretch flex flex-col gap-[7.985px] h-[74.3px] items-start relative shrink-0 w-full" data-name="Container">
      <Label3 />
      <Container10 />
    </div>
  );
}

function Label4() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#2e2a40] text-[14px] top-[0.18px]">{`Request Ticket subject `}</p>
    </div>
  );
}

function Option11() {
  return <div className="absolute left-[-41.16px] size-0 top-[-504.92px]" data-name="Option" />;
}

function Option12() {
  return <div className="absolute left-[-41.16px] size-0 top-[-504.92px]" data-name="Option" />;
}

function Option13() {
  return <div className="absolute left-[-41.16px] size-0 top-[-504.92px]" data-name="Option" />;
}

function Option14() {
  return <div className="absolute left-[-41.16px] size-0 top-[-504.92px]" data-name="Option" />;
}

function Dropdown4() {
  return (
    <div className="absolute bg-white border-[#e7e7e7] border-[1.18px] border-solid h-[46.325px] left-0 rounded-[4px] top-0 w-[290.636px]" data-name="Dropdown">
      <Option11 />
      <Option12 />
      <Option13 />
      <Option14 />
    </div>
  );
}

function Icon4() {
  return <div className="size-[15.989px]" data-name="Icon" />;
}

function Container12() {
  return (
    <div className="h-[46.325px] relative shrink-0 w-full" data-name="Container">
      <Dropdown4 />
      <div className="absolute flex items-center justify-center left-[238.67px] size-[15.989px] top-[-0.82px]">
        <div className="flex-none rotate-180">
          <Icon4 />
        </div>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="content-stretch flex flex-col gap-[7.985px] h-[74.3px] items-start relative shrink-0 w-full" data-name="Container">
      <Label4 />
      <Container12 />
    </div>
  );
}

function Label5() {
  return (
    <div className="h-[19.99px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] left-0 text-[#2e2a40] text-[14px] top-[0.18px]">Ticket Body</p>
    </div>
  );
}

function TextArea() {
  return (
    <div className="absolute h-[146.277px] left-0 rounded-[4px] top-0 w-[290.636px]" data-name="Text Area">
      <div className="content-stretch flex items-start overflow-clip px-[20px] py-[12px] relative rounded-[inherit] size-full">
        <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[20px] relative shrink-0 text-[#757575] text-[14px]">Type ticket issue here..</p>
      </div>
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-[1.18px] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Container14() {
  return (
    <div className="h-[151.404px] relative shrink-0 w-full" data-name="Container">
      <TextArea />
    </div>
  );
}

function Container13() {
  return (
    <div className="content-stretch flex flex-col gap-[7.985px] h-[179.379px] items-start relative shrink-0 w-full" data-name="Container">
      <Label5 />
      <Container14 />
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#7f56d8] h-[43.964px] relative rounded-[4px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] shrink-0 w-full" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[20px] left-[145.62px] text-[14px] text-center text-white top-[12.17px]">Send Ticket</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex flex-col gap-[19.99px] h-[714.787px] items-start relative shrink-0 w-full" data-name="Container">
      <Container3 />
      <Container5 />
      <Container7 />
      <Container9 />
      <Container11 />
      <Container13 />
      <Button />
    </div>
  );
}

function Container() {
  return (
    <div className="bg-white h-[850.718px] relative rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col gap-[23.992px] items-start pt-[19.99px] px-[19.99px] relative size-full">
        <Container1 />
        <Container2 />
      </div>
    </div>
  );
}

function App() {
  return (
    <div className="bg-[#f9f9fb] h-[1018.608px] relative shrink-0 w-full" data-name="App">
      <div className="content-stretch flex flex-col gap-[23.992px] items-start pt-[91.93px] px-[19.99px] relative size-full">
        <Heading1 />
        <Container />
      </div>
    </div>
  );
}

function Body() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[853.319px] items-start left-0 top-0 w-[370.598px]" data-name="Body">
      <App />
    </div>
  );
}

function Icon5() {
  return (
    <div className="h-[23.992px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/2 left-[16.67%] right-[16.67%] top-1/2" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-3/4 left-[16.67%] right-[16.67%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-1/4 left-[16.67%] right-[16.67%] top-3/4" data-name="Vector">
        <div className="absolute inset-[-1px_-6.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9942 1.99935">
            <path d="M0.999675 0.999675H16.9945" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="relative rounded-[10px] shrink-0 size-[39.962px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[7.985px] px-[7.985px] relative size-full">
        <Icon5 />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="flex-[1_0_0] h-[27.994px] min-h-px min-w-px relative" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[28px] left-0 text-[#2e2c34] text-[18px] top-[-0.64px] uppercase">TICKET LEAD</p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[39.962px] relative shrink-0 w-[173.791px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[11.987px] items-center relative size-full">
        <Button1 />
        <Heading />
      </div>
    </div>
  );
}

function ImageAlexRobert() {
  return (
    <div className="relative rounded-[39602500px] shrink-0 size-[31.996px]" data-name="Image (Alex Robert)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none rounded-[39602500px] size-full" src={imgImageAlexRobert} />
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[15.989px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9887 15.9887">
        <g id="Icon">
          <path d={svgPaths.p299e0698} id="Vector" stroke="var(--stroke-0, #0C0407)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99858" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute bg-[#fafafa] content-stretch flex gap-[7.985px] h-[39.962px] items-center left-[50.31px] pl-[3.983px] rounded-[39602500px] top-0 w-[71.94px]" data-name="Button">
      <ImageAlexRobert />
      <Icon6 />
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[39.962px] relative shrink-0 w-[122.248px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Button2 />
      </div>
    </div>
  );
}

function App1() {
  return (
    <div className="absolute bg-white content-stretch flex h-[71.94px] items-center justify-between left-0 px-[19.99px] shadow-[0px_4px_40px_0px_rgba(0,0,0,0.03)] top-[165.23px] w-[370.598px]" data-name="App">
      <Container15 />
      <Container16 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="h-[28.012px] relative shrink-0 w-[135.341px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[28px] left-0 text-[#2e2c34] text-[20px] top-[-0.82px] uppercase">TICKET LEAD</p>
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="h-[23.992px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-1/4" data-name="Vector">
        <div className="absolute inset-[-8.33%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9955 13.9955">
            <path d={svgPaths.pd734280} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-1/4" data-name="Vector">
        <div className="absolute inset-[-8.33%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9955 13.9955">
            <path d={svgPaths.p1899e800} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.99935" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="relative shrink-0 size-[31.959px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[3.983px] px-[3.983px] relative size-full">
        <Icon7 />
      </div>
    </div>
  );
}

function Container18() {
  return (
    <div className="h-[31.959px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between relative size-full">
          <Heading3 />
          <Button3 />
        </div>
      </div>
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[21.982px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.9821 21.9821">
        <g id="Icon">
          <path clipRule="evenodd" d={svgPaths.pa001a00} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Vector" />
          <path clipRule="evenodd" d={svgPaths.p3ce48200} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Vector_2" />
          <path clipRule="evenodd" d={svgPaths.p23af1d00} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Vector_3" />
          <path clipRule="evenodd" d={svgPaths.p3e0d5f00} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Vector_4" />
        </g>
      </svg>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[24.011px] relative shrink-0 w-[88.574px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-0 text-[#7f56d8] text-[16px] top-[0.36px]">Dashboard</p>
      </div>
    </div>
  );
}

function Link() {
  return (
    <div className="bg-[rgba(127,86,216,0.1)] h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Link">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[11.987px] items-center pl-[15.989px] relative size-full">
          <Icon8 />
          <Text />
        </div>
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[21.982px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.9821 21.9821">
        <g id="Icon">
          <path d={svgPaths.p384e5ff0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.49878" />
          <path d={svgPaths.p34520d00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999186" />
        </g>
      </svg>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[24.011px] relative shrink-0 w-[55.601px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-0 text-[#2e2c34] text-[16px] top-[0.36px]">New Ticket</p>
      </div>
    </div>
  );
}

function Link1() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Link">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[11.987px] items-center pl-[15.989px] relative size-full">
          <Icon9 />
          <Text1 />
        </div>
      </div>
    </div>
  );
}

function Icon10() {
  return (
    <div className="relative shrink-0 size-[21.982px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.9821 21.9821">
        <g id="Icon">
          <path d={svgPaths.p15963000} fill="var(--fill-0, #1E1E1E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[24.011px] relative shrink-0 w-[57.555px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] left-0 text-[#2e2c34] text-[16px] top-[0.36px]">Logout</p>
      </div>
    </div>
  );
}

function Link2() {
  return (
    <div className="h-[47.984px] relative rounded-[10px] shrink-0 w-full" data-name="Link">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[11.987px] items-center pl-[15.989px] relative size-full">
          <Icon10 />
          <Text2 />
        </div>
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="content-stretch flex flex-col gap-[7.985px] h-[215.893px] items-start relative shrink-0 w-full" data-name="Navigation">
      <Link />
      <Link1 />
      <Link2 />
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[319.828px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col gap-[31.996px] items-start pt-[19.99px] px-[19.99px] relative size-full">
        <Container18 />
        <Navigation />
      </div>
    </div>
  );
}

function App2() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[853.319px] items-start left-[-280px] pr-[1.18px] top-[165.23px] w-[279.995px]" data-name="App">
      <div aria-hidden="true" className="absolute border-[#e7e7e7] border-r-[1.18px] border-solid inset-0 pointer-events-none" />
      <Container17 />
    </div>
  );
}

export default function MobileDesignCreationCopy() {
  return (
    <div className="bg-white relative size-full" data-name="Mobile Design Creation (Copy)">
      <Body />
      <App1 />
      <App2 />
    </div>
  );
}