import svgPaths from "./svg-0y9j7yv57q";
import imgEllipse73 from "figma:asset/de594936ad0a19f927b491e86d6ede3a55fdfe1d.png";
import imgPeople from "figma:asset/574436234932c1bee1f2c0e5132cc2c2470cb1cc.png";

function Group35() {
  return (
    <div className="absolute contents left-[2px] top-[218px]">
      <div className="absolute bg-[rgba(127,86,216,0.1)] h-[45px] left-[2px] top-[218px] w-[249px]" />
    </div>
  );
}

function AlignLeft() {
  return (
    <div className="absolute left-[20px] size-[30px] top-[27px]" data-name="align-left">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="align-left">
          <path d="M22.5 14.5H5" id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 7.5H5" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 21.5H5" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <div className="relative shrink-0 size-[48px]">
        <img alt="" className="block max-w-none size-full" height="48" src={imgEllipse73} width="48" />
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#1a202c] text-[16px] whitespace-nowrap">
        <p className="leading-[normal]">Alex Robert</p>
      </div>
    </div>
  );
}

function User() {
  return (
    <div className="absolute bg-[#fafafa] content-stretch flex gap-[12px] h-[56px] items-center left-[1019px] pl-[5px] pr-[18px] py-[12px] rounded-[1000px] top-[14px]" data-name="user">
      <Frame />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[20px] top-[14px]">
      <AlignLeft />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[63px] text-[#2e2c34] text-[18px] top-[31px]">{`Welcome! `}</p>
      <User />
    </div>
  );
}

function TopBar() {
  return (
    <div className="h-[85px] relative shrink-0 w-full" data-name="Top Bar">
      <div className="absolute bg-white h-[85px] left-0 shadow-[0px_4px_40px_1px_rgba(0,0,0,0.03)] top-0 w-[1263px]" />
      <Group1 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[calc(16.67%-3px)] top-0 w-[1263px]">
      <TopBar />
    </div>
  );
}

function Card() {
  return (
    <div className="absolute h-[904px] left-0 rounded-[4px] top-0 w-[1194px]" data-name="card">
      <div className="absolute bg-white inset-0 rounded-[4px]" />
    </div>
  );
}

function VuesaxLinearMessageEdit() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/message-edit">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="message-edit">
          <path d={svgPaths.p1b31b600} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Group">
            <path d={svgPaths.p395e4a00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
            <path d={svgPaths.p4b86480} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          </g>
          <g id="Vector_4" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function MessageEdit() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="message-edit">
      <VuesaxLinearMessageEdit />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#7f56d8] content-stretch flex gap-[10px] h-[44px] items-center justify-center left-[1017px] p-[10px] rounded-[4px] top-[27px] w-[157px]" data-name="Button">
      <MessageEdit />
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">New Ticket</p>
      </div>
    </div>
  );
}

function UsersList() {
  return (
    <div className="absolute h-[885px] left-[calc(16.67%+22px)] overflow-clip rounded-[4px] top-[167px] w-[1194px]" data-name="Users List">
      <Card />
      <Button />
    </div>
  );
}

function VuesaxLinearSearchNormal() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/search-normal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="search-normal">
          <path d={svgPaths.p1cd7af0} id="Vector" stroke="var(--stroke-0, #B6B6B6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M16.5 16.5L15 15" id="Vector_2" stroke="var(--stroke-0, #B6B6B6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Vector_3" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function SearchNormal() {
  return (
    <div className="absolute inset-[calc(29.55%-0.41px)_calc(84.25%+0.69px)_calc(29.55%-0.41px)_calc(8.66%-0.83px)]" data-name="search-normal">
      <VuesaxLinearSearchNormal />
    </div>
  );
}

function SearchInput() {
  return (
    <div className="absolute bg-[#fbfbfb] border border-[#e7e7e7] border-solid h-[44px] left-[calc(16.67%+42px)] rounded-[4px] top-[195px] w-[254px]" data-name="Search Input">
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[calc(36.36%-0.27px)_calc(5.77%-0.88px)_calc(34.09%-0.32px)_calc(20.61%-0.59px)] justify-center leading-[0] text-[#b6b6b6] text-[12px]">
        <p className="leading-[normal] whitespace-pre-wrap">Search for ticket</p>
      </div>
      <SearchNormal />
    </div>
  );
}

function VuesaxLinearArrowDown() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19">
        <g id="arrow-down">
          <path d={svgPaths.p2917ad60} id="Vector" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_2" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function ArrowDown() {
  return (
    <div className="absolute inset-[calc(29.55%-0.41px)_calc(12.82%-0.74px)_calc(27.27%-0.45px)_calc(70.94%+0.42px)]" data-name="arrow-down">
      <VuesaxLinearArrowDown />
    </div>
  );
}

function ExportButton() {
  return (
    <div className="absolute border border-[#e7e7e7] border-solid h-[44px] left-[calc(75%+21px)] rounded-[4px] top-[195px] w-[117px]" data-name="Export Button">
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[calc(34.09%-0.32px)_calc(33.33%-0.33px)_calc(31.82%-0.36px)_calc(12.82%-0.74px)] justify-center leading-[0] text-[#84818a] text-[12px] whitespace-nowrap">
        <p className="leading-[normal]">This Week</p>
      </div>
      <ArrowDown />
    </div>
  );
}

function Tittle1() {
  return (
    <div className="content-stretch flex items-center relative shrink-0" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#b4b4b4] text-[12px] text-center tracking-[-0.24px] whitespace-nowrap">
        <p className="leading-[normal]">Prevoius</p>
      </div>
    </div>
  );
}

function Tittle() {
  return (
    <div className="content-stretch flex flex-col h-[31px] items-center justify-center px-[20px] py-[10px] relative rounded-[4px] shrink-0" data-name="Tittle">
      <Tittle1 />
    </div>
  );
}

function Tittle3() {
  return (
    <div className="content-stretch flex items-center relative shrink-0" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[12px] text-center text-white tracking-[-0.24px] w-[20px]">
        <p className="leading-[normal] whitespace-pre-wrap">1</p>
      </div>
    </div>
  );
}

function Tittle2() {
  return (
    <div className="bg-[#7f56d8] content-stretch flex flex-col h-[32px] items-center justify-center p-[10px] relative rounded-[4px] shrink-0" data-name="Tittle">
      <Tittle3 />
    </div>
  );
}

function Tittle5() {
  return (
    <div className="content-stretch flex items-center relative shrink-0" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[12px] text-center tracking-[-0.24px] w-[20px]">
        <p className="leading-[normal] whitespace-pre-wrap">2</p>
      </div>
    </div>
  );
}

function Tittle4() {
  return (
    <div className="content-stretch flex flex-col h-[32px] items-center justify-center p-[10px] relative rounded-[4px] shrink-0" data-name="Tittle">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Tittle5 />
    </div>
  );
}

function Tittle7() {
  return (
    <div className="content-stretch flex items-center relative shrink-0" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#84818a] text-[12px] text-center tracking-[-0.24px] w-[28px]">
        <p className="leading-[normal] whitespace-pre-wrap">Next</p>
      </div>
    </div>
  );
}

function Tittle6() {
  return (
    <div className="content-stretch flex flex-col h-[32px] items-center justify-center px-[20px] py-[10px] relative rounded-[4px] shrink-0" data-name="Tittle">
      <Tittle7 />
    </div>
  );
}

function Page() {
  return (
    <div className="absolute content-stretch flex gap-[10px] items-start left-[calc(75%+45px)] top-[994px]" data-name="Page">
      <Tittle />
      <Tittle2 />
      <Tittle4 />
      <Tittle6 />
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute h-[0.25px] left-[calc(16.67%+42px)] top-[325px] w-[1154.999px]">
      <div className="absolute inset-[-1100%_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1155 3">
          <g id="Group 1000004229">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.504883" x2="1154.5" y1="2.25" y2="2.25" />
            <line id="Line_2" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeWidth="3" x1="1.5" x2="108.027" y1="1.5" y2="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function VuesaxLinearSms() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/sms">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0521 20">
        <g id="sms">
          <path d={svgPaths.p27dd8800} id="Vector" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.p221feb00} id="Vector_2" stroke="var(--stroke-0, #7F56D8)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_3" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function Sms() {
  return (
    <div className="absolute h-[20px] left-[calc(16.67%+42px)] top-[285px] w-[20.052px]" data-name="sms">
      <VuesaxLinearSms />
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[285px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[calc(16.67%+72.01px)] text-[#7f56d8] text-[14px] top-[295px] w-[72.187px]">
        <p className="leading-[14px] whitespace-pre-wrap">All Tickets</p>
      </div>
      <Sms />
    </div>
  );
}

function VuesaxLinearSmsNotification() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/sms-notification">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0521 20">
        <g id="sms-notification">
          <path d={svgPaths.p10b8f700} id="Vector" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.pa592f80} id="Vector_2" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.p1bb2a700} id="Vector_3" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_4" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function SmsNotification() {
  return (
    <div className="absolute h-[20px] left-[calc(25%+80px)] top-[285px] w-[20.052px]" data-name="sms-notification">
      <VuesaxLinearSmsNotification />
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents left-[calc(25%+80px)] top-[285px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[calc(25%+106.19px)] text-[#84818a] text-[14px] top-[294px] w-[108px]">
        <p className="leading-[14px] whitespace-pre-wrap">Not Replayed</p>
      </div>
      <SmsNotification />
    </div>
  );
}

function VuesaxLinearSmsStar() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/sms-star">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0521 20">
        <g id="sms-star">
          <path d={svgPaths.p19a75730} id="Vector" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.pbb23340} id="Vector_2" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Group">
            <path d={svgPaths.p1f80e00} id="Vector_3" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Vector_4" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function SmsStar() {
  return (
    <div className="absolute h-[20px] left-[calc(50%+57.32px)] top-[285px] w-[20.052px]" data-name="sms-star">
      <VuesaxLinearSmsStar />
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[calc(50%+57.32px)] top-[285px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[calc(50%+87.33px)] text-[#84818a] text-[14px] top-[295px] w-[65.169px]">
        <p className="leading-[14px] whitespace-pre-wrap">Resolved</p>
      </div>
      <SmsStar />
    </div>
  );
}

function VuesaxLinearSmsTracking() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/sms-tracking">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0521 20">
        <g id="sms-tracking">
          <path d={svgPaths.p211db1d8} id="Vector" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.p221feb00} id="Vector_2" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d="M1.67101 13.75H6.68402" id="Vector_3" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d="M1.67101 10.4167H4.17752" id="Vector_4" stroke="var(--stroke-0, #84818A)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_5" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function SmsTracking() {
  return (
    <div className="absolute h-[20px] left-[calc(41.67%+20.52px)] top-[285px] w-[20.052px]" data-name="sms-tracking">
      <VuesaxLinearSmsTracking />
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[calc(41.67%+20.52px)] top-[285px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[calc(41.67%+50.53px)] text-[#84818a] text-[14px] top-[295px] w-[70.182px]">
        <p className="leading-[14px] whitespace-pre-wrap">On-Going</p>
      </div>
      <SmsTracking />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[285px]">
      <Group6 />
      <Group9 />
      <Group8 />
      <Group7 />
    </div>
  );
}

function TicketGroup() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[285px]" data-name="Ticket Group">
      <Group11 />
      <Group10 />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute contents font-['Montserrat:Medium',sans-serif] font-medium leading-[0] left-[calc(16.67%+62px)] top-[413.16px]">
      <div className="-translate-y-1/2 absolute flex flex-col h-[15.217px] justify-center left-[calc(16.67%+62px)] text-[#2e2c34] text-[14px] top-[420.77px] w-[411.934px]">
        <p className="leading-[14px] whitespace-pre-wrap">How to Join to my portal?</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[30.435px] justify-center left-[calc(16.67%+62.23px)] text-[#84818a] text-[12px] top-[454.47px] w-[964px]">
        <p className="whitespace-pre-wrap">
          <span className="leading-[14px]">{`The answer is  Lorem ipsum dolor sit amet, consectetur adipiscing elit.`}</span>
          <span className="leading-[14px] text-[#84818a]">Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span>
          <span className="leading-[14px]">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span>
          <span className="leading-[14px] text-[#84818a]">Lorem ipsum dolor sit amet, consectetur adipiscing elit</span>
          <span className="leading-[14px]">.</span>
        </p>
      </div>
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[371.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[calc(16.67%+101px)] text-[#2e2c34] text-[16px] top-[383.21px] w-[248.745px]">
        <p className="leading-[14px] whitespace-pre-wrap">Replay-Ticket# 2023-CS123</p>
      </div>
      <div className="absolute left-[calc(16.67%+62px)] size-[22px] top-[371.25px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
          <circle cx="11" cy="11" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="11" />
        </svg>
      </div>
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[368px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(83.33%+44px)] text-[#84818a] text-[12px] top-[375.5px] w-[117px]">
        <p className="leading-[14px] whitespace-pre-wrap">Posted at 12:45 AM</p>
      </div>
      <div className="absolute h-0 left-[calc(16.67%+62px)] top-[484.68px] w-[1107.47px]" data-name="Line">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1107.47 1">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.5" x2="1106.97" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[368px]">
      <Group12 />
      <Group14 />
      <Group15 />
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[349px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[32.43%_4.17%_49.81%_19.44%] rounded-[4px]" />
      <Group16 />
    </div>
  );
}

function People() {
  return (
    <div className="absolute left-[calc(16.67%+62px)] rounded-[30px] size-[28px] top-[496px]" data-name="People">
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[30px]">
        <img alt="" className="absolute h-[163.95%] left-[-0.57%] max-w-none top-[-2.05%] w-[109.3%]" src={imgPeople} />
      </div>
    </div>
  );
}

function Group27() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[496px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(83.33%+75px)] text-[#7f56d8] text-[14px] top-[509.5px] w-[86px]">
        <p className="[text-decoration-skip-ink:none] decoration-solid leading-[14px] underline whitespace-pre-wrap">Open Ticket</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(16.67%+97px)] text-[#84818a] text-[14px] top-[509.5px] w-[159px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Dr.Mohamed Ahmed  `}</p>
      </div>
      <People />
    </div>
  );
}

function Group28() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[349px]">
      <Group17 />
      <Group27 />
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute contents font-['Montserrat:Medium',sans-serif] font-medium leading-[0] left-[calc(16.67%+62px)] top-[628.16px]">
      <div className="-translate-y-1/2 absolute flex flex-col h-[15.217px] justify-center left-[calc(16.67%+62px)] text-[#2e2c34] text-[14px] top-[635.77px] w-[411.934px]">
        <p className="leading-[14px] whitespace-pre-wrap">How to Join to my portal?</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[30.435px] justify-center left-[calc(16.67%+62.23px)] text-[#84818a] text-[12px] top-[669.47px] w-[964px]">
        <p className="whitespace-pre-wrap">
          <span className="leading-[14px]">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span>
          <span className="leading-[14px] text-[#84818a]">Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span>
          <span className="leading-[14px]">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span>
          <span className="leading-[14px] text-[#84818a]">Lorem ipsum dolor sit amet, consectetur adipiscing elit</span>
          <span className="leading-[14px]">.</span>
        </p>
      </div>
    </div>
  );
}

function Group20() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[586.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[calc(16.67%+101px)] text-[#2e2c34] text-[16px] top-[598.21px] w-[248.745px]">
        <p className="leading-[14px] whitespace-pre-wrap">Ticket# 2023-CS123</p>
      </div>
      <div className="absolute left-[calc(16.67%+62px)] size-[22px] top-[586.25px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
          <circle cx="11" cy="11" fill="var(--fill-0, #3B8AFF)" id="Ellipse 931" r="11" />
        </svg>
      </div>
    </div>
  );
}

function Group21() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[583px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(83.33%+44px)] text-[#84818a] text-[12px] top-[590.5px] w-[117px]">
        <p className="leading-[14px] whitespace-pre-wrap">Posted at 12:45 AM</p>
      </div>
      <div className="absolute h-0 left-[calc(16.67%+62px)] top-[699.68px] w-[1107.47px]" data-name="Line">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1107.47 1">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.5" x2="1106.97" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Group19() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[583px]">
      <Group13 />
      <Group20 />
      <Group21 />
    </div>
  );
}

function Group18() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[564px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[52.42%_4.17%_29.83%_19.44%] rounded-[4px]" />
      <Group19 />
    </div>
  );
}

function People1() {
  return (
    <div className="absolute left-[calc(16.67%+62px)] rounded-[30px] size-[28px] top-[711px]" data-name="People">
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[30px]">
        <img alt="" className="absolute h-[163.95%] left-[-0.57%] max-w-none top-[-2.05%] w-[109.3%]" src={imgPeople} />
      </div>
    </div>
  );
}

function Group30() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[711px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(83.33%+75px)] text-[#7f56d8] text-[14px] top-[724.5px] w-[86px]">
        <p className="[text-decoration-skip-ink:none] decoration-solid leading-[14px] underline whitespace-pre-wrap">Open Ticket</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(16.67%+97px)] text-[#84818a] text-[14px] top-[724.5px] w-[128px]">
        <p className="leading-[14px] whitespace-pre-wrap">DrJohn Snow</p>
      </div>
      <People1 />
    </div>
  );
}

function Group29() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[564px]">
      <Group18 />
      <Group30 />
    </div>
  );
}

function Group24() {
  return (
    <div className="absolute contents font-['Montserrat:Medium',sans-serif] font-medium leading-[0] left-[calc(16.67%+62px)] top-[843.16px]">
      <div className="-translate-y-1/2 absolute flex flex-col h-[15.217px] justify-center left-[calc(16.67%+62px)] text-[#2e2c34] text-[14px] top-[850.77px] w-[411.934px]">
        <p className="leading-[14px] whitespace-pre-wrap">How to Join to my portal?</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[30.435px] justify-center left-[calc(16.67%+62.23px)] text-[#84818a] text-[12px] top-[884.47px] w-[964px]">
        <p className="leading-[14px] whitespace-pre-wrap">{`Hello mohamed you can do 1 2 3 4 5 `}</p>
      </div>
    </div>
  );
}

function Group25() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[801.25px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[15.217px] justify-center leading-[0] left-[calc(16.67%+101px)] text-[#2e2c34] text-[16px] top-[813.21px] w-[248.745px]">
        <p className="leading-[14px] whitespace-pre-wrap">Replay-Ticket# 2023-CS123</p>
      </div>
      <div className="absolute left-[calc(16.67%+62px)] size-[22px] top-[801.25px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
          <circle cx="11" cy="11" fill="var(--fill-0, #54C104)" id="Ellipse 931" r="11" />
        </svg>
      </div>
    </div>
  );
}

function Group26() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[798px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(83.33%+44px)] text-[#84818a] text-[12px] top-[805.5px] w-[117px]">
        <p className="leading-[14px] whitespace-pre-wrap">Posted at 12:45 AM</p>
      </div>
      <div className="absolute h-0 left-[calc(16.67%+62px)] top-[914.68px] w-[1107.47px]" data-name="Line">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1107.47 1">
            <line id="Line" stroke="var(--stroke-0, #E7E7E7)" strokeLinecap="round" x1="0.5" x2="1106.97" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Group23() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[798px]">
      <Group24 />
      <Group25 />
      <Group26 />
    </div>
  );
}

function Group22() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[779px]">
      <div className="absolute bg-[#fefefe] border border-[#e7e7e7] border-solid inset-[72.4%_4.17%_9.85%_19.44%] rounded-[4px]" />
      <Group23 />
    </div>
  );
}

function People2() {
  return (
    <div className="absolute left-[calc(16.67%+62px)] rounded-[30px] size-[28px] top-[926px]" data-name="People">
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[30px]">
        <img alt="" className="absolute h-[163.95%] left-[-0.57%] max-w-none top-[-2.05%] w-[109.3%]" src={imgPeople} />
      </div>
    </div>
  );
}

function Group32() {
  return (
    <div className="absolute contents left-[calc(16.67%+62px)] top-[926px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(83.33%+75px)] text-[#7f56d8] text-[14px] top-[939.5px] w-[86px]">
        <p className="[text-decoration-skip-ink:none] decoration-solid leading-[14px] underline whitespace-pre-wrap">Open Ticket</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[15px] justify-center leading-[0] left-[calc(16.67%+97px)] text-[#84818a] text-[14px] top-[939.5px] w-[95px]">
        <p className="leading-[14px] whitespace-pre-wrap">Dr Snow</p>
      </div>
      <People2 />
    </div>
  );
}

function Group31() {
  return (
    <div className="absolute contents left-[calc(16.67%+42px)] top-[779px]">
      <Group22 />
      <Group32 />
    </div>
  );
}

function InputArea() {
  return <div className="absolute bg-white border border-[#e7e7e7] border-solid h-[115px] left-[calc(58.33%+110px)] rounded-[4px] top-[179px] w-[152px]" data-name="Input Area" />;
}

function ColumnDropDOwn() {
  return (
    <div className="absolute contents left-[calc(58.33%+110px)] top-[179px]" data-name="Column Drop DOwn">
      <InputArea />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents inset-[18.22%_26.59%_80.39%_67.92%]">
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[18.22%_26.59%_80.39%_67.92%] justify-center leading-[0] text-[#7f56d8] text-[12px]">
        <p className="leading-[normal] whitespace-pre-wrap">Not Replayed</p>
      </div>
    </div>
  );
}

function Group33() {
  return (
    <div className="absolute contents left-[66.67%] top-[196px]">
      <div className="absolute left-[66.67%] size-[14px] top-[197px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
          <circle cx="7" cy="7" fill="var(--fill-0, #3B8AFF)" id="Ellipse 932" r="7" />
        </svg>
      </div>
      <Group2 />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents inset-[21.65%_25.07%_76.95%_67.79%]">
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[21.65%_25.07%_76.95%_67.79%] justify-center leading-[0] text-[#84818a] text-[12px]">
        <p className="leading-[normal] whitespace-pre-wrap">On-Going Tickets</p>
      </div>
    </div>
  );
}

function Group36() {
  return (
    <div className="absolute contents left-[calc(66.67%-2px)] top-[233px]">
      <div className="absolute left-[calc(66.67%-2px)] size-[14px] top-[234px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
          <circle cx="7" cy="7" fill="var(--fill-0, #FAC885)" id="Ellipse 933" r="7" />
        </svg>
      </div>
      <Group3 />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents inset-[24.72%_25.46%_73.88%_67.79%]">
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[24.72%_25.46%_73.88%_67.79%] justify-center leading-[0] text-[#84818a] text-[12px]">
        <p className="leading-[normal] whitespace-pre-wrap">Resolved Tickets</p>
      </div>
    </div>
  );
}

function Group37() {
  return (
    <div className="absolute contents left-[calc(66.67%-2px)] top-[266px]">
      <div className="absolute left-[calc(66.67%-2px)] size-[14px] top-[267px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
          <circle cx="7" cy="7" fill="var(--fill-0, #54C104)" id="Ellipse 934" r="7" />
        </svg>
      </div>
      <Group4 />
    </div>
  );
}

function Group34() {
  return (
    <div className="absolute contents left-[calc(58.33%+110px)] top-[179px]">
      <ColumnDropDOwn />
      <div className="absolute bg-[rgba(127,86,216,0.05)] h-[34px] left-[calc(66.67%-7px)] rounded-[4px] top-[187px] w-[135px]" />
      <Group33 />
      <Group36 />
      <Group37 />
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[calc(58.33%+110px)] top-[179px]">
      <Group34 />
    </div>
  );
}

function Category() {
  return (
    <div className="absolute inset-[8.33%_10.42%_10.42%_8.33%]" data-name="Category">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.875 17.875">
        <g id="Category">
          <path clipRule="evenodd" d={svgPaths.p3aaa82c0} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 1" />
          <path clipRule="evenodd" d={svgPaths.p2a04b900} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 3" />
          <path clipRule="evenodd" d={svgPaths.p10e31300} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 5" />
          <path clipRule="evenodd" d={svgPaths.p120a9d80} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 7" />
        </g>
      </svg>
    </div>
  );
}

function IconlyLightOutlineCategory() {
  return (
    <div className="absolute inset-[10.78%_79.52%_87.17%_11.65%]" data-name="Iconly/Light-Outline/Category">
      <Category />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[29px] top-[116px]">
      <IconlyLightOutlineCategory />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[61px] text-[#7f56d8] text-[16px] top-[117px]">Dashboard</p>
    </div>
  );
}

function IconsaxLinearTicketstar() {
  return (
    <div className="absolute left-[27px] size-[22px] top-[186px]" data-name="Iconsax/Linear/ticketstar">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/ticketstar">
          <path d={svgPaths.p388172f0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p19372c00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function MaterialSymbolsLogoutRounded() {
  return (
    <div className="absolute left-[27px] size-[22px] top-[254px]" data-name="material-symbols:logout-rounded">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="material-symbols:logout-rounded">
          <path d={svgPaths.p3c8a9ec0} fill="var(--fill-0, #1E1E1E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute h-[1076px] left-0 top-0 w-[249px]" data-name="Sidebar">
      <div className="absolute bg-white border-[#e7e7e7] border-r border-solid h-[1076px] left-0 top-0 w-[249px]" />
      <div className="absolute bg-[rgba(127,86,216,0.1)] h-[45px] left-[-8px] top-[105px] w-[249px]" />
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[35px] text-[#2e2c34] text-[24px] top-[28px] uppercase">Ticket Lead</p>
      <Group />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[59px] text-[#2e2c34] text-[16px] top-[187px]">New Ticket</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[57px] text-[#2e2c34] text-[16px] top-[256px]">Logout</p>
      <IconsaxLinearTicketstar />
      <MaterialSymbolsLogoutRounded />
    </div>
  );
}

export default function TicketMain() {
  return (
    <div className="bg-[#f9f9fb] relative size-full" data-name="Ticket Main">
      <Group35 />
      <Frame1 />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-[calc(16.67%+22px)] text-[#2e2c34] text-[24px] top-[125.5px] whitespace-nowrap">
        <p className="leading-[normal]">Tickets</p>
      </div>
      <UsersList />
      <SearchInput />
      <ExportButton />
      <Page />
      <TicketGroup />
      <Group28 />
      <Group29 />
      <Group31 />
      <Group5 />
      <Sidebar />
    </div>
  );
}