import svgPaths from "./svg-bo5b9xos9b";
import imgEllipse73 from "figma:asset/de594936ad0a19f927b491e86d6ede3a55fdfe1d.png";

function AlignLeft() {
  return (
    <div className="absolute left-[20px] size-[30px] top-[27px]" data-name="align-left">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="align-left">
          <path d="M22.5 14.5H5" id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 7.5H5" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 21.5H5" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <div className="relative shrink-0 size-[48px]">
        <img alt="" className="block max-w-none size-full" height="48" src={imgEllipse73} width="48" />
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#1a202c] text-[16px] whitespace-nowrap">
        <p className="leading-[normal]">Alex Robert</p>
      </div>
    </div>
  );
}

function ChevronDown() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="chevron-down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="chevron-down">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #0C0407)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function User() {
  return (
    <div className="absolute bg-[#fafafa] content-stretch flex gap-[12px] h-[56px] items-center left-[1019px] pl-[5px] pr-[18px] py-[12px] rounded-[1000px] top-[14px]" data-name="user">
      <Frame />
      <ChevronDown />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[20px] top-[14px]">
      <AlignLeft />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[0] left-[63px] text-[#1b1b1b] text-[#2e2c34] text-[18px] top-[31px]">
        <span className="leading-[normal]">{`Welcome! `}</span>
        <span className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal]">John Smith</span>
      </p>
      <User />
    </div>
  );
}

function TopBar() {
  return (
    <div className="absolute h-[85px] left-[calc(16.67%-3px)] top-0 w-[1263px]" data-name="Top Bar">
      <div className="absolute bg-white h-[85px] left-0 shadow-[0px_4px_40px_1px_rgba(0,0,0,0.03)] top-0 w-[1263px]" />
      <Group1 />
    </div>
  );
}

function Card() {
  return (
    <div className="absolute h-[828px] left-0 rounded-[4px] top-0 w-[1195px]" data-name="card">
      <div className="absolute bg-white inset-0 rounded-[4px]" />
    </div>
  );
}

function VuesaxLinearArrowDown1() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="arrow-down">
          <path d={svgPaths.p3993d9c0} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_2" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowDown() {
  return (
    <div className="relative size-[16px]" data-name="vuesax/linear/arrow-down">
      <VuesaxLinearArrowDown1 />
    </div>
  );
}

function InputArea() {
  return (
    <div className="content-stretch flex gap-[63px] h-[50px] items-center px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[366px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Level 4 `}</p>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <VuesaxLinearArrowDown />
        </div>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[20px] top-[127px] w-[366px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[320px]">
        <p className="whitespace-pre-wrap">
          <span className="leading-[normal]">{`Choose Level  `}</span>
          <span className="leading-[normal] text-[red]">*</span>
        </p>
      </div>
      <InputArea />
    </div>
  );
}

function VuesaxLinearArrowDown3() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="arrow-down">
          <path d={svgPaths.p3993d9c0} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_2" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowDown2() {
  return (
    <div className="relative size-[16px]" data-name="vuesax/linear/arrow-down">
      <VuesaxLinearArrowDown3 />
    </div>
  );
}

function InputArea1() {
  return (
    <div className="content-stretch flex gap-[63px] h-[50px] items-center px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[366px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">Choose Level</p>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <VuesaxLinearArrowDown2 />
        </div>
      </div>
    </div>
  );
}

function Content1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[20px] top-[228px] w-[366px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[320px]">
        <p className="whitespace-pre-wrap">
          <span className="leading-[normal]">{`Select Doctor `}</span>
          <span className="leading-[normal] text-[red]">*</span>
        </p>
      </div>
      <InputArea1 />
    </div>
  );
}

function InputArea2() {
  return (
    <div className="absolute content-stretch flex h-[50px] items-center left-[415px] px-[20px] py-[16px] rounded-[4px] top-[252px] w-[366px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Enter  Ticket Subject`}</p>
      </div>
    </div>
  );
}

function Tittle() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] items-start leading-[0] left-[20px] top-[24px]" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[28px] justify-center relative shrink-0 text-[#2e2a40] text-[18px] w-[204px]">
        <p className="whitespace-pre-wrap">Create Quick Ticket</p>
      </div>
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center relative shrink-0 text-[#84818a] text-[16px] whitespace-nowrap">
        <p className="leading-[normal]">Write and address new queries and issues</p>
      </div>
    </div>
  );
}

function VuesaxLinearArrowDown5() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="arrow-down">
          <path d={svgPaths.p3993d9c0} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_2" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowDown4() {
  return (
    <div className="relative size-[16px]" data-name="vuesax/linear/arrow-down">
      <VuesaxLinearArrowDown5 />
    </div>
  );
}

function InputArea3() {
  return (
    <div className="content-stretch flex gap-[63px] h-[50px] items-center px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[366px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">Semester 1</p>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <VuesaxLinearArrowDown4 />
        </div>
      </div>
    </div>
  );
}

function Content2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[414px] top-[127px] w-[366px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[320px]">
        <p className="whitespace-pre-wrap">
          <span className="leading-[normal]">{`Choose Semester `}</span>
          <span className="leading-[normal] text-[red]">*</span>
        </p>
      </div>
      <InputArea3 />
    </div>
  );
}

function VuesaxLinearArrowDown7() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="arrow-down">
          <path d={svgPaths.p3993d9c0} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_2" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowDown6() {
  return (
    <div className="relative size-[16px]" data-name="vuesax/linear/arrow-down">
      <VuesaxLinearArrowDown7 />
    </div>
  );
}

function InputArea4() {
  return (
    <div className="content-stretch flex gap-[63px] h-[50px] items-center px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[366px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">Select Status</p>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <VuesaxLinearArrowDown6 />
        </div>
      </div>
    </div>
  );
}

function InputArea5() {
  return (
    <div className="bg-white border border-[#e7e7e7] border-solid col-1 h-[134px] ml-0 mt-0 relative rounded-[4px] row-1 w-[366px]" data-name="Input Area">
      <div className="absolute bg-white border-[rgba(0,0,0,0.5)] border-b-[0.5px] border-solid h-[32px] left-[10px] top-[12px] w-[341px]" />
      <div className="absolute bg-white border-[#e7e7e7] border-b-[0.5px] border-solid h-[32px] left-[10px] top-[12px] w-[341px]" />
      <div className="absolute bg-white border-[#e7e7e7] border-b-[0.5px] border-solid h-[32px] left-[10px] top-[53px] w-[341px]" />
      <div className="absolute bg-white border-[#e7e7e7] border-b-[0.5px] border-solid h-[32px] left-[10px] top-[94px] w-[341px]" />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] left-[25px] text-[14px] text-black top-[26.5px] whitespace-nowrap">
        <p className="leading-[normal]">01 - Section Internet Application</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] left-[25px] text-[14px] text-black top-[67.5px] whitespace-nowrap">
        <p className="leading-[normal]">{`02 -  Internet Application`}</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] left-[25px] text-[14px] text-black top-[108.5px] whitespace-nowrap">
        <p className="leading-[normal]">{`05 - Section Information System  `}</p>
      </div>
    </div>
  );
}

function ColumnDropDOwn() {
  return (
    <div className="col-1 grid-cols-[max-content] grid-rows-[max-content] inline-grid items-[start] justify-items-[start] ml-0 mt-0 relative row-1" data-name="Column Drop DOwn">
      <InputArea5 />
    </div>
  );
}

function Group4() {
  return (
    <div className="col-1 grid-cols-[max-content] grid-rows-[max-content] inline-grid items-[start] justify-items-[start] ml-0 mt-0 relative row-1">
      <ColumnDropDOwn />
    </div>
  );
}

function Group2() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid items-[start] justify-items-[start] leading-[0] relative shrink-0 w-full">
      <Group4 />
    </div>
  );
}

function Content3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[807px] top-[127px] w-[366px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[320px]">
        <p className="whitespace-pre-wrap">
          <span className="leading-[normal]">{`Choose Subject `}</span>
          <span className="leading-[normal] text-[red]">*</span>
        </p>
      </div>
      <InputArea4 />
      <Group2 />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[414px] top-[127px]">
      <Content2 />
      <Content3 />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#7f56d8] content-stretch flex h-[44px] items-center justify-center left-[1016px] p-[10px] rounded-[4px] top-[580px] w-[157px]" data-name="Button">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Send Ticket</p>
      </div>
    </div>
  );
}

function AttachFile() {
  return (
    <div className="absolute left-[1096px] size-[24px] top-[136px]" data-name="attach_file">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="attach_file" />
      </svg>
    </div>
  );
}

function InputArea6() {
  return (
    <div className="h-[182px] relative rounded-[4px] shrink-0 w-[1153px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[8.79%_76.24%_82.42%_1.73%] justify-center leading-[0] text-[#757575] text-[14px] tracking-[-0.28px]">
        <p className="leading-[normal] whitespace-pre-wrap">Type ticket issue here..</p>
      </div>
      <AttachFile />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] items-start relative shrink-0">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[320px]">
        <p className="leading-[normal] whitespace-pre-wrap">Ticket Body</p>
      </div>
      <InputArea6 />
    </div>
  );
}

function Content4() {
  return (
    <div className="absolute content-stretch flex flex-col h-[231px] items-start left-[20px] top-[322px] w-[1153px]" data-name="Content">
      <Frame1 />
    </div>
  );
}

function ReplyDetailTicket() {
  return (
    <div className="absolute h-[648px] left-[calc(16.67%+15px)] overflow-clip rounded-[4px] top-[180px] w-[1195px]" data-name="Reply Detail Ticket">
      <Card />
      <Content />
      <Content1 />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] left-[415px] text-[#2e2a40] text-[14px] top-[236px] w-[320px]">
        <p className="leading-[normal] whitespace-pre-wrap">Request Ticket Subject</p>
      </div>
      <InputArea2 />
      <Tittle />
      <Group3 />
      <Button />
      <Content4 />
    </div>
  );
}

function Category() {
  return (
    <div className="absolute inset-[8.33%_10.42%_10.42%_8.33%]" data-name="Category">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.875 17.875">
        <g id="Category">
          <path clipRule="evenodd" d={svgPaths.p3aaa82c0} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 1" />
          <path clipRule="evenodd" d={svgPaths.p2a04b900} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 3" />
          <path clipRule="evenodd" d={svgPaths.p10e31300} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 5" />
          <path clipRule="evenodd" d={svgPaths.p120a9d80} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 7" />
        </g>
      </svg>
    </div>
  );
}

function IconlyLightOutlineCategory() {
  return (
    <div className="absolute inset-[10.78%_79.52%_87.17%_11.65%]" data-name="Iconly/Light-Outline/Category">
      <Category />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[29px] top-[116px]">
      <IconlyLightOutlineCategory />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[61px] text-[#7f56d8] text-[16px] top-[117px]">Dashboard</p>
    </div>
  );
}

function IconsaxLinearTicketstar() {
  return (
    <div className="absolute left-[27px] size-[22px] top-[186px]" data-name="Iconsax/Linear/ticketstar">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/ticketstar">
          <path d={svgPaths.p388172f0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p19372c00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function MaterialSymbolsLogoutRounded() {
  return (
    <div className="absolute left-[27px] size-[22px] top-[254px]" data-name="material-symbols:logout-rounded">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="material-symbols:logout-rounded">
          <path d={svgPaths.p3c8a9ec0} fill="var(--fill-0, #1E1E1E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute h-[1076px] left-0 top-0 w-[249px]" data-name="Sidebar">
      <div className="absolute bg-white border-[#e7e7e7] border-r border-solid h-[1076px] left-0 top-0 w-[249px]" />
      <div className="absolute bg-[rgba(127,86,216,0.1)] h-[45px] left-0 top-[174px] w-[249px]" />
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[35px] text-[#2e2c34] text-[24px] top-[28px] uppercase">Ticket Lead</p>
      <Group />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[59px] text-[#2e2c34] text-[16px] top-[187px]">New Ticket</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[57px] text-[#2e2c34] text-[16px] top-[256px]">Logout</p>
      <IconsaxLinearTicketstar />
      <MaterialSymbolsLogoutRounded />
    </div>
  );
}

export default function NewTicket() {
  return (
    <div className="bg-[#f9f9fb] relative size-full" data-name="New Ticket">
      <TopBar />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-[calc(16.67%+21px)] text-[#2e2c34] text-[24px] top-[125.5px] whitespace-nowrap">
        <p className="leading-[normal]">New Ticket</p>
      </div>
      <ReplyDetailTicket />
      <Sidebar />
    </div>
  );
}