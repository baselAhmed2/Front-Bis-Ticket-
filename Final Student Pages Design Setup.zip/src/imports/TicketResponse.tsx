import svgPaths from "./svg-n9h30pxww";
import imgEllipse73 from "figma:asset/ffc5edd5df1e034f97f1621e2ca2d4e33201613f.png";

function AlignLeft() {
  return (
    <div className="absolute left-[20px] size-[30px] top-[27px]" data-name="align-left">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="align-left">
          <path d="M22.5 14.5H5" id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 7.5H5" id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M25 21.5H5" id="Vector_3" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <div className="relative shrink-0 size-[48px]">
        <img alt="" className="absolute block max-w-none size-full" height="48" src={imgEllipse73} width="48" />
      </div>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#1a202c] text-[16px] whitespace-nowrap">
        <p className="leading-[normal]">Alex Robert</p>
      </div>
    </div>
  );
}

function User() {
  return (
    <div className="absolute bg-[#fafafa] content-stretch flex gap-[12px] h-[56px] items-center left-[1019px] pl-[5px] pr-[18px] py-[12px] rounded-[1000px] top-[14px]" data-name="user">
      <Frame />
      <div className="overflow-clip relative shrink-0 size-[16px]" data-name="chevron-down">
        <div className="absolute bottom-[37.5%] left-1/4 right-1/4 top-[37.5%]" data-name="Vector">
          <div className="absolute inset-[-25%_-12.5%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 6">
              <path d="M1 1L5 5L9 1" id="Vector" stroke="var(--stroke-0, #0C0407)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[20px] top-[14px]">
      <AlignLeft />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[63px] text-[#2e2c34] text-[18px] top-[31px]">{`Welcome! `}</p>
      <User />
    </div>
  );
}

function ReplyTicketBox() {
  return (
    <div className="absolute inset-[28.07%_1.67%_50.33%_1.67%]" data-name="Reply ticket Box">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1155 209.382">
        <g id="Reply ticket Box">
          <path d={svgPaths.p30e23800} fill="var(--fill-0, #FCFCFC)" id="Rectangle 6715" stroke="var(--stroke-0, #E7E7E7)" />
        </g>
      </svg>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[27px] top-[57px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[23px] justify-center leading-[0] left-[28px] text-[#2e2c34] text-[18px] top-[68.5px] w-[340px]">
        <p className="leading-[14px] whitespace-pre-wrap">How to deposit money to my portal?</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[normal] left-[27px] text-[#84818a] text-[14px] top-[169.5px] w-[991px] whitespace-pre-wrap">
        <p className="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        <p className="mb-0">&nbsp;</p>
        <p className="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        <p className="mb-0">&nbsp;</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[20px] top-[18px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-[45px] text-[#2e2c34] text-[16px] top-[26px] whitespace-nowrap">
        <p className="leading-[14px]" dir="auto">
          Ticket# 2026-IE123
        </p>
      </div>
      <div className="absolute left-[20px] size-[15px] top-[18px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="7.5" />
        </svg>
      </div>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute left-[20px] size-[15px] top-[18px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="Group 1000004235">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="7.5" />
        </g>
      </svg>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[20px] top-[18px]">
      <Group2 />
      <Group3 />
      <Group4 />
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[20px] top-[18px]">
      <Group5 />
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[1029px] top-[19px]">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[1029px] text-[#84818a] text-[12px] top-[26px] whitespace-nowrap">
        <p className="leading-[14px]">Posted at 12:45 -3-2026</p>
      </div>
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[20px] top-[18px]">
      <Group6 />
      <Group7 />
    </div>
  );
}

function OutputArea() {
  return (
    <div className="bg-white content-stretch flex h-[50px] items-center px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Output Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] tracking-[-0.28px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">Basel Ahmed</p>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[365px] top-[348px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">{`Student Name `}</p>
      </div>
      <OutputArea />
    </div>
  );
}

function Tittle() {
  return (
    <div className="absolute h-[26.604px] left-0 top-0 w-[417px]" data-name="Tittle">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-0 text-[#2e2a40] text-[18px] top-[14.5px] whitespace-nowrap">
        <p className="leading-[1.5]">{`Last Replays On  Ticket`}</p>
      </div>
    </div>
  );
}

function InputArea() {
  return (
    <div className="absolute bg-white border border-[#e7e7e7] border-solid h-[110px] leading-[0] left-0 rounded-[4px] text-black top-[36.6px] w-[967px]" data-name="Input Area">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Light',sans-serif] font-light h-[23px] justify-center left-[18px] text-[10px] top-[18.9px] w-[202px]">
        <p className="leading-[1.5] whitespace-pre-wrap">You on 12-11-2024</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[58px] justify-center left-[22px] text-[14px] top-[54.4px] w-[921px]">
        <p className="leading-[1.5] whitespace-pre-wrap">{`Massage Text `}</p>
      </div>
    </div>
  );
}

function Content1() {
  return (
    <div className="absolute h-[141px] left-[35px] top-[505px] w-[967px]" data-name="Content">
      <Tittle />
      <InputArea />
    </div>
  );
}

function Tittle1() {
  return (
    <div className="absolute h-[27px] left-[36px] top-[296px] w-[53px]" data-name="Tittle">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-0 text-[#2e2a40] text-[18px] top-[13.5px] whitespace-nowrap">
        <p className="leading-[1.5]">{` Ticket Sender Information `}</p>
      </div>
    </div>
  );
}

function OutputArea1() {
  return (
    <div className="absolute bg-white border border-[#e7e7e7] border-solid h-[50px] left-0 rounded-[4px] top-[26px] w-[289px]" data-name="Output Area">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[19px] text-[#757575] text-[14px] top-[24.5px] tracking-[-0.28px] whitespace-nowrap">
        <p className="leading-[normal]">512393207</p>
      </div>
    </div>
  );
}

function Content2() {
  return (
    <div className="absolute h-[76px] left-[35px] top-[348px] w-[289px]" data-name="Content">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-0 text-[#2e2a40] text-[14px] top-[8.5px] whitespace-nowrap">
        <p className="leading-[normal]">Student ID</p>
      </div>
      <OutputArea1 />
    </div>
  );
}

function InputArea1() {
  return (
    <div className="absolute bg-white border border-[#e7e7e7] border-solid h-[50px] left-0 rounded-[4px] top-[26px] w-[289px]" data-name="Input Area">
      <div className="absolute left-[19px] size-[15px] top-[16.5px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="7.5" />
        </svg>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-[47px] text-[#757575] text-[14px] top-[24.5px] whitespace-nowrap">
        <p className="leading-[normal]">{`Information Economy `}</p>
      </div>
    </div>
  );
}

function Content3() {
  return (
    <div className="absolute h-[76px] left-[713px] top-[348px] w-[289px]" data-name="Content">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium justify-center leading-[0] left-0 text-[#2e2a40] text-[14px] top-[8.5px] whitespace-nowrap">
        <p className="leading-[normal]">{`Course `}</p>
      </div>
      <InputArea1 />
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents left-[35px] top-[348px]">
      <Content2 />
      <Content3 />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[35px] top-[296px]">
      <Content1 />
      <Tittle1 />
      <Group9 />
    </div>
  );
}

function InputArea2() {
  return (
    <div className="absolute bg-white border border-[#e7e7e7] border-solid h-[110px] leading-[0] left-[35px] rounded-[4px] text-black top-[674px] w-[967px]" data-name="Input Area">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:Light',sans-serif] font-light h-[23px] justify-center left-[18px] text-[10px] top-[18.9px] w-[202px]">
        <p className="leading-[1.5] whitespace-pre-wrap">Receiver on 13-11-2024</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[58px] justify-center left-[22px] text-[14px] top-[54.4px] w-[921px]">
        <p className="leading-[1.5] whitespace-pre-wrap">{`Massage Text `}</p>
      </div>
    </div>
  );
}

function InputArea3() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[122px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] left-1/2 text-[14px] text-black text-center top-1/2 w-[50px]">
        <p className="leading-[normal] whitespace-pre-wrap">9</p>
      </div>
    </div>
  );
}

function Content4() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[1036px] top-[348px] w-[125px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-full">
        <p className="leading-[normal] whitespace-pre-wrap">{`Group Number `}</p>
      </div>
      <InputArea3 />
    </div>
  );
}

function ReplyDetailTicket() {
  return (
    <div className="absolute h-[969px] left-[calc(16.67%+21px)] overflow-clip rounded-[4px] top-[170px] w-[1195px]" data-name="Reply Detail Ticket">
      <div className="absolute h-[828px] left-0 rounded-[4px] top-0 w-[1195px]" data-name="card">
        <div className="absolute bg-white inset-0 rounded-[4px]" />
      </div>
      <ReplyTicketBox />
      <Group8 />
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[1.63%_40.75%_96.36%_44.52%] justify-center leading-[0] text-[#757575] text-[14px]">
        <p className="leading-[normal] whitespace-pre-wrap">Classwork Issue</p>
      </div>
      <Content />
      <Group10 />
      <InputArea2 />
      <Content4 />
    </div>
  );
}

function VuesaxLinearArrowDown() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-down">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
        <g id="arrow-down">
          <path d={svgPaths.p2c331200} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_2" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#7f56d8] content-stretch flex items-center justify-center left-[calc(83.33%+31px)] p-[10px] rounded-[4px] top-[1328px] w-[157px]" data-name="Button">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[14px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Submit</p>
      </div>
    </div>
  );
}

function InputArea4() {
  return (
    <div className="bg-white content-stretch flex h-[110px] items-start px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[967px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] tracking-[-0.28px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">Type ticket issue here..</p>
      </div>
    </div>
  );
}

function Content5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] h-[133.97px] items-start left-[calc(16.67%+41px)] top-[1194.42px] w-[967px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[320px]">
        <p className="leading-[normal] whitespace-pre-wrap">Ticket Body</p>
      </div>
      <InputArea4 />
    </div>
  );
}

function Tittle2() {
  return (
    <div className="absolute content-stretch flex flex-col h-[26.604px] items-start left-[calc(16.67%+42px)] top-[1047px]" data-name="Tittle">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold h-[28px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[18px] w-[204px]">
        <p className="leading-[1.5] whitespace-pre-wrap">Reply to Ticket</p>
      </div>
    </div>
  );
}

function InputArea5() {
  return (
    <div className="bg-white content-stretch flex h-[50px] items-center px-[20px] py-[16px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] tracking-[-0.28px] w-[254px]">
        <p className="leading-[normal] whitespace-pre-wrap">512393207</p>
      </div>
    </div>
  );
}

function Content6() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[calc(16.67%+41px)] top-[1096.41px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">Token ID</p>
      </div>
      <InputArea5 />
    </div>
  );
}

function VuesaxLinearArrowDown1() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-down">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="arrow-down">
          <path d={svgPaths.p3993d9c0} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_2" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function InputArea6() {
  return (
    <div className="bg-white content-stretch flex gap-[63px] h-[50px] items-center pl-[20px] pr-[72px] py-[16px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#757575] text-[14px] w-[176px]">
        <p className="leading-[normal] whitespace-pre-wrap">Deposit Issue</p>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[16px]" data-name="vuesax/linear/arrow-down">
            <VuesaxLinearArrowDown1 />
          </div>
        </div>
      </div>
    </div>
  );
}

function Content7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[calc(41.67%+2px)] top-[1096.41px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[300px]">
        <p className="leading-[normal] whitespace-pre-wrap">Request Ticket Type</p>
      </div>
      <InputArea6 />
    </div>
  );
}

function VuesaxLinearArrowDown2() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-down">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="arrow-down">
          <path d={svgPaths.p3993d9c0} id="Vector" stroke="var(--stroke-0, #BABABA)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_2" opacity="0" />
        </g>
      </svg>
    </div>
  );
}

function InputArea7() {
  return (
    <div className="bg-white h-[50px] relative rounded-[4px] shrink-0 w-[289px]" data-name="Input Area">
      <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="absolute left-[20px] size-[15px] top-[17.5px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F8A534)" fillOpacity="0.6" id="Ellipse 931" r="7.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Montserrat:Medium',sans-serif] font-medium inset-[34%_17.65%_34%_16.61%] justify-center leading-[0] text-[#757575] text-[14px]">
        <p className="leading-[normal] whitespace-pre-wrap">On-Going</p>
      </div>
      <div className="absolute flex items-center justify-center left-[256px] size-[16px] top-[17px]">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[16px]" data-name="vuesax/linear/arrow-down">
            <VuesaxLinearArrowDown2 />
          </div>
        </div>
      </div>
    </div>
  );
}

function Content8() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] items-start left-[calc(58.33%+89px)] top-[1096.41px] w-[289px]" data-name="Content">
      <div className="flex flex-col font-['Montserrat:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] relative shrink-0 text-[#2e2a40] text-[14px] w-[289px]">
        <p className="leading-[normal] whitespace-pre-wrap">Status</p>
      </div>
      <InputArea7 />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute contents left-[calc(16.67%+41px)] top-[1096.41px]">
      <Content6 />
      <Content7 />
      <Content8 />
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents left-[calc(16.67%+41px)] top-[1047px]">
      <Button />
      <Content5 />
      <Tittle2 />
      <Group12 />
    </div>
  );
}

function Category() {
  return (
    <div className="absolute inset-[8.33%_10.42%_10.42%_8.33%]" data-name="Category">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.875 17.875">
        <g id="Category">
          <path clipRule="evenodd" d={svgPaths.p1b0dd80} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 1" />
          <path clipRule="evenodd" d={svgPaths.p1d036400} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 3" />
          <path clipRule="evenodd" d={svgPaths.pdd4a200} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 5" />
          <path clipRule="evenodd" d={svgPaths.p20c71180} fill="var(--fill-0, #7F56D8)" fillRule="evenodd" id="Fill 7" />
        </g>
      </svg>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[29px] top-[116px]">
      <div className="absolute inset-[10.78%_79.52%_87.17%_11.65%]" data-name="Iconly/Light-Outline/Category">
        <Category />
      </div>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[61px] text-[#7f56d8] text-[16px] top-[117px]">Dashboard</p>
    </div>
  );
}

function IconsaxLinearTicketstar() {
  return (
    <div className="absolute left-[27px] size-[22px] top-[186px]" data-name="Iconsax/Linear/ticketstar">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="Iconsax/Linear/ticketstar">
          <path d={svgPaths.p388172f0} id="Vector" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p19372c00} id="Vector_2" stroke="var(--stroke-0, #2E2C34)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute h-[1076px] left-0 top-0 w-[249px]" data-name="Sidebar">
      <div className="absolute bg-white border-[#e7e7e7] border-r border-solid h-[1076px] left-0 top-0 w-[249px]" />
      <div className="absolute bg-[rgba(127,86,216,0.1)] h-[45px] left-0 top-[174px] w-[249px]" />
      <p className="absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[35px] text-[#2e2c34] text-[24px] top-[28px] uppercase">Ticket Lead</p>
      <Group />
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[59px] text-[#2e2c34] text-[16px] top-[187px]">New Ticket</p>
      <p className="absolute font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] left-[57px] text-[#2e2c34] text-[16px] top-[256px]">Logout</p>
      <IconsaxLinearTicketstar />
      <div className="absolute left-[27px] size-[22px] top-[254px]" data-name="material-symbols:logout-rounded">
        <div className="absolute inset-[12.5%_14.17%_12.5%_12.5%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.1333 16.5">
            <path d={svgPaths.p25f94200} fill="var(--fill-0, #1E1E1E)" id="Vector" />
          </svg>
        </div>
      </div>
    </div>
  );
}

export default function TicketResponse() {
  return (
    <div className="bg-[#f9f9fb] relative size-full" data-name="TicketResponse">
      <div className="absolute bg-white h-[358px] left-[calc(16.67%+21px)] rounded-[16px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-[1031px] w-[1195px]" />
      <div className="absolute h-[85px] left-[calc(16.67%-3px)] top-0 w-[1263px]" data-name="Top Bar">
        <div className="absolute bg-white h-[85px] left-0 shadow-[0px_4px_40px_1px_rgba(0,0,0,0.03)] top-0 w-[1263px]" />
        <Group1 />
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] left-[calc(16.67%+22px)] text-[#2e2c34] text-[24px] top-[125.5px] whitespace-nowrap">
        <p className="leading-[normal]">Tickets</p>
      </div>
      <ReplyDetailTicket />
      <div className="absolute flex items-center justify-center left-[calc(91.67%-15px)] size-[34px] top-[457px]">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[34px]" data-name="vuesax/linear/arrow-down">
            <VuesaxLinearArrowDown />
          </div>
        </div>
      </div>
      <Group11 />
      <Sidebar />
    </div>
  );
}